#include "stdafx.h"
#include "CustomMonsterEffect.h"
#include "LuaStack.hpp"
#include "Console.h"

using namespace luaaa;

CCustomMonsterEffect gCustomMonsterEffect;

CCustomMonsterEffect::CCustomMonsterEffect() : m_Lua(false)
{
	this->m_MonsterEffect.clear();
}

CCustomMonsterEffect::~CCustomMonsterEffect()
{
	this->m_MonsterEffect.clear();
}

void SetMonsterEffect(int MonsterID, int Type, int EffectID, int EffectLv, int Bone, float Size, float R, float G, float B, float Black, int Rand) {
	int MonsterModel = MonsterID + 644;

	CUSTOM_MONSTER_EFFECT monsterInfo;

	monsterInfo.MonsterID = MonsterModel;

	CUSTOM_MONSTER_EFFECT_INFO glowInfo;

	glowInfo.Type = Type;

	glowInfo.EffectID = EffectID;

	glowInfo.EffectLv = EffectLv;

	glowInfo.Bone = Bone;

	glowInfo.Size = Size;

	glowInfo.R = R;

	glowInfo.G = G;

	glowInfo.B = B;

	glowInfo.Black = Black;

	glowInfo.Rand = Rand;

	auto it = gCustomMonsterEffect.m_MonsterEffect.find(MonsterModel);

	if (it == gCustomMonsterEffect.m_MonsterEffect.end()) {
		monsterInfo.m_Effects.push_back(glowInfo);

		gCustomMonsterEffect.m_MonsterEffect.insert(std::make_pair(MonsterModel, monsterInfo));
	}
	else {
		it->second.m_Effects.push_back(glowInfo);
	}
}

static void CreateEffectMonster(DWORD ObjectStruct, DWORD model) {
	if (ObjectStruct == 0 || model == 0) {
		return;
	}
	auto monsterEffect = gCustomMonsterEffect.getMonsterEffect(*(DWORD *)(ObjectStruct + 48));

	if (monsterEffect != nullptr) {
		vec3_t p, Position, Light;

		for (const auto& effect : monsterEffect->m_Effects) {
			vec34_t* BoneTransform = &*(vec34_t*)((DWORD(__thiscall*)(DWORD, int))0x4CD7F0)(ObjectStruct, effect.Bone);

			if (BoneTransform) {
				if (effect.Rand != 100) {
					if ((rand() % 100) > effect.Rand) {
						continue;
					}
				}

				Vector(0.0f, 0.0f, 0.0f, p);
				Vector(effect.R, effect.G, effect.B, Light);

				((void(__thiscall*)(void*, vec34_t, vec3_t, vec3_t, bool))0x545030)((void*)model, BoneTransform[0], p, Position, 1);

				if (effect.Type == 1) {
					((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, DWORD))0x74CD30)(effect.EffectID, Position, *(vec3_t*)(ObjectStruct + 254), Light, effect.EffectLv, effect.Size, ObjectStruct);
				}
				else {
					((void(*)(int, vec3_t, float, vec3_t, DWORD, float, int))0x771310)(effect.EffectID, Position, effect.Size, Light, ObjectStruct, effect.Black, 0);
				}
			}
		}
	}
}

__declspec(naked) void CreateMonsterEffect() {
	static DWORD m_ReturnFunc = 0x0056FC6B;

	static DWORD m_ObjectStruct = 0;
	static DWORD m_ModelStruct = 0;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP - 0x4C];
		MOV m_ModelStruct, ECX;
		MOV EDX, DWORD PTR SS : [EBP + 0xC]
		MOV m_ObjectStruct, EDX;
	}

	CreateEffectMonster(m_ObjectStruct, m_ModelStruct);

	_asm {
		MOVSX EAX, WORD PTR DS : [EDX + 0x84];
		CMP EAX, 0x26;
		JMP[m_ReturnFunc];
	}
}

void CCustomMonsterEffect::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetMonsterEffect", SetMonsterEffect);

	this->m_Lua.DoFile("Data//Files//Lua//Monster//CustomMonsterEffect.lua");

	SetCompleteHook(0xE9, 0x0056FC61, &CreateMonsterEffect);
}

void CCustomMonsterEffect::RestartLua()
{
	LuaModule(this->m_Lua.GetState()).fun("SetMonsterEffect", SetMonsterEffect);

	this->m_Lua.DoFile("Data//Files//Lua//Monster//CustomMonsterEffect.lua");

	SetCompleteHook(0xE9, 0x0056FC61, &CreateMonsterEffect);
}

CUSTOM_MONSTER_EFFECT * CCustomMonsterEffect::getMonsterEffect(int Type)
{
	auto it = this->m_MonsterEffect.find(Type);

	if (it == this->m_MonsterEffect.end()) {
		return nullptr;
	}

	return &it->second;
}
