// stdafx.cpp : source file that includes just the standard includes
// Main_X601.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file

#pragma comment (lib, "User32.lib")
#pragma comment (lib, "Winmm.lib")
#pragma comment (lib, "Opengl32.lib")
#pragma comment (lib, "ws2_32.lib")

#pragma comment (lib, "lua51.lib")
