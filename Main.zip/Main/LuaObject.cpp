#include "stdafx.h"
#include "LuaObject.h"
#include "LuaStack.hpp"

class ObjectClass {
public:
	ObjectClass() : m_Struct(0) {

	};

	ObjectClass(DWORD Struct) {
		this->m_Struct = Struct;
	};

	~ObjectClass() {

	};

	float Alpha() const {
		return *(float *)(this->m_Struct + 152);
	};

	DWORD Mesh() const {
		return *(DWORD *)(this->m_Struct + 68);
	};

	float Light() const {
		return *(float *)(this->m_Struct + 100);
	};

	float TexCoordU() const {
		return *(float *)(this->m_Struct + 104);
	};

	float TexCoordV() const {
		return *(float *)(this->m_Struct + 108);
	};

	DWORD Hidden() const {
		return *(DWORD *)(this->m_Struct + 60);
	};

	int getAction() const {
		return *(WORD *)(this->m_Struct + 0x12);
	};

	float getTime() const {
		return *(float *)(this->m_Struct + 112);
	};

	void setTime(float value) const {
		*(float *)(this->m_Struct + 112) = value;
	};

private:
	DWORD m_Struct;
};

float worldTime() {
	return *(float*)0x5EF5A1C;
}

float GetDoubleRender(float a1, float a2) {
	float Return;
	float InitValue;

	InitValue = (float)((int32_t)(a2 * 0.01745f * 1000.0f / a1 + *(float*)0x5EF5A1C) % (int32_t)(6283.185546875f / a1)) * 0.001f * a1;

	if (InitValue >= 3.14f)
	{
		Return = cos(InitValue);
	}
	else
	{
		Return = -cos(InitValue);
	}

	return (float)((Return + 1.0f) * 0.5f);
}

void RegisterClassObject(lua_State * lua)
{
	luaaa::LuaClass<ObjectClass> luaObject(lua, "Object");
	luaObject.ctor<DWORD>();
	luaObject.fun("Alpha", &ObjectClass::Alpha);
	luaObject.fun("Mesh", &ObjectClass::Mesh);
	luaObject.fun("Light", &ObjectClass::Light);
	luaObject.fun("TexCoordU", &ObjectClass::TexCoordU);
	luaObject.fun("TexCoordV", &ObjectClass::TexCoordV);
	luaObject.fun("Hidden", &ObjectClass::Hidden);
	luaObject.fun("getAction", &ObjectClass::getAction);
	luaObject.fun("getTime", &ObjectClass::getTime);
	luaObject.fun("setTime", &ObjectClass::setTime);

	luaaa::LuaModule(lua).fun("worldTime", &worldTime);
	luaaa::LuaModule(lua).fun("GetDoubleRender", &GetDoubleRender);
}
