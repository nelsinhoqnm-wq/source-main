#pragma once

void InterfaceRemakeLoad();
void BarSystemLoad();
double RenderNumberRemake(float a1, float a2, int a3, float a4, float a5);
#define pRender_rendertext			((int(__thiscall*)(int thisa, int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth , int iBoxHeight , int iSort, OUT SIZE * lpTextSize)) 0x00420150)
#define g_Fontthis					((int(__thiscall*)( )) 0x0041FE10)
#define GetInstance					((int(__cdecl*)()) 0x00861110)
#define sub_7798F0					((char(__thiscall*)(int This, char a9))0x007798F0)
#define pSliderSetPosition			((int(__thiscall*)(DWORD This,int X,int Y)) 0x00417EC0) 
#define pCheckMouseOver				((bool(__cdecl*)(int a1, int a2, int a3, int a4)) 0x00790B10)
#define PlayBuffer					((signed int(__cdecl*)(int a1, int a2, int a3)) 0x006D6C20)
#define sub_813DC0					((int(__thiscall*)(DWORD * This, int Skill, float X, float Y, float W, float H)) 0x00813DC0)
#define sub_4C8640					((bool(__thiscall*)(void * This,char a2)) 0x4C8640)
#define sub_4200F0_Addr				((int(__thiscall*)(LPVOID a1, int a2)) 0x4200F0)
#define getWindowConfig_35			((int(__thiscall*)(int This))0x00861620)
#define GetInventory				((int(__thiscall*)(int This))0x00861260)
#define pWinWidth					*(GLsizei*)0x0E61E58
#define pWinHeight					*(GLsizei*)0x0E61E5C
#define pWinWidthReal				*(float*)0xE7C3D4
#define pWinWidthReal2				1.5f
#define pWinHeightReal				*(float*)0xE7C3D8
#define pWinHeightReal2				1.25f
#define pWinFontHeight				*(int*)0x81C0380
#define	pFontNormal					*(HGDIOBJ*)0x00E8C588
#define pFontBold					*(HGDIOBJ*)0x00E8C58C
#define pFontBigBold				*(HGDIOBJ*)0x00E8C590
#define pFontNormal2				*(HGDIOBJ*)0x00E8C594
#define pSetFont					((int(__thiscall*)(LPVOID This, int a2)) 0x420120)
#define g_pNewUISystem				((int(*)()) 0x861110)
#define sub_861200					((int(__thiscall*)(int This)) 0x861200)
#define sub_815000					((char(__thiscall*)(int This)) 0x815000)
#define SetTextColorByHDC			((int(__thiscall*)(LPVOID a1, int color)) 0x420080)
#define pGetStrutParty( x )			(*(PartyList*)(0x81CB4E8 + 32 * x))
#define pMakeColor					((DWORD(__cdecl*)(BYTE, BYTE, BYTE, BYTE)) 0x00412D20)