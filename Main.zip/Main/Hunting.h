#pragma once

#include "Protocol.h"

struct PMSG_CHARACTER_HUNTING_INFO_RECV
{
	PSBMSG_HEAD header;	// C1:0B
	WORD level;
	QWORD experienceNow;
	QWORD lastExperience;
	float experience;
	float media;
	DWORD lastZen;
	float mediaZen;
};

class Hunting {
public:
	Hunting();
	~Hunting();

	void ReceiveHunting(PMSG_CHARACTER_HUNTING_INFO_RECV* lpMsg);

	QWORD experienceNow;
	QWORD lastExperience;
	float experience;
	float media;
	DWORD lastZen;
	float mediaZen;
	std::string expperMinute;
	std::string expNow;
	std::string LastExp;
	std::string mediaZenc;
	std::string lastZenc;

	WORD level;
};

extern Hunting gHunting;