#include "stdafx.h"
#include "MenuWindow.h"
#include "Util.h"
#include "Interface.h"
#include "CreateFont.h"

#pragma comment (lib, "Gdi32.lib")

CMenuWindow gMenuWindow;

CMenuWindow::CMenuWindow()
{
	this->m_HealthBarDisabled = 0;
	this->m_ShadowDisabled = 0;
	this->m_WingDisabled = 0;
}

CMenuWindow::~CMenuWindow()
{

}

__declspec(naked) void ChangeViewItem() {
	static DWORD m_ReturnFunc = 0x00772954;

	static int WindowWidth = *(int*)MAIN_RESOLUTION_X;
	static int WindowHeight = *(int*)MAIN_RESOLUTION_Y;

	_asm {
		MOV EAX, WindowWidth;

		MOV ECX, DWORD PTR SS : [EBP - 0x20];
		MOV DWORD PTR DS : [ECX + 0x48], EAX;

		MOV EAX, WindowHeight;

		MOV ECX, DWORD PTR SS : [EBP - 0x20];
		MOV DWORD PTR DS : [ECX + 0x4C], EAX;


		MOV ECX, DWORD PTR SS : [EBP - 0x20];
		MOV EDX, DWORD PTR DS : [ECX + 0x4C];

		JMP[m_ReturnFunc]
	}
}

void glViewport2(int x, int y, int Width, int Height) {
	((void(*)(int, int, int, int))0x6363D0)(x, y, *(int*)MAIN_RESOLUTION_X, *(int*)MAIN_RESOLUTION_Y);
}

void gluPerspective2(float a1, float a2, float a3, float a4) {
	float aspect = *(float*)MAIN_RESOLUTION_X / *(float*)MAIN_RESOLUTION_Y;

	((void(*)(float, float, float, float))0x6358A0)(a1, aspect, a3, a4);
}

void CMenuWindow::Init() {
	SetCompleteHook(0xE8, 0x007729B3, &gluPerspective2);
	SetCompleteHook(0xE8, 0x00772960, &glViewport2);
}

DWORD g_dwCharSet[8] = { HANGUL_CHARSET, DEFAULT_CHARSET, CHINESEBIG5_CHARSET, GB2312_CHARSET, SHIFTJIS_CHARSET, THAI_CHARSET, DEFAULT_CHARSET, VIETNAMESE_CHARSET };

void CMenuWindow::ChangeFontSize(int fontSize, bool resolution)
{
	if (resolution == 0) {
		/*if (fontSize == *(int*)MAIN_FONT_SIZE) {
			return;
		}*/
	}

	if (g_hFont) {
		DeleteObject((HGDIOBJ)g_hFont);
	}

	if (g_hFontBold) {
		DeleteObject((HGDIOBJ)g_hFontBold);
	}

	if (g_hFontBig) {
		DeleteObject((HGDIOBJ)g_hFontBig);
	}

	if (g_hFontFix) {
		DeleteObject((HGDIOBJ)g_hFontFix);
	}

	SetDword(MAIN_FONT_SIZE, fontSize);

	int newfontSize = fontSize - 1;

	g_hFont = CreateFont(newfontSize + gCreateFont.m_fontInfo[0].AddSize, 0, 0, 0, (gCreateFont.m_fontInfo[0].Bold == 1 ? FW_BOLD : FW_NORMAL), 0, 0, 0,
		gCreateFont.m_fontInfo[0].CharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		NONANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		gCreateFont.m_fontInfo[0].Name.c_str());

	g_hFontBold = CreateFont(newfontSize + gCreateFont.m_fontInfo[1].AddSize, 0, 0, 0, (gCreateFont.m_fontInfo[1].Bold == 1 ? FW_BOLD : FW_NORMAL), 0, 0, 0,
		gCreateFont.m_fontInfo[1].CharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		NONANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		gCreateFont.m_fontInfo[1].Name.c_str());

	g_hFontBig = CreateFont((newfontSize * 2) + gCreateFont.m_fontInfo[2].AddSize, 0, 0, 0, (gCreateFont.m_fontInfo[2].Bold == 1 ? FW_BOLD : FW_NORMAL), 0, 0, 0,
		gCreateFont.m_fontInfo[2].CharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		NONANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		gCreateFont.m_fontInfo[2].Name.c_str());

	g_hFontFix = CreateFont(12 + gCreateFont.m_fontInfo[3].AddSize, 0, 0, 0, (gCreateFont.m_fontInfo[3].Bold == 1 ? FW_BOLD : FW_NORMAL), 0, 0, 0,
		gCreateFont.m_fontInfo[3].CharSet, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		NONANTIALIASED_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		gCreateFont.m_fontInfo[3].Name.c_str());
}

void LoadTexture(char * text) {
	static DWORD m_CallGlobal = 0x006346A0;

	_asm {
		PUSH 0x80000001;
		MOV EAX, text;
		PUSH EAX;
		MOV ECX, 0x08128ADC;
		CALL[m_CallGlobal];
	}
}

void CMenuWindow::ChangeLanguage(char * lang)
{
	char buffer[256];

	sprintf_s(buffer, "Data\\Local\\%s\\Dialog_%s.bmd", lang, lang);
	((void(*)(char*))0x58A940)(buffer);

	sprintf_s(buffer, "Data\\Local\\%s\\Item_%s.bmd", lang, lang);
	((void(*)(char*))0x58B200)(buffer);

	//((void(__thiscall*)(LPVOID))0x51ACE0)(((LPVOID(*)())0x51ABB0)());

	//sprintf_s(buffer, "Data\\Local\\%s\\movereq_%s.bmd", lang, lang);
	//((void(*)(char*))0x51AD60)(buffer);

	//((void(*)(HDC))0x6316C0)(gInterface.hdc);

	//sprintf_s(buffer, "Data\\Local\\%s\\movereq_%s.bmd", lang, lang);
	//((void(__thiscall*)(DWORD))0x51AC20)((DWORD)buffer);

	/*sprintf_s(buffer, "Data\\Local\\%s\\NpcName(%s)%s.bmd", lang, lang);
	((void(*)(char*))0x590D00)(buffer);

	sprintf_s(buffer, "Data\\Local\\%s\\Quest_%s.bmd", lang, lang);
	((void(*)(DWORD, char*))0x4F33F0)(((DWORD(*)())0x5BE390)(), buffer);

	sprintf_s(buffer, "Data\\Local\\%s\\Skill_%s.bmd", lang, lang);
	((void(*)(char*))0x58A3F0)(buffer);*/

	//((void(__thiscall*)(LPVOID))0x596980)(((LPVOID(__thiscall*)()0x596910)());

	((void(*)())0x00D20470)();

	((void(*)())0x6345A0)();

	//Itemtooltip
	((void(__thiscall*)(LPVOID, bool))0x7E7940)(((LPVOID(__thiscall*)(LPVOID))0x861AA0)(pWindowThis()), 0);

	((void(__thiscall*)(LPVOID))0x7E3000)(((LPVOID(__thiscall*)(LPVOID))0x861AA0)(pWindowThis()));


	//((void(*)())0x7E3000)();

}

void CMenuWindow::ChangeResolution(int value)
{
	switch (value)
	{
	case 0:*(int*)MAIN_RESOLUTION_X = 640; *(int*)MAIN_RESOLUTION_Y = 480; *(int*)MAIN_FONT_SIZE = 12; break;
	case 1:*(int*)MAIN_RESOLUTION_X = 800; *(int*)MAIN_RESOLUTION_Y = 600; *(int*)MAIN_FONT_SIZE = 13; break;
	case 2:*(int*)MAIN_RESOLUTION_X = 1024; *(int*)MAIN_RESOLUTION_Y = 768; *(int*)MAIN_FONT_SIZE = 14; break;
	case 3:*(int*)MAIN_RESOLUTION_X = 1280; *(int*)MAIN_RESOLUTION_Y = 1024;  *(int*)MAIN_FONT_SIZE = 15; break;
	case 4:*(int*)MAIN_RESOLUTION_X = 1366; *(int*)MAIN_RESOLUTION_Y = 768;  *(int*)MAIN_FONT_SIZE = 15; break;
	case 5:*(int*)MAIN_RESOLUTION_X = 1440; *(int*)MAIN_RESOLUTION_Y = 900; *(int*)MAIN_FONT_SIZE = 15; break;
	case 6:*(int*)MAIN_RESOLUTION_X = 1600; *(int*)MAIN_RESOLUTION_Y = 900;  *(int*)MAIN_FONT_SIZE = 15; break;
	case 7:*(int*)MAIN_RESOLUTION_X = 1680; *(int*)MAIN_RESOLUTION_Y = 1050;  *(int*)MAIN_FONT_SIZE = 15; break;
	case 8:*(int*)MAIN_RESOLUTION_X = 1920; *(int*)MAIN_RESOLUTION_Y = 1080;  *(int*)MAIN_FONT_SIZE = 15; break;
	default:
		*(int*)MAIN_RESOLUTION_X = 1024; *(int*)MAIN_RESOLUTION_Y = 768; break;
	}

	this->ChangeFontSize(*(int*)MAIN_FONT_SIZE, 1);

	*(DWORD*)((DWORD)((LPVOID(*)()) 0x407B20)() + 40) = *(int*)MAIN_RESOLUTION_X;
	*(DWORD*)((DWORD)((LPVOID(*)()) 0x407B20)() + 44) = *(int*)MAIN_RESOLUTION_Y;

	*(float*)0xE7C3D4 = (float)*(int*)MAIN_RESOLUTION_X / 640;
	*(float*)0xE7C3D8 = (float)*(int*)MAIN_RESOLUTION_Y / 480;

	RECT rc = { 0, 0, *(int*)MAIN_RESOLUTION_X, *(int*)MAIN_RESOLUTION_Y };

	//Window Resolution
	if (*(DWORD*)0xE60974) {
		AdjustWindowRect(&rc, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_BORDER | WS_CLIPCHILDREN, NULL);

		rc.right -= rc.left;
		rc.bottom -= rc.top;

		SetWindowLong(MAIN_WINDOW, GWL_STYLE, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_BORDER | WS_CLIPCHILDREN);

		SetWindowPos(MAIN_WINDOW, HWND_NOTOPMOST, (GetSystemMetrics(SM_CXSCREEN) - rc.right) / 2, 
			(GetSystemMetrics(SM_CYSCREEN) - rc.bottom) / 2,
			rc.right,
			rc.bottom, SWP_SHOWWINDOW);
	}
	else {
		AdjustWindowRect(&rc, WS_OVERLAPPEDWINDOW, NULL);

		SetWindowPos(MAIN_WINDOW, HWND_NOTOPMOST, 0,
			0,
			rc.right,
			rc.bottom, SWP_SHOWWINDOW);
	}

	//Set font
	((void(__thiscall*)(LPVOID))0x41FF20)(pTextThis());

	((void(__thiscall*)(LPVOID, int, HDC))0x41FE80)(pTextThis(), 0, MAIN_HDC);

	SetDouble(0x00D2C848, 2000.f);

	SetDouble(0x00D2C898, 2000.f);

	//Chat input
	((void(__thiscall*)(LPVOID))0x785B70)(pChatThis(pWindowThis()));

	((void(__thiscall*)(DWORD, DWORD, DWORD, DWORD, DWORD))0x785870)(*(DWORD*)((DWORD)pWindowThis() + 12), *(DWORD*)(pWindowThis()), *(DWORD*)((DWORD)pWindowThis() + 16), 0, 382);

	//Macro ui
	((void(__thiscall*)(LPVOID))0x7D2530)((LPVOID)(*(DWORD*)((DWORD)pWindowThis() + 152)));

	LPVOID Struct = ((LPVOID(*)(DWORD))0x9D00C5)(552);
	LPVOID HeroPosition = 0;

	if (Struct) {
		HeroPosition = ((LPVOID(__thiscall*)(LPVOID))0x7D2480)(Struct);
	}
	else {
		HeroPosition = 0;
	}

	*(DWORD *)((DWORD)pWindowThis() + 152) = (DWORD)HeroPosition;

	if (HeroPosition) {
		((void(__thiscall*)(LPVOID, DWORD, DWORD, DWORD))0x7D25C0)(HeroPosition, *(DWORD*)(pWindowThis()), 0, 0);
	}

	//PersonalShop
	((void(__thiscall*)(DWORD))0x840A60)(*(DWORD *)((DWORD)pWindowThis() + 84));
	((void(__thiscall*)(LPVOID, DWORD, DWORD, DWORD))0x840610)((LPVOID)*(DWORD *)((DWORD)pWindowThis() + 84), *(DWORD*)(pWindowThis()), 260, 0);
}
