#pragma once

#include "Lua.h"
#include "LuaUser.h"

class CDescriptions {
public:
	CDescriptions();
	~CDescriptions();
	void RestartLua();

	void Init();

public:
	Lua m_Lua;
	CLuaUser m_LuaUser;
};

extern CDescriptions gDescriptions;

extern arraytooltip * textLine;
extern int * textColor;
extern int * textBold;