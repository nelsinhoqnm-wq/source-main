#include "stdafx.h"
#include "CustomMonsterGlow.h"
#include "CustomMonsterEffect.h"
#include "Console.h"
#include "LuaStack.hpp"

using namespace luaaa;

CCustomMonsterGlow gCustomMonsterGlow;

CCustomMonsterGlow::CCustomMonsterGlow() : m_Lua(true)
{
	this->m_CustomMonsterGlow.clear();
}

CCustomMonsterGlow::~CCustomMonsterGlow()
{
	this->m_CustomMonsterGlow.clear();
}

void SetMonsterGlow(int MonsterID, int Layer, int MeshType, int R, int G, int B) {
	int ModelMonster = MonsterID + 644;

	CUSTOM_MONSTER_GLOW monsterInfo;

	monsterInfo.MonsterID = ModelMonster;

	CUSTOM_MONSTER_GLOW_INFO glowInfo;

	glowInfo.Layer = Layer;

	glowInfo.MeshType = MeshType;

	glowInfo.R = R;

	glowInfo.G = G;

	glowInfo.B = B;

	auto it = gCustomMonsterGlow.m_CustomMonsterGlow.find(ModelMonster);

	if (it == gCustomMonsterGlow.m_CustomMonsterGlow.end()) {
		monsterInfo.m_Glow.push_back(glowInfo);

		gCustomMonsterGlow.m_CustomMonsterGlow.insert(std::make_pair(ModelMonster, monsterInfo));
	}
	else {
		it->second.m_Glow.push_back(glowInfo);
	}
}

void CCustomMonsterGlow::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetMonsterGlow", SetMonsterGlow);

	this->m_Lua.DoFile("Data//Files//Lua//Monster//CustomMonsterGlow.lua");

	SetCompleteHook(0xE8, 0x008C5BB5, &this->RenderAidaMonsterObjectMesh);
}

CUSTOM_MONSTER_GLOW * CCustomMonsterGlow::getMonsterGlow(int Type)
{
	auto it = this->m_CustomMonsterGlow.find(Type);

	if (it == this->m_CustomMonsterGlow.end()) {
		return nullptr;
	}

	return &it->second;
}

bool CCustomMonsterGlow::RenderAidaMonsterObjectMesh(DWORD obj, DWORD model)
{
	auto monsterGlow = gCustomMonsterGlow.getMonsterGlow(*(DWORD *)(obj + 48));

	if (monsterGlow) {
		((void(*)(float))0x546860)(1.0);

		for (int n = 0; n < 8; n++)
		{
			((void(__thiscall*)(DWORD*, int, int, float, int, float, float, float, int))0x5468A0)((DWORD*)model, n, 2, *(float *)(obj + 152), *(DWORD *)(obj + 68), *(float *)(obj + 100), *(float *)(obj + 104), *(float *)(obj + 108), -1);
		}

		for (const auto& glow : monsterGlow->m_Glow) {
			*(float *)(model + 72) = (float)(glow.R / 255.0f);
			*(float *)(model + 76) = (float)(glow.G / 255.0f);
			*(float *)(model + 80) = (float)(glow.B / 255.0f);
			*(float *)(model + 100) = (float)(glow.R / 255.0f);
			*(float *)(model + 104) = (float)(glow.G / 255.0f);
			*(float *)(model + 108) = (float)(glow.B / 255.0f);

			((void(__thiscall*)(DWORD*, int, int, float, int, float, float, float, int))0x5468A0)((DWORD*)model, glow.Layer, glow.MeshType, *(float *)(obj + 152), *(DWORD *)(obj + 68), *(float *)(obj + 100), *(float *)(obj + 104), *(float *)(obj + 108), -1);
		}

		((void(*)())0x546880)();
		return true;
	}

	return ((bool(*)(DWORD, DWORD))0x8CA230)(obj, model);
}
