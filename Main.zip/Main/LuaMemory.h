#pragma once

#include "Util.h"

class LuaMemory {
public:
	LuaMemory();
	~LuaMemory();

	void RegisterLua(lua_State* lua);
};