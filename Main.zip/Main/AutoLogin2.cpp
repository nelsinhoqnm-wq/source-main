#include "StdAfx.h"
#include "AutoLogin2.h"
#include "Reconnect.h"
#include "Util.h"
#include "LoadFiles.h"

static BYTE EncDecKey1[3] = { 0x57, 0xE9, 0x22 };
static BYTE EncDecKey2[3] = { 0x94, 0xC7, 0x84 };

CAutoLogin gAutoLogin;

CAutoLogin::CAutoLogin() {
	std::memset(this->m_PassAccount, 0, sizeof(this->m_PassAccount));

	std::memset(this->m_CharAccount, 0, sizeof(this->m_CharAccount));

	std::memset(this->m_ServerIPAddress, 0, sizeof(this->m_ServerIPAddress));

	std::memset(this->m_SavePassAccount, 0, sizeof(this->m_SavePassAccount));

	std::memset(this->m_SaveCharAccount, 0, sizeof(this->m_SaveCharAccount));

	std::memset(this->m_SaveServerIPAddress, 0, sizeof(this->m_SaveServerIPAddress));

	this->m_ServerPORT = 0;

	this->m_AutoLogin = 0;

	this->m_Load = 0;

	this->m_FirstLogin = 0;

	this->m_ConnectingAutoLogin = 0;

	this->m_AutoLoginConnected = 0;

	this->m_CancelAutoLogin = 0;

	this->m_ThisAutoLogin = 0;
}

CAutoLogin::~CAutoLogin() {
	this->Save();
}

void CAutoLogin::EncryptString(char* out_buff, char* in_buff, int size)
{
	for (int n = 0; n < size; n++)
	{
		out_buff[n] = in_buff[n] ^ EncDecKey1[n % 3];
	}
}

void CAutoLogin::DecryptString(char* out_buff, char* in_buff, int size)
{
	for (int n = 0; n < size; n++)
	{
		out_buff[n] = in_buff[n] ^ EncDecKey1[n % 3];
	}
}

void CAutoLogin::Load() {
	HKEY key;

	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
	{
		char buffPass[11];

		DWORD type = REG_SZ, size = sizeof(buffPass);

		if (RegQueryValueEx(key, "PassAccount", 0, NULL, (LPBYTE)&buffPass, &size) != ERROR_SUCCESS) {
			if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
				RegSetValueExA(key, "PassAccount", 0, REG_SZ, (LPBYTE)&buffPass, sizeof(buffPass));
			}
		}
		else {
			DecryptString(this->m_PassAccount, buffPass, strlen(buffPass));
		}
	}

	RegCloseKey(key);

	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
	{
		DWORD type = REG_SZ, size = sizeof(this->m_LoginAccount);

		RegQueryValueEx(key, "ID", 0, NULL, (LPBYTE)&this->m_LoginAccount, &size);
	}

	RegCloseKey(key);

	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
	{
		char buffChar[11];

		DWORD type = REG_SZ, size = sizeof(buffChar);

		if (RegQueryValueEx(key, "CharAccount", 0, NULL, (LPBYTE)&buffChar, &size) != ERROR_SUCCESS) {
			if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
				RegSetValueExA(key, "CharAccount", 0, REG_SZ, (LPBYTE)&buffChar, sizeof(buffChar));
			}
		}
		else {
			DecryptString(this->m_CharAccount, buffChar, sizeof(buffChar));
		}
	}

	RegCloseKey(key);

	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
	{
		char buffIP[17];

		DWORD type = REG_SZ, size = sizeof(buffIP);

		if (RegQueryValueEx(key, "ServerIpAddress", 0, NULL, (LPBYTE)&buffIP, &size) != ERROR_SUCCESS) {
			if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
				RegSetValueExA(key, "ServerIpAddress", 0, REG_SZ, (LPBYTE)&buffIP, sizeof(buffIP));
			}
		}
		else {
			DecryptString(this->m_ServerIPAddress, buffIP, sizeof(buffIP));
		}
	}

	RegCloseKey(key);

	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
	{
		DWORD type = REG_DWORD, size = sizeof(this->m_ServerPORT);

		if (RegQueryValueEx(key, "ServerPORT", 0, NULL, (LPBYTE)&this->m_ServerPORT, &size) != ERROR_SUCCESS) {
			if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
				RegSetValueExA(key, "ServerPORT", 0, REG_DWORD, (LPBYTE)&m_ServerPORT, sizeof(m_ServerPORT));
			}
		}

	}

	RegCloseKey(key);

	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
	{
		DWORD type = REG_DWORD, size = sizeof(this->m_AutoLogin);

		if (RegQueryValueEx(key, "AutoLogin", 0, NULL, (LPBYTE)&this->m_AutoLogin, &size) != ERROR_SUCCESS) {
			if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
				RegSetValueExA(key, "AutoLogin", 0, REG_DWORD, (LPBYTE)&m_AutoLogin, sizeof(m_AutoLogin));
			}
		}

		if (strlen(m_PassAccount) > 0) {
			this->m_Load = 1;
		}
	}

	RegCloseKey(key);

	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
	{
		DWORD type = REG_DWORD, size = sizeof(this->m_ThisAutoLogin);

		if (RegQueryValueEx(key, "AutoLoginLogged", 0, NULL, (LPBYTE)&this->m_ThisAutoLogin, &size) != ERROR_SUCCESS) {
			if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
				this->m_ThisAutoLogin = 1;
				RegSetValueExA(key, "AutoLoginLogged", 0, REG_DWORD, (LPBYTE)&m_ThisAutoLogin, sizeof(m_ThisAutoLogin));
			}
		}
		else {
			if (!this->m_ThisAutoLogin) {
				this->m_ThisAutoLogin = 1;
				RegSetValueExA(key, "AutoLoginLogged", 0, REG_DWORD, (LPBYTE)&m_ThisAutoLogin, sizeof(m_ThisAutoLogin));
			}
			else {
				this->m_ThisAutoLogin = 0;
			}
		}
	}

	RegCloseKey(key);

	if (strcmp(this->m_ServerIPAddress, gLoadFiles.m_LoadFiles.m_IpServer) != 0) {
		this->m_AutoLogin = 0;
		this->m_ThisAutoLogin = 0;

		DWORD m_OffAutoLogin = 0;

		if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
		{
			if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
				RegSetValueExA(key, "AutoLoginLogged", 0, REG_DWORD, (LPBYTE)&m_OffAutoLogin, sizeof(m_OffAutoLogin));
			}
			else {
				RegSetValueExA(key, "AutoLoginLogged", 0, REG_DWORD, (LPBYTE)&m_OffAutoLogin, sizeof(m_OffAutoLogin));
			}
		}

		RegCloseKey(key);
	}

	//SetCompleteHook(0xE8, 0x004D349F, &this->RenderMainScene);
	//SetCompleteHook(0xE8, 0x004D34BE, &this->RenderMainScene);
	//
	//SetCompleteHook(0xE8, 0x00663EC3, &this->CharacterInfoRecv);
	//
	//SetCompleteHook(0xE8, 0x004CF567, &this->DestroyWindow);
	//SetCompleteHook(0xE8, 0x004D35E0, &this->DestroyWindow);
	//SetCompleteHook(0xE8, 0x00772559, &this->DestroyWindow);
}

void CAutoLogin::Save()
{
	HKEY key;

	if (this->m_ThisAutoLogin) {
		DWORD m_OffAutoLogin = 0;

		if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
		{
			if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
				RegSetValueExA(key, "AutoLoginLogged", 0, REG_DWORD, (LPBYTE)&m_OffAutoLogin, sizeof(m_OffAutoLogin));
			}
			else {
				RegSetValueExA(key, "AutoLoginLogged", 0, REG_DWORD, (LPBYTE)&m_OffAutoLogin, sizeof(m_OffAutoLogin));
			}
		}

		RegCloseKey(key);
	}

	if (m_AutoLogin == 0) {
		return;
	}

	if (!this->m_ThisAutoLogin) {
		return;
	}

	if (strlen(this->m_SaveCharAccount) <= 0
		|| strlen(this->m_SaveLoginAccount) <= 0
		|| strlen(this->m_SavePassAccount) <= 0) {
		return;
	}

	if (strlen(gAutoLogin.m_PassAccount) > 0 && strlen(gAutoLogin.m_LoginAccount) > 0 && strlen(gAutoLogin.m_CharAccount) > 0
		&& this->m_Load) {
		if (strcmp(this->m_PassAccount, this->m_SavePassAccount) == 0
			&& strcmp(this->m_LoginAccount, this->m_SaveLoginAccount) == 0
			&& strcmp(this->m_CharAccount, this->m_SaveCharAccount) == 0
			&& strcmp(this->m_ServerIPAddress, this->m_SaveServerIPAddress) == 0
			&& this->m_ServerPORT == this->m_SaveServerPORT) {
			return;
		}
	}

	if (RegOpenKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, KEY_ALL_ACCESS, &key) == ERROR_SUCCESS)
	{
		this->EncryptString(m_SavePassAccount, m_SavePassAccount, sizeof(m_SavePassAccount));

		if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
			RegSetValueExA(key, "PassAccount", 0, REG_SZ, (LPBYTE)&m_SavePassAccount, sizeof(m_SavePassAccount));
		}
		else {
			RegSetValueExA(key, "PassAccount", 0, REG_SZ, (LPBYTE)&m_SavePassAccount, sizeof(m_SavePassAccount));
		}

		this->EncryptString(m_SaveCharAccount, m_SaveCharAccount, sizeof(m_SaveCharAccount));

		if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
			RegSetValueExA(key, "CharAccount", 0, REG_SZ, (LPBYTE)&m_SaveCharAccount, sizeof(m_SaveCharAccount));
		}
		else {
			RegSetValueExA(key, "CharAccount", 0, REG_SZ, (LPBYTE)&m_SaveCharAccount, sizeof(m_SaveCharAccount));
		}

		this->EncryptString(m_SaveServerIPAddress, m_SaveServerIPAddress, sizeof(m_SaveServerIPAddress));

		if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
			RegSetValueExA(key, "ServerIpAddress", 0, REG_SZ, (LPBYTE)&m_SaveServerIPAddress, sizeof(m_SaveServerIPAddress));
		}
		else {
			RegSetValueExA(key, "ServerIpAddress", 0, REG_SZ, (LPBYTE)&m_SaveServerIPAddress, sizeof(m_SaveServerIPAddress));
		}

		if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
			RegSetValueExA(key, "ServerPORT", 0, REG_DWORD, (LPBYTE)&m_SaveServerPORT, sizeof(m_SaveServerPORT));
		}
		else {
			RegSetValueExA(key, "ServerPORT", 0, REG_DWORD, (LPBYTE)&m_SaveServerPORT, sizeof(m_SaveServerPORT));
		}

		if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Webzen\\Mu\\Config", 0, 0, 0, KEY_WRITE, 0, &key, NULL) == ERROR_SUCCESS) {
			RegSetValueExA(key, "ID", 0, REG_SZ, (LPBYTE)&m_SaveLoginAccount, sizeof(m_SaveLoginAccount));
		}
		else {
			RegSetValueExA(key, "ID", 0, REG_SZ, (LPBYTE)&m_SaveLoginAccount, sizeof(m_SaveLoginAccount));
		}
	}

	RegCloseKey(key);
}

void CAutoLogin::RegisterAutoLogin(char * account, char * password, char * character, char * serverip, WORD serverport)
{
	std::memcpy(this->m_SaveLoginAccount, account, sizeof(this->m_SaveLoginAccount));

	std::memcpy(this->m_SavePassAccount, password, sizeof(this->m_SavePassAccount));

	std::memcpy(this->m_SaveServerIPAddress, serverip, sizeof(this->m_SaveServerIPAddress));

	std::memcpy(this->m_SaveCharAccount, character, sizeof(this->m_SaveCharAccount));

	this->m_SaveServerPORT = serverport;
}

void CAutoLogin::RenderMainScene(HDC hdc)
{
	if (gAutoLogin.m_AutoLogin && !gAutoLogin.m_CancelAutoLogin && !gAutoLogin.m_AutoLoginConnected && gAutoLogin.m_ThisAutoLogin) {
		if (strlen(gAutoLogin.m_PassAccount) > 0 && strlen(gAutoLogin.m_LoginAccount) > 0 && strlen(gAutoLogin.m_CharAccount) > 0) {
			if (gAutoLogin.m_FirstLogin == 0) {
				if (*(DWORD*)(MAIN_SCREEN_STATE) == 2) {
					gAutoLogin.m_ConnectingAutoLogin = 1;
	
					SetDword(MAIN_SCREEN_STATE, 5);
	
					gAutoLogin.m_FirstLogin = 1;
	
					std::memcpy(ReconnectPassword, gAutoLogin.m_PassAccount, sizeof(ReconnectPassword));
	
					std::memcpy(ReconnectAccount, gAutoLogin.m_LoginAccount, sizeof(ReconnectAccount));
	
					std::memcpy(GameServerAddress, gAutoLogin.m_ServerIPAddress, sizeof(GameServerAddress));
	
					GameServerPort = gAutoLogin.m_ServerPORT;
	
					ReconnectOnCloseSocket();
	
					std::memcpy(ReconnectName, gAutoLogin.m_CharAccount, sizeof(ReconnectName));
	
					ReconnecGameServerLoad();
				}
			}
			else {
				if (gAutoLogin.m_AutoLoginConnected == 0) {
					ReconnectMainProc();
				}
			}
		}
	}

	((void(*)(HDC))0x4DAD00)(hdc);
}

void CAutoLogin::CGCharacterListRecv(PMSG_CHARACTER_LIST_RECV * lpMsg)
{
	if (gAutoLogin.m_ConnectingAutoLogin) {
		if (ReconnectProgress == RECONNECT_PROGRESS_JOINED)
		{
			for (int n = 0; n < lpMsg->count; n++) {
				auto lpchar = (PMSG_CHARACTER_LIST*)(((BYTE*)lpMsg) + sizeof(PMSG_CHARACTER_LIST_RECV) + (sizeof(PMSG_CHARACTER_LIST)*n));

				if (strcmp(lpchar->Name, ReconnectName) == 0) {
					ReconnectHero = lpchar->slot;
					break;
				}
			}

			PMSG_CHARACTER_INFO_SEND pMsg;

			pMsg.header.set(0xF3, 0x03, sizeof(pMsg));

			memcpy(pMsg.name, ReconnectName, sizeof(pMsg.name));

			DataSend((BYTE*)&pMsg, pMsg.header.size);

			ReconnectSetInfo(RECONNECT_STATUS_RECONNECT, RECONNECT_PROGRESS_CHAR_LIST, 30000, 30000);

			if (ReconnectHero != -1) {
				lpViewObj lpObj = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), ((int(*)(int))0x57D9A0)(ReconnectHero));

				if (lpObj) {
					*(WORD *)(*(DWORD*)0x8128AC8 + 14) = lpObj->Level;
					*(BYTE *)(*(DWORD*)0x8128AC8 + 11) = lpObj->Class;
					*(BYTE *)(*(DWORD*)0x8128AC8 + 12) = lpObj->Skin;
					strcpy((char*)(*(DWORD*)0x8128AC8), lpObj->Name);
				}
			}

			((void(*)())0x631610)();
			*(BYTE*)0xE8CB4D = 0;
			*(DWORD*)0xE609E8 = 3;
		}
	}
}

bool CAutoLogin::CharacterInfoRecv(DWORD lpMsg, int key)
{
	bool result = ((bool(*)(DWORD, int))0x63DBE0)(lpMsg, key);

	if (gAutoLogin.m_ConnectingAutoLogin) {
		ReconnectOnCharacterInfo();

		gAutoLogin.m_AutoLoginConnected = 1;

		gAutoLogin.m_ConnectingAutoLogin = 0;

		SetDword(MAIN_SCREEN_STATE, 5);
	}

	gAutoLogin.RegisterAutoLogin(ReconnectAccount, ReconnectPassword, (Hero)->Name, GameServerAddress, GameServerPort);

	return result;
}

void CAutoLogin::DestroyWindow()
{
	gAutoLogin.Save();

	((void(*)())0x004CF890)();
}
