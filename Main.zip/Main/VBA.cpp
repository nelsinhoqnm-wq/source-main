#include "stdafx.h"
#include "VBA.h"
#include "Util.h"

#define MAX_VERTICES 50000

GLenum primitive;

GLfloat vertices0[MAX_VERTICES * 3];
GLfloat textures0[MAX_VERTICES * 2];
GLfloat colors0[MAX_VERTICES * 4];

GLfloat* vertices = vertices0;
GLfloat* textures = textures0;
GLfloat* colors = colors0;

bool vertexState = true;
bool colorState = true;
bool textureState = true;

void _glTexCoord2f(GLfloat s, GLfloat t)
{
	__glTexCoord2f(s, t);
}

void _glColor3f(GLfloat red, GLfloat green, GLfloat blue)
{
	__glColor3f(red, green, blue);
}

void _glColor3fv(const GLfloat* v)
{
	__glColor3fv(v);
}

void _glColor4f(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha)
{
	__glColor4f(red, green, blue, alpha);
}

void _glVertex3f(GLfloat x, GLfloat y, GLfloat z)
{
	__glVertex3f(x, y, z);
}

void _glVertex3fv(const GLfloat* v)
{
	__glVertex3fv(v);
}

//////////////////////////////////////////////////////////////////////////

void _glBegin(GLenum mode)
{
	primitive = mode;

	// reset pointers
	vertices = vertices0;
	textures = textures0;
	colors = colors0;
}

void _glEnd(void)
{
	bool pt = textures != textures0;
	bool pc = colors != colors0;

	int count = (vertices - vertices0) / 3;

	_ASSERT(count < MAX_VERTICES);

	// texture
	if (pt)
	{
		if (textureState == false)
		{
			glEnableClientState(GL_TEXTURE_COORD_ARRAY);
			textureState = true;
		}
	}
	else
	{
		if (textureState == true)
		{
			glDisableClientState(GL_TEXTURE_COORD_ARRAY);
			textureState = false;
		}
	}

	// color
	if (pc)
	{
		if (colorState == false)
		{
			glEnableClientState(GL_COLOR_ARRAY);
			colorState = true;
		}
	}
	else
	{
		if (colorState == true)
		{
			glDisableClientState(GL_COLOR_ARRAY);
			colorState = false;
		}
	}

	glDrawArrays(primitive, 0, count);
}

void _CreateOpenglWindow()
{
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glEnableClientState(GL_COLOR_ARRAY);

	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glTexCoordPointer(2, GL_FLOAT, 0, textures);
	glColorPointer(4, GL_FLOAT, 0, colors);
}

bool CreateOpenglWindow() {
	bool retur = ((bool(*)())0x004D0BD0)();

	_CreateOpenglWindow();

	return retur;
}

void InitVBA()
{
	SetCompleteHook(0xE8, 0x004D0B70, &CreateOpenglWindow);
	SetCompleteHook(0xE8, 0x004D2642, &CreateOpenglWindow);

	MemorySet(0x00547539, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547539, &_glBegin);

	MemorySet(0x005476B6, 0x90, 6);
	SetCompleteHook(0xE8, 0x005476B6, &_glColor3fv);
	MemorySet(0x00547720, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547720, &_glColor3fv);
	MemorySet(0x005477AB, 0x90, 6);
	SetCompleteHook(0xE8, 0x005477AB, &_glColor3fv);
	MemorySet(0x00547854, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547854, &_glColor3fv);
	MemorySet(0x005478FD, 0x90, 6);
	SetCompleteHook(0xE8, 0x005478FD, &_glColor3fv);

	MemorySet(0x005476FB, 0x90, 6);
	SetCompleteHook(0xE8, 0x005476FB, &_glColor4f);
	MemorySet(0x00547756, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547756, &_glColor4f);
	MemorySet(0x005477E1, 0x90, 6);
	SetCompleteHook(0xE8, 0x005477E1, &_glColor4f);
	MemorySet(0x0054788A, 0x90, 6);
	SetCompleteHook(0xE8, 0x0054788A, &_glColor4f);
	MemorySet(0x00547933, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547933, &_glColor4f);

	MemorySet(0x00547654, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547654, &_glTexCoord2f);
	MemorySet(0x0054766F, 0x90, 6);
	SetCompleteHook(0xE8, 0x0054766F, &_glTexCoord2f);
	MemorySet(0x00547786, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547786, &_glTexCoord2f);
	MemorySet(0x0054782F, 0x90, 6);
	SetCompleteHook(0xE8, 0x0054782F, &_glTexCoord2f);
	MemorySet(0x005478D8, 0x90, 6);
	SetCompleteHook(0xE8, 0x005478D8, &_glTexCoord2f);
	MemorySet(0x005479A3, 0x90, 6);
	SetCompleteHook(0xE8, 0x005479A3, &_glTexCoord2f);

	MemorySet(0x00547A80, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547A80, &_glVertex3fv);
	MemorySet(0x00547B7E, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547B7E, &_glVertex3fv);
	MemorySet(0x00547B9D, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547B9D, &_glVertex3fv);

	MemorySet(0x00547BAD, 0x90, 6);
	SetCompleteHook(0xE8, 0x00547BAD, &_glEnd);

	SetByte(0x00546860, 0xC3);
	SetByte(0x00546880, 0xC3);

	//Terrain
	MemorySet(0x005DA034, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA034, &_glBegin);

	MemorySet(0x005DA04E, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA04E, &_glTexCoord2f);
	MemorySet(0x005DA089, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA089, &_glTexCoord2f);
	MemorySet(0x005DA0C2, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA0C2, &_glTexCoord2f);
	MemorySet(0x005DA0FD, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA0FD, &_glTexCoord2f);

	MemorySet(0x005DA064, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA064, &_glColor3fv);
	MemorySet(0x005DA09D, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA09D, &_glColor3fv);
	MemorySet(0x005DA0D8, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA0D8, &_glColor3fv);
	MemorySet(0x005DA113, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA113, &_glColor3fv);

	MemorySet(0x005DA06F, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA06F, &_glVertex3fv);
	MemorySet(0x005DA0A8, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA0A8, &_glVertex3fv);
	MemorySet(0x005DA0E3, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA0E3, &_glVertex3fv);
	MemorySet(0x005DA11E, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA11E, &_glVertex3fv);

	MemorySet(0x005DA124, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA124, &_glEnd);

	//BitmapTile
	MemorySet(0x005DA9E5, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DA9E5, &_glBegin);

	MemorySet(0x005DAA2A, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DAA2A, &_glColor3fv);

	MemorySet(0x005DAA63, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DAA63, &_glColor4f);

	MemorySet(0x005DAA8A, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DAA8A, &_glTexCoord2f);

	MemorySet(0x005DAA9D, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DAA9D, &_glVertex3fv);

	MemorySet(0x005DAAA8, 0x90, 6);
	SetCompleteHook(0xE8, 0x005DAAA8, &_glEnd);
}
