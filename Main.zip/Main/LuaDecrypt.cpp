// FileProtect.cpp: implementation of the CLuaDecrypt class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LuaDecrypt.h"
#include "LoadFiles.h"

CLuaDecrypt gFileProtectLua;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLuaDecrypt::CLuaDecrypt() // OK
{
	this->m_buff = 0;
	this->m_size = 0;
	memset(this->m_path, 0, sizeof(this->m_path));
}

CLuaDecrypt::~CLuaDecrypt() // OK
{

}

bool CLuaDecrypt::LoadFile(char* path) // OK
{
	HANDLE file = CreateFile(path, GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_ARCHIVE, 0);

	if (file == INVALID_HANDLE_VALUE)
	{
		return 0;
	}

	this->m_size = GetFileSize(file, 0);

	if (this->m_buff != 0)
	{
		delete[] this->m_buff;
		this->m_buff = 0;
	}

	this->m_buff = new char[this->m_size];

	if (this->m_buff == 0)
	{
		CloseHandle(file);
		return 0;
	}

	DWORD OutSize = 0;

	if (ReadFile(file, this->m_buff, this->m_size, &OutSize, 0) == 0)
	{
		CloseHandle(file);
		return 0;
	}

	CloseHandle(file);
	return 1;
}

bool CLuaDecrypt::DecryptFile(char* path) // OK
{
	if (this->LoadFile(path) == 0)
	{
		return 0;
	}

	if (this->m_size < sizeof(gFileProtectLuaHeader))
	{
		return 0;
	}

	if (memcmp(this->m_buff, gFileProtectLuaHeader, sizeof(gFileProtectLuaHeader)) != 0)
	{
		return 0;
	}

	for (int n = 0; n < ((int)(this->m_size - sizeof(gFileProtectLuaHeader))); n++)
	{
		this->m_buff[sizeof(gFileProtectLuaHeader) + n] -= gFileProtectLuaXorTable[gLoadFiles.m_LoadFiles.m_PrivateCode[n%strlen(gLoadFiles.m_LoadFiles.m_PrivateCode)] % sizeof(gFileProtectLuaXorTable)];
		this->m_buff[sizeof(gFileProtectLuaHeader) + n] ^= gFileProtectLuaXorTable[n % sizeof(gFileProtectLuaXorTable)];
	}

	return this->CreateTemporaryFile();
}

bool CLuaDecrypt::CreateTemporaryFile() // OK
{
	wsprintf(this->m_path, ("Data\\Item\\vorks%d.lua"), rand() % 1000);

	HANDLE file = CreateFile(this->m_path, GENERIC_WRITE, FILE_SHARE_WRITE | FILE_SHARE_READ | FILE_SHARE_DELETE, 0, CREATE_ALWAYS, FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_TEMPORARY, 0);

	if (file == INVALID_HANDLE_VALUE)
	{
		return 0;
	}

	DWORD OutSize = 0;

	if (WriteFile(file, &this->m_buff[sizeof(gFileProtectLuaHeader)], (this->m_size - sizeof(gFileProtectLuaHeader)), &OutSize, 0) == 0)
	{
		CloseHandle(file);
		return 0;
	}

	CloseHandle(file);
	return 1;
}

void CLuaDecrypt::DeleteTemporaryFile() // OK
{
	if (strcmp(this->m_path, "") == 0)
	{
		return;
	}

	if (DeleteFile(this->m_path) == 0)
	{
		return;
	}

	delete[] this->m_buff;

	this->m_buff = 0;

	this->m_size = 0;

	memset(this->m_path, 0, sizeof(this->m_path));
}

bool CLuaDecrypt::ConvertMainFilePath(char* path) // OK
{
	if (this->DecryptFile(path) == 0)
	{
		return 0;
	}

	memset(path, 0, strlen(path));

	memcpy(path, this->m_path, strlen(this->m_path));

	return 1;
}