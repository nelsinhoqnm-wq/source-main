#pragma once

#include "Lua.h"
#include "LuaLoadImage.h"
#include "LuaBMD.h"

class CRenderModel {
public:
	CRenderModel();
	~CRenderModel();

	void RestartLua();
	void Init();
	void LoadImageRenderModel();

public:
	Lua m_Lua;

private:
	LuaLoadImage m_LuaLoadImage;
	LuaBMD m_LuaBMD;
};

extern CRenderModel gRenderModel;