#pragma once

class CRenderObject {
public:
	CRenderObject();
	~CRenderObject();

	void Init();
	static void Draw_RenderObject(ObjectModel *o, bool Translate, int Select, int ExtraMon);
};

extern CRenderObject gRenderObject;