#pragma once

#define MAX_WIN_WIDTH 640
#define MAX_MAIN_VIEWPORT 400

enum eReconnectStatus
{
	RECONNECT_STATUS_NONE = 0,
	RECONNECT_STATUS_RECONNECT = 1,
	RECONNECT_STATUS_DISCONNECT = 2,
};

enum eReconnectProgress
{
	RECONNECT_PROGRESS_NONE = 0,
	RECONNECT_PROGRESS_CONNECTED = 1,
	RECONNECT_PROGRESS_JOINED = 2,
	RECONNECT_PROGRESS_CHAR_LIST = 3,
	RECONNECT_PROGRESS_CHAR_INFO = 4,
};

void InitReconnect();
void ReconnectMainProc();
void ReconnectDrawInterface();
void ReconnectSetInfo(DWORD status,DWORD progress,DWORD CurWait,DWORD MaxWait);
void ReconnecGameServerLoad();
void ReconnecGameServerAuth();
void ReconnectOnCloseSocket();
void ReconnectOnMapServerMove(char* address,WORD port);
void ReconnectOnMapServerMoveAuth(BYTE result);
void ReconnectOnConnectAccount(BYTE result);
void ReconnectOnCloseClient(BYTE result);
void ReconnectOnCharacterList();
void ReconnectOnCharacterInfo();
void ReconnectViewportDestroy();
BOOL ReconnectCreateConnection(char* address,WORD port);
void ReconnectGetAccountInfo();
void ReconnectCheckConnection();
void ReconnectCloseSocket();
void ReconnectMenuExitGame();

extern char GameServerAddress[16];
extern WORD GameServerPort;
extern char ReconnectAccount[11];
extern char ReconnectPassword[11];
extern char ReconnectName[11];
extern char ReconnectMapServerAddress[16];
extern WORD ReconnectMapServerPort;
extern DWORD ReconnectStatus;
extern DWORD ReconnectProgress;
extern DWORD ReconnectCurTime;
extern DWORD ReconnectMaxTime;
extern DWORD ReconnectCurWait;
extern DWORD ReconnectMaxWait;
extern DWORD ReconnectAuthSend;
extern DWORD ReconnectHelperOn;
extern DWORD ReconnectHero;