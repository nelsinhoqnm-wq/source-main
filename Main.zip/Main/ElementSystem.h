#pragma once

#include "Lua.h"
#include "LuaEffects.h"
#include "LuaBMD.h"

class ELEMENT_INFO {
public:
	ELEMENT_INFO() {
		this->ItemIndex = -1;
	};

	~ELEMENT_INFO() {

	};

	int ItemIndex;
	int Type;
	int Movement;
	float HeightFloor;
	float Size;
	char Model[32];
};

class CElementSystem {
public:
	CElementSystem();
	~CElementSystem();

	void Init();
	ELEMENT_INFO * GetElement(int ItemIndex);

public:
	std::map<int, ELEMENT_INFO> m_ElementInfo;

private:
	Lua m_Lua;
	CLuaEffects m_LuaEffects;
	LuaBMD m_LuaBMD;
};

extern CElementSystem gElementSystem;