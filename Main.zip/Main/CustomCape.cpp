#include "stdafx.h"
#include "CustomCape.h"
#include "CustomWing.h"
#include "LuaStack.hpp"
#include "LuaBMD.h"
#include "LuaObject.h"
#include "AntiHack.h"
#include "Item.h"
#include "MenuWindow.h"
#include "Console.h"
#include "LuaStack.hpp"
#include "LuaObject.h"

using namespace luaaa;

CCustomCape gCustomCape;

CCustomCape::CCustomCape() : m_Lua(false)
{
}

CCustomCape::~CCustomCape()
{
}

__declspec(naked) void CheckEquipedCape() {

	static DWORD m_SetEquipedCape = 0x005723A2;
	static DWORD m_ReturnFunction = 0x00572335;
	static ObjectPreview* m_Character;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV m_Character, ECX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_Character->WingsSlot) == 1 && gMenuWindow.m_WingDisabled == 0) {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8];
			MOVZX EDX, BYTE PTR DS : [ECX + 0x13];
			JMP[m_SetEquipedCape];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8];
			MOVZX EDX, BYTE PTR DS : [ECX + 0x13];
			JMP[m_ReturnFunction];
		}
	}
}

void CreateCape(ObjectPreview* character, WORD ItemIndex, BYTE Class) {
	gCustomCape.CreateCape(character, ItemIndex, ((BYTE(*)(BYTE))0x405230)(Class));
}

__declspec(naked) void CreateCapeToNormalClass() {
	static ObjectPreview* m_Character;
	static DWORD m_HookStartedFunc = 0x009CDB52;
	static DWORD m_ReturnFunc = 0x005757DE;
	static DWORD m_HookCape = 0x00575A9C;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV m_Character, ECX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_Character->WingsSlot) == 1) {
		CreateCape(m_Character, m_Character->WingsSlot, m_Character->Class);

		_asm {
			JMP[m_HookCape];
		}
	}
	else {
		_asm {
			PUSH 0x64;
			CALL[m_HookStartedFunc];
			ADD ESP, 0x4;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void CreateCapeToDLClass() {
	static ObjectPreview* m_Character;
	static DWORD m_ReturnFunc = 0x00574671;
	static DWORD m_HookCape = 0x00575A9C;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 8];
		MOV m_Character, EAX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_Character->WingsSlot) == 1) {
		CreateCape(m_Character, m_Character->WingsSlot, m_Character->Class);

		_asm {
			JMP[m_HookCape];
		}
	}
	else {
		_asm {
			MOV DWORD PTR SS : [EBP - 0x2D8], 0x4
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void CreateCapeToRFClass() {
	static ObjectPreview* m_Character;
	static DWORD m_ReturnFunc = 0x00575105;
	static DWORD m_HookCape = 0x00575A9C;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		MOV m_Character, EAX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_Character->WingsSlot) == 1) {
		CreateCape(m_Character, m_Character->WingsSlot, m_Character->Class);

		_asm {
			JMP[m_HookCape];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8];
			MOVSX ECX, WORD PTR DS : [EAX + 0x208];
			JMP[m_ReturnFunc];
		}
	}
}

void RenderModel(DWORD BMDStruct, DWORD Object, DWORD ItemIndex) {
	if (gAntiHack.LicenseChecked) {
		int renderCharacter = 1;

		if (*(float*)(BMDStruct + 72) == 1.0 && *(float*)(BMDStruct + 76) == 1.0 && *(float*)(BMDStruct + 80) == 1.0) {
			renderCharacter = 0;
		}

		gCustomCape.m_Lua.Generic_Call("RenderCapeModel", "iiii>", BMDStruct, Object, ItemIndex, renderCharacter);
	}
}

__declspec(naked) void RenderCapeModel() {
	static DWORD m_ReturnFunc = 0x005FA84B;
	static DWORD m_ExitFunc = 0x00608175;

	static DWORD m_BMDStruct = 0;
	static DWORD m_ObjectStruct = 0;
	static DWORD m_ItemIndex = 0;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x10];
		MOV m_ItemIndex, ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0xC];
		MOV m_ObjectStruct, ECX;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV m_BMDStruct, ECX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_ItemIndex) == 1) {
		RenderModel(m_BMDStruct, m_ObjectStruct, m_ItemIndex);

		_asm {
			JMP[m_ExitFunc];
		}
	}
	else {
		_asm {
			CMP DWORD PTR SS : [EBP + 0x10], 0x14A7
			JMP[m_ReturnFunc];
		}
	}
}

void CapeModelPosition(DWORD ItemIndex, float& posX, float& posY, float& posZ, float& matrixX, float& matrixY, float& matrixZ) {
	if (gAntiHack.LicenseChecked) {
		float m_posX = 0.0;
		float m_posY = 0.0;
		float m_posZ = 0.0;
		float m_matrixX = 0.0;
		float m_matrixY = 0.0;
		float m_matrixZ = 0.0;

		gCustomCape.m_Lua.Generic_Call("CapeModelPosition", "i>ffffff", ItemIndex, &m_posX, &m_posY, &m_posZ, &m_matrixX, &m_matrixY, &m_matrixZ);

		posX = m_posX;
		posY = m_posY;
		posZ = m_posZ;
		matrixX = m_matrixX;
		matrixY = m_matrixY;
		matrixZ = m_matrixZ;
	}
}

__declspec(naked) void ModelPosition() {
	static DWORD m_ReturnFunc = 0x005658BD;
	static DWORD m_HookFunc = 0x00566109;
	static DWORD m_CallFunc = 0x00959CE0;
	static DWORD m_ItemIndex = 0;

	static float posX = 0.0;
	static float posY = 0.0;
	static float posZ = 0.0;
	static float matrixX = 0.0;
	static float matrixY = 0.0;
	static float matrixZ = 0.0;

	_asm
	{
		MOV EDX, DWORD PTR SS : [EBP + 0x1C];
		MOV m_ItemIndex, EDX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_ItemIndex) == 1) {
		CapeModelPosition(m_ItemIndex, posX, posY, posZ, matrixX, matrixY, matrixZ);

		_asm {
			FLD DWORD PTR DS : [posX];
			FSTP DWORD PTR SS : [EBP - 0x80];
			FLD DWORD PTR DS : [posY];
			FSTP DWORD PTR SS : [EBP - 0x7C];
			FLD DWORD PTR DS : [posZ];
			FSTP DWORD PTR SS : [EBP - 0x78];
			LEA EDX, DWORD PTR SS : [EBP - 0xB0];
			PUSH EDX;
			LEA EAX, DWORD PTR SS : [EBP - 0x80];
			PUSH EAX;
			CALL[m_CallFunc];
			ADD ESP, 0x8;
			FLD DWORD PTR DS : [matrixX];
			FSTP DWORD PTR SS : [EBP - 0xA4];
			FLD DWORD PTR DS : [matrixY];
			FSTP DWORD PTR SS : [EBP - 0x94];
			FLD DWORD PTR DS : [matrixZ];
			FSTP DWORD PTR SS : [EBP - 0x84];
			JMP[m_HookFunc];
		}
	}
	else {
		_asm
		{
			CMP DWORD PTR SS : [EBP + 0x1C], 0x1CC5
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void DeleteClothEquipedInventory() {
	static DWORD m_Returnfunc = 0x008362A7;
	static DWORD m_HookFunc = 0x008362FB;
	static DWORD m_Index = 0;

	_asm {
		MOVSX EAX, WORD PTR DS : [EDX];
		MOV m_Index, EAX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_Index + ITEM_BASE_MODEL) || m_Index == GET_ITEM(12, 40)) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOVSX EAX, WORD PTR DS : [EDX];
			CMP EAX, 0x1827;
			JMP[m_Returnfunc];
		}
	}
}

__declspec(naked) void DeleteClothUnequipInventory() {
	static DWORD m_Returnfunc = 0x00836414;
	static DWORD m_HookFunc = 0x0083645D;
	static DWORD m_Index = 0;

	_asm {
		MOVSX EAX, WORD PTR DS : [EDX];
		MOV DWORD PTR SS : [EBP - 0x8], EAX;
		MOV m_Index, EAX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_Index + ITEM_BASE_MODEL) || m_Index == GET_ITEM(12, 40)) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOVSX EAX, WORD PTR DS : [EDX];
			MOV DWORD PTR SS : [EBP - 0x8], EAX;
			JMP[m_Returnfunc];
		}
	}
}

__declspec(naked) void SetClothDLContinue() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnHook = 0x00576062;
	static DWORD m_HookFunc = 0x005760C2;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EAX + 0x208]
		MOV m_Index, ECX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_Index)) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EAX + 0x208]
			JMP[m_ReturnHook];
		}
	}
}

__declspec(naked) void SetClothRFContinue() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnHook = 0x0057614B;
	static DWORD m_HookFunc = 0x005761AB;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x208]
		MOV m_Index, EAX;
	}

	if (gCustomWing.CheckCustomWingIsCape(m_Index)) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x208]
			JMP[m_ReturnHook];
		}
	}
}

void RenderShineCape(DWORD StructFunc, DWORD Struct) {
	gCustomCape.m_Lua.Generic_Call("CapeRenderShine", "iii>", *(DWORD*)(StructFunc + 12), StructFunc, Struct);
}

void __declspec(naked) JumpToRenderCloth()
{
	static DWORD m_CallFunc = 0x009CF11A;
	static DWORD m_ReturnFunc = 0x0051EC7F;

	_asm
	{
		MOV EAX, DWORD PTR SS : [EBP - 0x40]
		PUSH EAX;
		MOV ECX, DWORD PTR SS : [EBP - 0x44]
		PUSH ECX;
		CALL[RenderShineCape];
		PUSH EAX;
		CALL[m_CallFunc];
		ADD ESP, 0xC;
		JMP[m_ReturnFunc];
	}
}

void RenderShine(DWORD func, DWORD Struct, int imageIndex, float colorR, float colorG, float colorB) {
	pGLSwitchBlend();

	((void(*)(int))0x00635CF0)(imageIndex);

	float_t lights = 1.0f;

	if (colorR > 0.0)
	{
		float max = colorB - colorG;
		float min = -colorR;
		lights = GetDoubleRender(min, 0.0f) * max + colorG;
	}

	glColor3f(lights, lights, lights);

	glBegin(7);

	for (DWORD i = 0; i < *(DWORD *)(func + 48) - 1; ++i)
	{
		for (DWORD j = 0; j < *(DWORD *)(func + 44) - 1; ++j)
		{
			((void(__thiscall*)(int, int a2, int a3, int t))0x0051EE20)(func, Struct, j, i);
			((void(__thiscall*)(int, int a2, int a3, int t))0x0051EE20)(func, Struct, j + 1, i);
			((void(__thiscall*)(int, int a2, int a3, int t))0x0051EE20)(func, Struct, j + 1, i + 1);
			((void(__thiscall*)(int, int a2, int a3, int t))0x0051EE20)(func, Struct, j, i + 1);
		}
	}

	glEnd();
}

void CCustomCape::Init()
{
	this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//CharacterCreateCape.lua");

	this->RegisterCapeClass(this->m_Lua.GetState());

	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("RenderShine", &RenderShine);

	SetCompleteHook(0xE9, 0x0057232E, &CheckEquipedCape);

	SetCompleteHook(0xE9, 0x005757D4, &CreateCapeToNormalClass);

	SetCompleteHook(0xE9, 0x00574667, &CreateCapeToDLClass);

	SetCompleteHook(0xE9, 0x005750FB, &CreateCapeToRFClass);

	SetCompleteHook(0xE9, 0x005FA844, &RenderCapeModel);

	SetCompleteHook(0xE9, 0x005658B6, &ModelPosition);

	SetCompleteHook(0xE9, 0x008362A2, &DeleteClothEquipedInventory);

	SetCompleteHook(0xE9, 0x0083640E, &DeleteClothUnequipInventory);

	SetCompleteHook(0xE9, 0x0057605B, &SetClothDLContinue);

	SetCompleteHook(0xE9, 0x00576144, &SetClothRFContinue);

	MemorySet(0x0051EC76, 0x90, 6);
	SetCompleteHook(0xE9, 0x0051EC76, &JumpToRenderCloth);
}

void CCustomCape::RestartLua()
{
	this->m_LuaLoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//CharacterCreateCape.lua");

	this->RegisterCapeClass(this->m_Lua.GetState());

	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("RenderShine", &RenderShine);

	SetCompleteHook(0xE9, 0x0057232E, &CheckEquipedCape);

	SetCompleteHook(0xE9, 0x005757D4, &CreateCapeToNormalClass);

	SetCompleteHook(0xE9, 0x00574667, &CreateCapeToDLClass);

	SetCompleteHook(0xE9, 0x005750FB, &CreateCapeToRFClass);

	SetCompleteHook(0xE9, 0x005FA844, &RenderCapeModel);

	SetCompleteHook(0xE9, 0x005658B6, &ModelPosition);

	SetCompleteHook(0xE9, 0x008362A2, &DeleteClothEquipedInventory);

	SetCompleteHook(0xE9, 0x0083640E, &DeleteClothUnequipInventory);

	SetCompleteHook(0xE9, 0x0057605B, &SetClothDLContinue);

	SetCompleteHook(0xE9, 0x00576144, &SetClothRFContinue);

	MemorySet(0x0051EC76, 0x90, 6);
	SetCompleteHook(0xE9, 0x0051EC76, &JumpToRenderCloth);
}

void CCustomCape::RegisterCapeClass(lua_State * lua)
{
	luaaa::LuaClass<CapeClass> luaCape(lua, "CapeStack");
	luaCape.ctor<int>();
	luaCape.fun("Create", &CapeClass::Create);
	luaCape.fun("Collision", &CapeClass::Collision);
	luaCape.fun("SetCapePlayer", &CapeClass::SetCapePlayer);
	luaCape.fun("SetWindMinMax", &CapeClass::SetWindMinMax);
}

void CCustomCape::LoadImageCape()
{
	this->m_Lua.Generic_Call("LoadImageCape", ">");
}

void CCustomCape::CreateCape(ObjectPreview * character, WORD ItemIndex, BYTE Class)
{
	if (gMenuWindow.m_WingDisabled) {
		return;
	}

	if (gAntiHack.LicenseChecked) {
		this->m_Lua.Generic_Call("CreateCapePlayer", "iii>", (DWORD)&(character->Object), ItemIndex, Class);
	}
}
