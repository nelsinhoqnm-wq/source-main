#include "stdafx.h"
#include "TradeX.h"
#include "Item.h"
#include "Util.h"
#include "ItemMove.h"
#include "CustomMessage.h"

CTradeX gTradeX;

CTradeX::CTradeX()
{
	this->m_PosX = 260;
	this->m_PosY = 0;

	this->m_isVisible = false;

	this->m_TradeItemSource.clear();
	this->m_TradeItemTarget.clear();

	m_iMouseYSource = 0;
	m_iMouseYTarget = 0;

	TradeXHidden = 0;
	TradeXTransation = 0;

	TimeTradeX = 10;
	TickBlockOk = 0;

	memcpy(NameTarget, "Hope", sizeof(NameTarget));
}

CTradeX::~CTradeX()
{
	std::vector<TradeItem>::iterator target = this->m_TradeItemTarget.begin();

	for (; target != this->m_TradeItemTarget.end(); target++) {
		target->Clear();
	}

	this->m_TradeItemTarget.clear();

	std::vector<TradeItem>::iterator source = this->m_TradeItemSource.begin();

	for (; source != this->m_TradeItemSource.end(); source++) {
		source->Clear();
	}

	this->m_TradeItemSource.clear();
}

bool CheckMouseUse(LPVOID This) {
	if (gTradeX.isVisible()) {
		if (gTradeX.CheckMouse()) {
			return true;
		}
	}

	return ((bool(__thiscall*)(LPVOID))0x860A60)(pWindowThis());
}

__declspec(naked) void DisableButtonsInTradeX() {
	static DWORD m_CallFunc = 0x00861110;
	static DWORD m_ReturnFunc = 0x00837748;
	static DWORD m_HookFunc = 0x0083782E;

	if (gTradeX.isVisible()) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			PUSH 0x0C;
			CALL[m_CallFunc];
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void DisableUpdateButtonsInTradeX() {
	static DWORD m_ReturnFunc = 0x0083B5C6;
	static DWORD m_HookFunc = 0x0083B605;

	if (gTradeX.isVisible()) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV DWORD PTR SS : [EBP - 0x4], EAX
			PUSH 0x1;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void DisableUpdateButtonsInTradeX2() {
	static DWORD m_ReturnFunc = 0x0083B60E;
	static DWORD m_HookFunc = 0x0083B653;

	if (gTradeX.isVisible()) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP - 0xC]
			ADD ECX, 0x1CC
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void DisableUpdateButtonsInTradeX3() {
	static DWORD m_ReturnFunc = 0x0083B65A;
	static DWORD m_HookFunc = 0x0083B7B6;
	static DWORD m_CallFunc = 0x00861110;

	if (gTradeX.isVisible()) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			PUSH 0x0C
			CALL[m_CallFunc];
			JMP[m_ReturnFunc];
		}
	}
}

BOOL RenderExternalFunc() {
	if (gTradeX.isVisible()) {
		gTradeX.Render();
		return 1;
	}

	return 0;
}

__declspec(naked) void MainProcRenderTrade() {
	static DWORD m_HookFunc = 0x0086427B;
	static DWORD m_ExitFunc = 0x00864355;

	_asm {
		Call[RenderExternalFunc];
		Test EAX, EAX;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:
		MOV DWORD PTR SS : [EBP - 0x8], ECX
		PUSH 1
		JMP[m_HookFunc];
	}
}

BOOL UpdateExternalFunc() {
	if (gTradeX.isVisible()) {
		gTradeX.Update();
		return 1;
	}

	return 0;
}

__declspec(naked) void MainProcUpdateTrade() {
	static DWORD m_HookFunc = 0x0086421A;
	static DWORD m_ExitFunc = 0x0086425D;

	_asm {
		Call[UpdateExternalFunc];
		Test Eax, Eax;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:

		MOV DWORD PTR SS : [EBP - 0x4], ECX;
		MOV EAX, DWORD PTR SS : [EBP - 0x4];
		JMP[m_HookFunc];
	}
}

BOOL UpdateKeyEventExternalFunc() {
	if (gTradeX.isVisible()) {
		gTradeX.UpdateKeyEvent();
		return 1;
	}

	return 0;
}

__declspec(naked) void MainProcUpdateKeyEventTrade() {
	static DWORD m_HookFunc = 0x00864158;
	static DWORD m_ExitFunc = 0x008641F1;

	_asm {
		Call[UpdateKeyEventExternalFunc];
		Test Eax, Eax;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:
		MOV DWORD PTR FS : [0x0], ESP
		JMP[m_HookFunc];
	}
}

BOOL UpdateMouseEventExternalFunc() {
	if (gTradeX.isVisible()) {
		gTradeX.UpdateMouseEvent();
		return 1;
	}

	return 0;
}

__declspec(naked) void MainProcUpdateMouseEventTrade() {
	static DWORD m_HookFunc = 0x00863F88;
	static DWORD m_ExitFunc = 0x00864129;

	_asm {
		Call[UpdateMouseEventExternalFunc];
		Test Eax, Eax;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:
		MOV DWORD PTR FS : [0x0], ESP;
		JMP[m_HookFunc];
	}
}

void AutoMoveItemTrade(void* This) {
	if (gTradeX.isVisible()) {
		return;
	}

	((void(__thiscall*)(LPVOID))0x00866B90)(pTradeInventoryThis(pWindowThis()));
}

BOOL MainProcRenderBuffTradeX() {
	if (gTradeX.isHidden()) {
		gTradeX.RenderIconTradeExtended();
		return 1;
	}

	return 0;
}

__declspec(naked) void MainProcRenderBuff() {
	static DWORD m_HookFunc = 0x00777C69;
	static DWORD m_ExitFunc = 0x00777CA4;

	_asm {
		Call[MainProcRenderBuffTradeX];
		Test Eax, Eax;
		Je EXIT;
		JMP[m_ExitFunc];

	EXIT:
		MOV DWORD PTR SS : [EBP - 0x4], ECX;
		JMP[m_HookFunc];
	}
}

BOOL MainProcUpdateMouseBuffTradeX() {
	if (gTradeX.isHidden()) {
		gTradeX.UpdateMouseEventTradeExtended();
		return 1;
	}

	return 0;
}

__declspec(naked) void MainProcUpdateMouseBuff() {
	static DWORD m_HookFunc = 0x00777928;
	static DWORD m_ExitFunc = 0x00777C24;

	_asm {
		Call[MainProcUpdateMouseBuffTradeX];
		Test Eax, Eax;
		Je EXIT;
		MOV BYTE PTR SS : [EBP - 0x72], 0x1
		JMP[m_ExitFunc];

	EXIT:
		MOV DWORD PTR FS : [0x0], ESP
		JMP[m_HookFunc];
	}
}

void CTradeX::Init()
{
	SetCompleteHook(0xE8, 0x004D935C, &CheckMouseUse);
	SetCompleteHook(0xE8, 0x005B67B9, &CheckMouseUse);
	SetCompleteHook(0xE8, 0x005B832F, &CheckMouseUse);
	SetCompleteHook(0xE8, 0x005CF380, &CheckMouseUse);

	SetCompleteHook(0xE9, 0x00837741, &DisableButtonsInTradeX);

	SetCompleteHook(0xE9, 0x0083B5C1, &DisableUpdateButtonsInTradeX);

	SetCompleteHook(0xE9, 0x0083B605, &DisableUpdateButtonsInTradeX2);

	SetCompleteHook(0xE9, 0x0083B653, &DisableUpdateButtonsInTradeX3);

	SetCompleteHook(0xE9, 0x00864276, &MainProcRenderTrade);

	SetCompleteHook(0xE9, 0x00864214, &MainProcUpdateTrade);

	SetCompleteHook(0xE9, 0x00864151, &MainProcUpdateKeyEventTrade);

	SetCompleteHook(0xE9, 0x00863F81, &MainProcUpdateMouseEventTrade);

	SetCompleteHook(0xE8, 0x00838FB8, &AutoMoveItemTrade);

	SetCompleteHook(0xE8, 0x00777C64, &MainProcRenderBuff);

	SetCompleteHook(0xE8, 0x00777921, &MainProcUpdateMouseBuff);
}

bool CTradeX::isVisible()
{
	return this->m_isVisible;
}

bool CTradeX::CheckMouse()
{
	if (CheckMouseIn(this->m_PosX, this->m_PosY, 190, 429)) {
		return true;
	}

	return false;
}

void CTradeX::Open()
{
	this->m_PosX = 260;
	this->m_PosY = 0;

	this->m_isVisible = 1;

	//OpenWindow(ObjWindow::Inventory);

	m_EventStateTarget = EVENT_NONE;
	m_EventStateSource = EVENT_NONE;

	ScrollBarPosXTarget = (float)(this->m_PosX + 160);

	ScrollBarPosXSource = (float)(this->m_PosX + 160);

	m_iMouseYSource = 0;
	m_iMouseYTarget = 0;
}

void CTradeX::Close()
{
}

void CTradeX::ClearTradeX()
{
	this->ClearTradeXSource();
	this->ClearTradeXTarget();

	this->m_isVisible = 0;

	memcpy(this->NameTarget, "Hope", sizeof(this->NameTarget));

	this->TradeXTransation = 0;

	this->TradeXHidden = 0;

	this->m_SourceAcceptTradeX = 0;
	this->m_TargetAcceptTradeX = 0;

	this->TickBlockOk = 0;

	this->ClickEvent = GetTickCount();
}

void CTradeX::Render()
{
	if (!this->isVisible()) {
		return;
	}

	EnableAlphaTest(1);

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	this->RenderFrame();

	this->RenderText();

	this->RenderButtom();

	this->RenderScrollTarget((float)(this->m_PosX + 15), (float)(this->m_PosY + 105), 160, 90);

	this->RenderScrollSource((float)(this->m_PosX + 15), (float)(this->m_PosY + 275), 160, 90);

	DisableAlphaBlend();
}

void CTradeX::RenderFrame()
{
	RenderImage(590020, (float)(this->m_PosX), (float)(this->m_PosY), 190.0, 430.0);
	//RenderImage(31353, (float)(this->m_PosX), (float)(this->m_PosY), 190.0, 64.0);
	//RenderImage(31355, (float)(this->m_PosX), (float)(this->m_PosY + 64), 21.0, 320.0);
	//RenderImage(31356, (float)(this->m_PosX + 169), (float)(this->m_PosY + 64), 21.0, 320.0);
	//RenderImage(31357, (float)(this->m_PosX), (float)(this->m_PosY + 384), 190.0, 45.0);
	//RenderImage(31401, (float)(this->m_PosX+ 1), (float)(this->m_PosY + 220), 188.0, 21.0);

	if (this->m_TargetAcceptTradeX) {
		RenderImage2(31743, (float)(this->m_PosX + 14), (float)(this->m_PosY + 87), 13, 13, 0.0, 0.5, 1.0, 0.5, 1, 1, 1.0);
	}
	else {
		RenderImage2(31743, (float)(this->m_PosX + 14), (float)(this->m_PosY + 87), 13, 13, 0.0, 0.0, 1.0, 0.5, 1, 1, 1.0);
	}

	this->RenderBoxItem((float)(this->m_PosX + 15), (float)(this->m_PosY + 105), 160, 90);

	if (this->m_SourceAcceptTradeX) {
		RenderImage2(31743, this->m_PosX + 14, this->m_PosY + 258, 13, 13, 0.0, 0.5, 1.0, 0.5, 1, 1, 1.0);
	}
	else {
		RenderImage2(31743, this->m_PosX + 14, this->m_PosY + 258, 13, 13, 0.0, 0.0, 1.0, 0.5, 1, 1, 1.0);
	}

	this->RenderBoxItem(this->m_PosX + 15, this->m_PosY + 275, 160, 90);

	this->RenderItensSource();

	this->RenderItensTarget();
}

void CTradeX::RenderText()
{
	char buffer[256];

	pTextSetFont(pTextThis(), g_hFontBold);

	pSetTextBgColor2(pTextThis(), 0);

	pSetTextColor(pTextThis(), 0xD8, 0xD8, 0xD8, 0xFF);

	pDrawText(pTextThis(), this->m_PosX, this->m_PosY + 11, gCustomMessage.GetMessage(5), 190, 0, 3, 0);

	pTextSetFont(pTextThis(), g_hFont);

	pSetTextColor(pTextThis(), 225, 225, 225, 0xFF);

	SIZE pBox;

	pDrawText(pTextThis(), this->m_PosX + 20, this->m_PosY + 45, gCustomMessage.GetMessage(6), 190, 0, 1, &pBox);

	pSetTextColor(pTextThis(), 0xFF, 0xFF, 0xFF, 0xFF);

	if (gTradeX.TradeXTransation == 0) {
		sprintf_s(buffer, gCustomMessage.GetMessage(7));
	}
	else if (gTradeX.TradeXTransation == 1) {
		pSetTextColor(pTextThis(), 172, 255, 56, 255);

		sprintf_s(buffer, gCustomMessage.GetMessage(8));
	}
	else if (gTradeX.TradeXTransation == 2) {
		pSetTextColor(pTextThis(), 225, 0, 0, 255);

		sprintf_s(buffer, gCustomMessage.GetMessage(9));
	}

	pDrawText(pTextThis(), this->m_PosX + 45 + pBox.cx, this->m_PosY + 45, buffer, 190, 0, 7, 0);

	this->RenderTextSource();

	this->RenderTextTarget();
}

void CTradeX::RenderButtom() {
	char buffer[150];

	if (CheckMouseIn(this->m_PosX + 20, this->m_PosY + 380, 65, 30)) {
		RenderImage2(31326, (float)(this->m_PosX + 20), (float)(this->m_PosY + 380), (float)95, (float)33, 0, 0.2264566, 1.0, 0.2245212, 1, 1, 1.0);
	}
	else {
		RenderImage2(31326, (float)(this->m_PosX + 20), (float)(this->m_PosY + 380), (float)95, (float)33, 0, 0, 1.0, 0.2245212, 1, 1, 1.0);
	}

	pTextSetFont(pTextThis(), g_hFontBold);

	pSetTextColor(pTextThis(), 225, 225, 225, 255);

	pDrawText(pTextThis(), (float)(this->m_PosX + 20), (float)(this->m_PosY + 390), gCustomMessage.GetMessage(10), 77, 0, 3, 0);

	DWORD tick = (DWORD)((GetTickCount() - this->TickBlockOk) / 1000);

	if (CheckMouseIn(this->m_PosX + 100, this->m_PosY + 380, 90, 33)) {
		RenderImage2(31326, (float)(this->m_PosX + 100), (float)(this->m_PosY + 380), (float)95, (float)33, 0, 0.2264566, 1.0, 0.2245212, 1, 1, 1.0);
	}
	else {
		RenderImage2(31326, (float)(this->m_PosX + 100), (float)(this->m_PosY + 380), (float)95, (float)33, 0, 0, 1.0, 0.2245212, 1, 1, 1.0);
	}

	if (tick < 10) {
		pSetTextColor(pTextThis(), 255, 15, 15, 255);
	}
	else {
		pSetTextColor(pTextThis(), 225, 225, 225, 255);
	}

	if (tick < 10) {
		sprintf_s(buffer, gCustomMessage.GetMessage(11), gTradeX.CountTimeTradeX(tick));
	}
	else {
		sprintf_s(buffer, gCustomMessage.GetMessage(12));
	}

	pDrawText(pTextThis(), (float)(this->m_PosX + 100), (float)(this->m_PosY + 390), buffer, 80, 0, 3, 0);

}

void CTradeX::Update()
{
	if (!this->isVisible()) {
		return;
	}

	this->ItemPointer = -1;
	this->ItemPointerTarget = -1;

	if (CheckWindowOpen(ObjWindow::ExpandInventory)) {
		this->m_PosX = 70;

		ScrollBarPosXTarget = this->m_PosX + 160;
		ScrollBarPosXSource = this->m_PosX + 160;
	}
	else {
		this->m_PosX = 260;

		ScrollBarPosXTarget = this->m_PosX + 160;
		ScrollBarPosXSource = this->m_PosX + 160;
	}
}

void CTradeX::UpdateKeyEvent()
{
	if (!this->isVisible()) {
		return;
	}

}

void CTradeX::UpdateMouseEvent()
{
	this->UpdateButtom();

	if (CheckMouseIn(ScrollBarPosXTarget, this->m_PosY + 125 + TargetScrollBarPos, 15, 30)) {
		if (IsPressKey(VK_LBUTTON)) {
			m_EventStateTarget = EVENT_SCROLL_BTN_CLIKED;
			ResetMouseL();
		}

		m_EventStateTarget = EVENT_SCROLL_BTN_DOWN;
	}
	else {
		m_EventStateTarget = EVENT_NONE;
	}

	if (CheckMouseIn(ScrollBarPosXSource, this->m_PosY + 285 + SourceScrollBarPos, 15, 30)) {
		m_EventStateSource = EVENT_SCROLL_BTN_DOWN;
	}
	else {
		m_EventStateSource = EVENT_NONE;
	}

	if (CheckMouseIn(this->m_PosX + 120, this->m_PosY + 90, 170, 120)) {
		if (IsRepeatKey(VK_LBUTTON)) {
			int iMoveValue = pCursorY - m_iMouseYTarget;

			if (iMoveValue < 0) {
				if (pCursorY <= (this->m_PosY + 125 + TargetScrollBarPos) + (20 / 2)) {
					this->ScrollLinesTarget(0);
				}
			}
			else if (iMoveValue > 0) {
				if (pCursorY >= (this->m_PosY + 125 + TargetScrollBarPos) + (20 / 2)) {
					this->ScrollLinesTarget(1);
				}
			}

			m_iMouseYTarget = pCursorY;
		}
	}

	if (CheckMouseIn(this->m_PosX + 120, this->m_PosY + 260, 170, 120)) {
		if (IsRepeatKey(VK_LBUTTON)) {
			int iMoveValue = pCursorY - m_iMouseYSource;

			if (iMoveValue < 0) {
				if (pCursorY <= (this->m_PosY + 285 + SourceScrollBarPos) + (20 / 2)) {
					this->ScrollLinesSource(0);
				}
			}
			else if (iMoveValue > 0) {
				if (pCursorY >= (this->m_PosY + 285 + SourceScrollBarPos) + (20 / 2)) {
					this->ScrollLinesSource(1);
				}
			}

			m_iMouseYSource = pCursorY;
		}
	}
}

void CTradeX::UpdateButtom()
{
	if (CheckMouseIn(this->m_PosX + 20, this->m_PosY + 380, 65, 30)) { //Cancel
		if (IsPressKey(VK_LBUTTON) && *(BYTE*)0x8793386) {
			ResetMouseL();

			PMSG_TRADE_OK_BUTTON_SEND pMsg;

			pMsg.header.setE(0x3C, sizeof(pMsg));

			pMsg.flag = 0;

			pMsg.tradeX = 1;

			pMsg.Cancel = 25;

			DataSend((BYTE*)&pMsg, pMsg.header.size);
		}
	}

	if (CheckMouseIn(this->m_PosX + 100, this->m_PosY + 380, 65, 30)) { //aceitar
		if (IsPressKey(VK_LBUTTON) && *(BYTE*)0x8793386) {
			ResetMouseL();

			if ((DWORD)((GetTickCount() - this->TickBlockOk) / 1000) > 9) {
				if (this->TradeXTransation == 0) {
					this->m_SourceAcceptTradeX ^= 1;

					PMSG_TRADE_OK_BUTTON_SEND pMsg;

					pMsg.header.setE(0x3C, sizeof(pMsg));

					pMsg.flag = (BYTE)this->m_SourceAcceptTradeX;

					DataSend((BYTE*)&pMsg, pMsg.header.size);
				}
			}
		}
	}
}

void CTradeX::RenderButtomHidden()
{
	if (!this->isVisible()) {
		return;
	}

	if (CheckMouseIn((*((DWORD *)pInventoryThis(pWindowThis()) + 9) + 13), (float)(*((DWORD *)pInventoryThis(pWindowThis()) + 10) + 390), 36, 29)) {
		pTextSetFont(pTextThis(), g_hFontBold);

		pSetTextColor(pTextThis(), 225, 225, 225, 255);

		pSetTextBgColor(pTextThis(), 0, 0, 0, 255);

		pDrawText(pTextThis(), (float)((*((DWORD *)pInventoryThis(pWindowThis()) + 9))), (float)(*((DWORD *)pInventoryThis(pWindowThis()) + 10) + 379), gCustomMessage.GetMessage(13), 100, 0, 3, 0);
	}

	if (CheckMouseIn((*((DWORD *)pInventoryThis(pWindowThis()) + 9) + 13), (float)(*((DWORD *)pInventoryThis(pWindowThis()) + 10) + 390), 36, 29) && *(BYTE*)0x8793386) {
		RenderImage2(31370, (float)(*((DWORD *)pInventoryThis(pWindowThis()) + 9) + 13), (float)(*((DWORD *)pInventoryThis(pWindowThis()) + 10) + 390), 36, 29, 0, 0.45, 0.56, 0.40, 1, 1, 1.0);

		gTradeX.TradeXHiddenWindow();

		ResetMouseL();
	}
	else {
		RenderImage2(31370, (float)(*((DWORD *)pInventoryThis(pWindowThis()) + 9) + 13), (float)(*((DWORD *)pInventoryThis(pWindowThis()) + 10) + 390), 36, 29, 0, 0.0, 0.56, 0.40, 1, 1, 1.0);
	}
}

void CTradeX::RenderTextSource()
{
	char buffer[256];

	pTextSetFont(pTextThis(), g_hFont);

	pSetTextColor(pTextThis(), 225, 225, 225, 255);

	if (this->m_SourceAcceptTradeX) {
		sprintf_s(buffer, gCustomMessage.GetMessage(14));
	}
	else {
		sprintf_s(buffer, gCustomMessage.GetMessage(15));
	}

	pDrawText(pTextThis(), this->m_PosX + 31, this->m_PosY + 260, buffer, 190, 0, 1, 0);

	pTextSetFont(pTextThis(), g_hFontBold);

	pSetTextColor(pTextThis(), 240, 240, 240, 255);

	pDrawText(pTextThis(), this->m_PosX + 20, this->m_PosY + 277, gCustomMessage.GetMessage(16), 190, 0, 1, 0);

	sprintf_s(buffer, gCustomMessage.GetMessage(17), this->m_TradeItemSource.size());

	pDrawText(pTextThis(), this->m_PosX + 165, this->m_PosY + 277, buffer, 190, 0, 7, 0);
}

void CTradeX::RenderTextTarget()
{
	char buffer[256];

	pTextSetFont(pTextThis(), g_hFont);

	pSetTextColor(pTextThis(), 225, 225, 225, 255);

	
	if (this->m_TargetAcceptTradeX) {
		sprintf_s(buffer, gCustomMessage.GetMessage(18), NameTarget);
	}
	else {
		sprintf_s(buffer, gCustomMessage.GetMessage(19), NameTarget);
	}

	pDrawText(pTextThis(), this->m_PosX + 31, this->m_PosY + 89, buffer, 190, 0, 1, 0);

	pTextSetFont(pTextThis(), g_hFontBold);

	pSetTextColor(pTextThis(), 240, 240, 240, 255);

	sprintf_s(buffer, gCustomMessage.GetMessage(20), NameTarget);

	pDrawText(pTextThis(), this->m_PosX + 20, this->m_PosY + 107, buffer, 190, 0, 1, 0);

	sprintf_s(buffer, gCustomMessage.GetMessage(21), this->m_TradeItemTarget.size());

	pDrawText(pTextThis(), this->m_PosX + 165, this->m_PosY + 107, buffer, 190, 0, 7, 0);
}

void CTradeX::RenderBoxItem(float x, float y, float width, float height)
{
	EnableAlphaTest(1);

	glColor4f(0.0f, 0.0f, 0.0f, 0.3f);

	pDrawBarForm(x, y, width, height, 0.0, 0);

	glColor4f(0.0f, 0.0f, 0.0f, 0.5f);

	pDrawBarForm(x, y, width, height, 0.0, 0);

	glColor4f(0.2f, 0.2f, 0.2f, 0.6f);

	pDrawBarForm(x, y-1, width+1, 13.0, 0.0, 0);

	((void(*)())0x637A30)();
	DisableAlphaBlend();

	EnableAlphaTest(1);

	RenderImage(31340, x - 4, y - 3, 14.0, 14.0);
	RenderImage(31341, x + width - 9, y - 3, 14.0, 14.0);
	RenderImage(31342, x - 4, y + height - 8, 14.0, 14.0);
	RenderImage(31343, x + width - 9, y + height - 8, 14.0, 14.0);

	for (int i = x - 4 + 14; i<x + width - 9; i++)
	{
		RenderImage(31344, i, y - 3, 1, 14);
		RenderImage(31345, i,y + height - 8, 1, 14);
	}

	for (int i = y + 11; i < y + height - 8; i++)
	{
		RenderImage(31346, x - 4, i, 14, 1);
		RenderImage(31347, x + width - 9, i, 14, 1);
	}
}

void CTradeX::RenderItensSource()
{
	float SizeY = 290;

	char buffer[256];

	pTextSetFont(pTextThis(), g_hFont);

	int LineStart = 0;
	int LineCount = 0;

	for (auto &itemSource : this->m_TradeItemSource) {
		if (LineStart >= SourceScrollBarOffset && LineCount < 7) {
			if (!itemSource.pItemObj) {
				continue;
			}

			if (pCursorX >= this->m_PosX + 20 && pCursorX <= this->m_PosX + 130) {
				if (pCursorY >= this->m_PosY + SizeY && pCursorY <= this->m_PosY + (SizeY + 8)) {
					this->ItemPointer = itemSource.slot;
					RenderItemInformation(this->m_PosX - 100, this->m_PosY + 125, itemSource.pItemObj);
				}
			}

			auto itemAttr = pGetItemAttr(itemSource.pItemObj->Type);

			if (!itemAttr) {
				continue;
			}

			pSetTextBgColor2(pTextThis(), 0);

			pTextSetFont(pTextThis(), g_hFont);

			pSetTextColor(pTextThis(), 225, 225, 225, 255);

			sprintf_s(buffer, "%s + %d", itemAttr->Name, (itemSource.pItemObj->Level >> 3) & 0xF);
			pDrawText(pTextThis(), this->m_PosX + 20, this->m_PosY + SizeY, buffer, 190, 0, 1, 0);

			SizeY += 10;
			LineCount++;
		}

		LineStart++;
	}
}

void CTradeX::RenderItensTarget()
{
	float SizeY = 120;

	char buffer[256];

	pTextSetFont(pTextThis(), g_hFont);

	int LineStart = 0;
	int LineCount = 0;

	for (auto &itemTarget : this->m_TradeItemTarget) {
		if (LineStart >= TargetScrollBarOffset && LineCount < 7) {
			if (!itemTarget.pItemObj) {
				continue;
			}

			if (pCursorX >= this->m_PosX + 20 && pCursorX <= this->m_PosX + 130) {
				if (pCursorY >= this->m_PosY + SizeY && pCursorY <= this->m_PosY + (SizeY + 8)) {
					this->ItemPointerTarget = itemTarget.slot;
					RenderItemInformation(this->m_PosX - 100, this->m_PosY + 125, itemTarget.pItemObj);
				}
			}

			auto itemAttr = pGetItemAttr(itemTarget.pItemObj->Type);

			if (!itemAttr) {
				continue;
			}

			pSetTextBgColor2(pTextThis(), 0);

			pSetTextColor(pTextThis(), 225, 225, 225, 255);

			pTextSetFont(pTextThis(), g_hFont);

			sprintf_s(buffer, "%s + %d", itemAttr->Name, (itemTarget.pItemObj->Level >> 3) & 0xF);
			pDrawText(pTextThis(), this->m_PosX + 20, this->m_PosY + SizeY, buffer, 190, 0, 1, 0);
			SizeY += 10;
			LineCount++;
		}

		LineStart++;
	}
}

void CTradeX::RenderItemInformation(float x, float y, ITEM * pItemObj)
{
	if (CheckWindowOpen(ObjWindow::ExpandInventory)) {
		return;
	}

	EnableAlphaTest(true);

	glColor4f(0.0f, 0.0f, 0.0f, 1.0f);

	pDrawBarForm(45, 40, 215.0f, 370.0f, 0.0, 0);

	((void(*)())0x637A30)();

	DisableAlphaBlend();

	EnableAlphaTest(true);

	((void(__thiscall*)(LPVOID, int, int, ITEM*, bool, int, bool))0x7E3E30)(((LPVOID(__thiscall*)(LPVOID This)) 0x861AA0)(pWindowThis()), (int)155, (int)130, pItemObj, 0, 0, 0);

	((void(*)())0x637A30)();

	DisableAlphaBlend();

	this->RenderItemImage(pItemObj);

	EnableAlphaTest(true);
}

void CTradeX::RenderItemImage(ITEM * pItemObj)
{
	glMatrixMode(0x1701);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(int, int, int, int))0x6363D0)(0, 0, *(GLsizei*)MAIN_RESOLUTION_X, *(GLsizei*)MAIN_RESOLUTION_Y);

	((void(*)(float, float, float, float))0x6358A0)(1.f, (float)(*(DWORD*)MAIN_RESOLUTION_X) / (float)(*(DWORD*)MAIN_RESOLUTION_Y), *(float*)0xE61E38, *(float*)0xE61E3C);

	glMatrixMode(0x1700);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(vec34_t))0x635830)(*(vec34_t*)0x87933A0);

	((void(*)())0x635DE0)();

	((void(*)())0x635E40)();

	auto lpAttr = pGetItemAttr(pItemObj->Type);

	float width = lpAttr->Width;
	float height = lpAttr->Height;

	((void(*)(float, float, float, float, int, int, int, int, bool))0x5CF310)((float)155, (float)100, (float)width*3, (float)height*4, (int)pItemObj->Type, (int)pItemObj->Level * 8, (int)pItemObj->Option1, (int)pItemObj->ExtOption, 0);

	glMatrixMode(0x1700);
	glPopMatrix();
	glMatrixMode(0x1701);
	glPopMatrix();

	glColor3f(1, 1, 1);
	pSetBlend(false);
}

void CTradeX::TargetInserItens(int slot, BYTE* ItemInfo)
{
	TradeItem info;

	info.pItemObj = ((ITEM*(__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemInfo);

	info.slot = slot;

	this->m_TradeItemTarget.push_back(info);

	this->CalcLinesRenderTarget();
}

void CTradeX::SourceInserItens(int slot, BYTE* ItemInfo)
{
	TradeItem info;

	info.pItemObj = ((ITEM*(__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemInfo);;

	info.slot = slot;

	this->m_TradeItemSource.push_back(info);

	this->CalcLinesRenderSource();
}

void CTradeX::DelItemTarget(BYTE slot)
{
	std::vector<TradeItem>::iterator li = this->m_TradeItemTarget.begin();

	for (; li != this->m_TradeItemTarget.end(); li++) {
		auto pItem = &(*li);

		if (pItem->slot == slot) {
			pItem->Clear();
			this->m_TradeItemTarget.erase(li);
			break;
		}
	}
}

void CTradeX::DelItemSource(BYTE slot)
{
	std::vector<TradeItem>::iterator li = this->m_TradeItemSource.begin();

	for (; li != this->m_TradeItemSource.end(); li++) {
		auto pItem = &(*li);

		if (pItem->slot == slot) {
			pItem->Clear();
			this->m_TradeItemSource.erase(li);
			break;
		}
	}
}

void CTradeX::CalcLinesRenderTarget()
{
	TargetScrollBarOffset = 0;
	TargetScrollBarPos = 0;
	TargetScrollBarMaxOffset = this->m_TradeItemTarget.size() - 8;
	TargetScrollBarMultiplier = (float)((float)50 / (float)(this->m_TradeItemTarget.size() - 8));
}

void CTradeX::CalcLinesRenderSource()
{
	SourceScrollBarOffset = 0;
	SourceScrollBarPos = 0;
	SourceScrollBarMaxOffset = this->m_TradeItemSource.size() - 8;
	SourceScrollBarMultiplier = (float)((float)50 / (float)(this->m_TradeItemSource.size() - 8));
}

void CTradeX::RenderScrollTarget(float x, float y, float width, float height)
{
	//Bar
	EnableAlphaTest(1);

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	RenderImage(31270, x + width - 11, y + 14, 7, 3);

	// IMAGEM DE ROLAMENTO

	for (int i = 0; i < 6; i++) {
		RenderImage(31271, x + width - 11, (y + 13) + (float)(i * 10 + 4), 7, 15);
	}

	RenderImage(31272, x + width - 11, y + height - 8, 7, 3);

	int Line = 0;

	if (m_EventStateTarget == EVENT_SCROLL_BTN_DOWN) {
		glColor4f(0.7f, 0.7f, 0.7f, 1.0f);
	}
	else {
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	}

	RenderImage(31273, ScrollBarPosXTarget, y + 10 + TargetScrollBarPos, 15, 30);

	DisableAlphaBlend();
}

void CTradeX::RenderScrollSource(float x, float y, float width, float height)
{
	//Bar
	EnableAlphaTest(1);

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	RenderImage(31270, x + width - 11, y + 14, 7, 3);

	for (int i = 0; i < 6; i++) {
		RenderImage(31271, x + width - 11, (y + 13) + (float)(i * 10 + 4), 7, 15);
	}

	RenderImage(31272, x + width - 11, y + height - 8, 7, 3);

	if (m_EventStateSource == EVENT_SCROLL_BTN_DOWN) {
		glColor4f(0.7f, 0.7f, 0.7f, 1.0f);
	}
	else {
		glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
	}

	RenderImage(31273, ScrollBarPosXSource, y + 10 + SourceScrollBarPos, 15, 30);

	DisableAlphaBlend();
}

void CTradeX::ScrollLinesTarget(int mode)
{
	if (mode == 0) { //Up
		if (TargetScrollBarOffset > 0) {
			TargetScrollBarOffset = TargetScrollBarOffset - 1;
			TargetScrollBarPos = TargetScrollBarPos - TargetScrollBarMultiplier;
		}
	}
	else if (mode == 1) { //Down
		if (TargetScrollBarOffset < TargetScrollBarMaxOffset) {
			TargetScrollBarOffset = TargetScrollBarOffset + 1;
			TargetScrollBarPos = TargetScrollBarPos + TargetScrollBarMultiplier;
		}
	}
}

void CTradeX::ScrollLinesSource(int mode)
{
	if (mode == 0) { //Up
		if (SourceScrollBarOffset > 0) {
			SourceScrollBarOffset = SourceScrollBarOffset - 1;
			SourceScrollBarPos = SourceScrollBarPos - SourceScrollBarMultiplier;
		}
	}
	else if (mode == 1) { //Down
		if (SourceScrollBarOffset < SourceScrollBarMaxOffset) {
			SourceScrollBarOffset = SourceScrollBarOffset + 1;
			SourceScrollBarPos = SourceScrollBarPos + SourceScrollBarMultiplier;
		}
	}
}

void CTradeX::MouseWheel(MOUSEHOOKSTRUCTEX * lpMouse)
{
	//Target
	if (CheckMouseIn(this->m_PosX + 15, this->m_PosY + 105, 160, 90)) {
		if (((int)lpMouse->mouseData) > 0) {
			this->ScrollLinesTarget(0);
		}

		if (((int)lpMouse->mouseData) < 0) {
			this->ScrollLinesTarget(1);
		}
		return;
	}

	//Source
	if (CheckMouseIn(this->m_PosX + 15, this->m_PosY + 275, 160, 90)) {
		if (((int)lpMouse->mouseData) > 0) {
			this->ScrollLinesSource(0);
		}

		if (((int)lpMouse->mouseData) < 0) {
			this->ScrollLinesSource(1);
		}
		return;
	}
}

void CTradeX::ClearTradeXSource()
{
	std::vector<TradeItem>::iterator li = this->m_TradeItemSource.begin();

	for (; li != m_TradeItemSource.end(); li++) {
		auto SourceItem = &(*li);

		if (SourceItem->pItemObj) {
			((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), SourceItem->pItemObj);
			SourceItem->pItemObj = nullptr;
		}
	}

	m_TradeItemSource.clear();

	this->CalcLinesRenderSource();
}

void CTradeX::ClearTradeXTarget()
{
	std::vector<TradeItem>::iterator li = this->m_TradeItemTarget.begin();

	for (; li != m_TradeItemTarget.end(); li++) {
		auto TargetItem = &(*li);

		if (TargetItem->pItemObj) {
			((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), TargetItem->pItemObj);
			TargetItem->pItemObj = nullptr;
		}
	}

	m_TradeItemTarget.clear();

	this->CalcLinesRenderTarget();
}

int CTradeX::CountTimeTradeX(DWORD tick)
{
	return TimeTradeX - tick;
}

void CTradeX::TradeXHiddenWindow()
{
	PMSG_TRADEX_HIDDEN_WINDOW_RECV pMsg;

	pMsg.header.set(0xF3, 0xC1, sizeof(pMsg));

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void CTradeX::RenderIconTradeExtended()
{
	if (this->TradeXHidden) {
		RenderImage2(TradeXIconID, 90, 30, 22.0, 20.f, 0.0, 0.0, 101.f / 128.f, 101.f / 128.f, 1, 1, 0.0);

		if (CheckMouseIn(90, 30, 22, 20)) {
			EnableAlphaTest(1);

			pTextSetFont(pTextThis(), g_hFont);

			pSetTextColor(pTextThis(), 225, 225, 225, 255);

			pSetTextBgColor(pTextThis(), 0, 0, 0, 255);

			pDrawText(pTextThis(), 75, 50, gCustomMessage.GetMessage(22), 100, 0, 3, 0);

			DisableAlphaBlend();
		}
	}
}

void CTradeX::UpdateMouseEventTradeExtended()
{
	if (TradeXHidden) {
		if (CheckMouseIn(90, 30, 22, 20) && *(BYTE*)0x8793386) {
			ResetMouseL();

			this->TradeXOpenWindow();

			this->ClickEvent = GetTickCount();
		}
	}
}

void CTradeX::TradeXOpenWindow()
{
	PMSG_TRADEX_OPEN_WINDOW_SEND pMsg;

	pMsg.header.set(0xF3, 0xC0, sizeof(pMsg));

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void CTradeX::GCTradeResponseRecv(PMSG_TRADE_RESPONSE_RECV * lpMsg)
{
	if (lpMsg->TradeX) {
		std::memcpy(this->NameTarget, lpMsg->name, sizeof(this->NameTarget));

		this->ClearTradeXSource();
		this->ClearTradeXTarget();

		this->Open();

		this->m_TargetAcceptTradeX = 0;
		this->m_SourceAcceptTradeX = 0;
	}
	else {
		this->m_isVisible = 0;
	}
}

void CTradeX::TradeXItemAddRecv(PMSG_TRADEX_ITEM_ADD_RECV * lpMsg)
{
	this->TargetInserItens(lpMsg->slot, lpMsg->ItemInfo);
	this->CalcLinesRenderTarget();
}

void CTradeX::TradeXStateRecv(PMSG_TRADEX_STATE_RECV * lpMsg)
{
	if (lpMsg->state == 2) {
		this->TradeXHidden = 0;
		this->m_isVisible = 0;
		this->TradeXTransation = lpMsg->Transation;

		std::memset(this->NameTarget, 0, sizeof(this->NameTarget));

		this->ClearTradeXSource();
		this->CalcLinesRenderSource();
		this->ClearTradeXTarget();
		this->CalcLinesRenderTarget();

		CloseWindow(ObjWindow::Inventory);
	}
	else if (lpMsg->state == 1) {
		this->TradeXHidden = 1;
		this->TradeXTransation = lpMsg->Transation;
		this->m_isVisible = 0;

		CloseWindow(ObjWindow::Inventory);
	}
	else if (lpMsg->state == 3) {
		this->ClearTradeXSource();
		this->CalcLinesRenderSource();
		this->ClearTradeXTarget();
		this->CalcLinesRenderTarget();

		TradeXTransation = 1;
	}
	else if (lpMsg->state == 4) {
		this->ClearTradeXTarget();
		this->CalcLinesRenderTarget();

		TradeXTransation = 2;
	}
	else if (lpMsg->state == 5) {
		this->TradeXTransation = 0;
		this->m_TargetAcceptTradeX = 0;
		this->TimeTradeX = 10;
	}
}

void CTradeX::TradeXListRecv(PMSG_TRADEX_ITEM_LIST_RECV * lpMsg)
{
	if (lpMsg->count <= 0) {
		return;
	}

	for (int n = 0; n < lpMsg->count; n++) {
		auto lpInfo = (PMSG_TRADEX_ITEM_RECV*)(((BYTE*)lpMsg) + sizeof(PMSG_TRADEX_ITEM_LIST_RECV) + (sizeof(PMSG_TRADEX_ITEM_RECV)*n));

		if (lpMsg->target == 1) {
			this->TargetInserItens(lpInfo->slot, lpInfo->ItemInfo);
		}
		else {
			this->SourceInserItens(lpInfo->slot, lpInfo->ItemInfo);
		}
	}

	if (lpMsg->target == 1) {
		this->CalcLinesRenderTarget();
	}
	else {
		this->CalcLinesRenderSource();
	}
}

void CTradeX::TradeXDelItemTarget(PMSG_TRADEX_ITEM_DEL_RECV * lpMsg)
{
	this->DelItemTarget(lpMsg->slot);
	this->CalcLinesRenderTarget();
}

void CTradeX::TradeXOkButtonRecv(PMSG_TRADE_OK_BUTTON_RECV * lpMsg)
{
	if (lpMsg->tradeX == 1) {
		if (lpMsg->flag == 0) {
			this->m_TargetAcceptTradeX = 0;

			this->TimeTradeX = 10;
			this->TickBlockOk = GetTickCount();
		}
		else if (lpMsg->flag == 1) {
			this->m_TargetAcceptTradeX = 1;
		}
		else if (lpMsg->flag == 2) {
			this->m_SourceAcceptTradeX = 0;

			this->TimeTradeX = 10;
			this->TickBlockOk = GetTickCount();
		}
		else if (lpMsg->flag == 3) {
			this->m_SourceAcceptTradeX = 1;
		}
	}
}

void CTradeX::TradeXResultRecv(PMSG_TRADE_RESULT_RECV * lpMsg)
{
	if (lpMsg->tradeX == 1) {
		if (lpMsg->result == 1) {
			this->ClearTradeXSource();
			this->ClearTradeXTarget();

			this->TradeXTransation = 1;
		}
	}
}

bool CTradeX::CheckTradeXSourceEmptySlot()
{
	if (this->m_TradeItemSource.size() < 120) {
		return 1;
	}

	return 0;
}

void CTradeX::MoveItemFromInventory()
{
	gItemMove.m_InventoryCtrlMix = 0;

	gItemMove.m_BackupMouseX = pCursorX;
	gItemMove.m_BackupMouseY = pCursorY;

	int PointedSlot = *((DWORD *)pInventoryThis(pWindowThis()) + 71);

	bool IsExtInv = ((bool(__thiscall*)(LPVOID This)) 0x007D5200)(((LPVOID(__thiscall*)(LPVOID))0x861A60)(pWindowThis()));

	if (IsExtInv == 1 && PointedSlot == -1) {
		if (this->CheckTradeXSourceEmptySlot() == 0)
		{
			return;
		}

		DWORD ItemExpanded1 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), pCursorX, pCursorY);
		DWORD ItemExpanded2 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), pCursorX, pCursorY);

		if (ItemExpanded1 != -1) {
			DWORD InventoryCtrl = -1;
			ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

			if (pItemObj) {
				auto itemAttribute = pGetItemAttr(pItemObj->Type);

				int slotEmpty = pInventoryCtrlFindEmptySlot(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), itemAttribute->Width, itemAttribute->Height);

				if (slotEmpty != -1) {
					gItemMove.m_BackupSlot = ItemExpanded1 + 76;
					gItemMove.m_BackupTargetSlot = slotEmpty;
					SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, gItemMove.m_BackupTargetSlot, MovePosition::TradeX);
					ResetMouseR();
					gItemMove.m_ItemMove = 1;
					gItemMove.m_DeleteInventoryCtrl = 1;
				}
			}
		}
		else if (ItemExpanded2 != -1) {
			DWORD InventoryCtrl = -1;
			ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

			if (pItemObj) {
				auto itemAttribute = pGetItemAttr(pItemObj->Type);

				int slotEmpty = pInventoryCtrlFindEmptySlot(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), itemAttribute->Width, itemAttribute->Height);

				if (slotEmpty != -1) {
					gItemMove.m_BackupSlot = ItemExpanded2 + 108;
					gItemMove.m_BackupTargetSlot = slotEmpty;
					SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, gItemMove.m_BackupTargetSlot, MovePosition::TradeX);
					ResetMouseR();
					gItemMove.m_ItemMove = 1;
					gItemMove.m_DeleteInventoryCtrl = 1;
				}
			}
		}
		else {
			DWORD InventoryCtrl = -1;
			ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

			if (pItemObj != nullptr) {
				auto itemAttribute = pGetItemAttr(pItemObj->Type);

				if (itemAttribute) {
					gItemMove.m_BackupTargetSlot = -1;
					gItemMove.m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
					SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, -1, MovePosition::TradeX);
					ResetMouseR();
					gItemMove.m_ItemMove = 1;
					gItemMove.m_DeleteInventoryCtrl = 1;
				}
			}
		}
	}
	else {
		if (PointedSlot != -1) {
			if (gItemMove.CheckItemEquiped(PointedSlot)) {
				auto item = gItemMove.getItem(PointedSlot);

				if (item->Type != -1) {
					auto itemAttribute = pGetItemAttr(item->Type);

					int value = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttribute->Width, itemAttribute->Height);

					if (value != -1) {
						gItemMove.m_BackupSlot = PointedSlot;
						gItemMove.m_BackupTargetSlot = value + 12;
						SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, gItemMove.m_BackupTargetSlot, MovePosition::Inventory);
						ResetMouseR();
						gItemMove.m_ItemMove = 1;
						gItemMove.m_DeleteInventoryCtrl = 0;
					}
				}
			}
		}
		else {
			if (this->CheckTradeXSourceEmptySlot() == 0)
			{
				return;
			}

			DWORD InventoryCtrl = -1;
			ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

			if (pItemObj != nullptr) {
				auto itemAttribute = pGetItemAttr(pItemObj->Type);

				if (itemAttribute) {
					gItemMove.m_BackupTargetSlot = -1;
					gItemMove.m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
					SendItemMove(gItemMove.m_BackupSlot, MovePosition::Inventory, -1, MovePosition::TradeX);
					ResetMouseR();
					gItemMove.m_ItemMove = 1;
					gItemMove.m_DeleteInventoryCtrl = 1;
				}
			}
		}
	}
}

void CTradeX::MoveItemToInventory()
{
	if (!this->CheckMouse()) {
		return;
	}

	if (gItemMove.checkAutoItemMove()) {
		return;
	}

	float SizeY = 290;
	int LineStart = 0;
	int LineCount = 0;

	for (auto &itemSource : this->m_TradeItemSource) {
		if (LineStart >= SourceScrollBarOffset && LineCount < 7) {
			if (!itemSource.pItemObj) {
				continue;
			}

			if (pCursorX >= this->m_PosX + 20 && pCursorX <= this->m_PosX + 130) {
				if (pCursorY >= this->m_PosY + SizeY && pCursorY <= this->m_PosY + (SizeY + 8)) {
					auto itemAttr = pGetItemAttr(itemSource.pItemObj->Type);

					if (itemAttr) {
						int slotInventory = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttr->Width, itemAttr->Height);

						if (slotInventory == -1) {
							int slotEmptyInv1 = pInventoryCtrlFindEmptySlot(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), itemAttr->Width, itemAttr->Height);

							if (slotEmptyInv1 == -1) {
								int slotEmptyInv2 = pInventoryCtrlFindEmptySlot(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), itemAttr->Width, itemAttr->Height);

								if (slotEmptyInv2 != -1) {
									gItemMove.m_BackupSlot = itemSource.slot;
									gItemMove.m_BackupTargetSlot = slotInventory + 108;
									SendItemMove(gItemMove.m_BackupSlot, MovePosition::TradeX, gItemMove.m_BackupTargetSlot, MovePosition::Inventory);
									ResetMouseR();
									gItemMove.m_ItemMove = 1;
									gItemMove.m_InventoryCtrlMix = 0;
									gItemMove.m_DeleteInventoryCtrl = 0;
								}
							}
							else {
								gItemMove.m_BackupSlot = itemSource.slot;
								gItemMove.m_BackupTargetSlot = slotInventory + 76;
								SendItemMove(gItemMove.m_BackupSlot, MovePosition::TradeX, gItemMove.m_BackupTargetSlot, MovePosition::Inventory);
								ResetMouseR();
								gItemMove.m_ItemMove = 1;
								gItemMove.m_InventoryCtrlMix = 0;
								gItemMove.m_DeleteInventoryCtrl = 0;
							}
						}
						else {
							gItemMove.m_BackupSlot = itemSource.slot;
							gItemMove.m_BackupTargetSlot = slotInventory + 12;
							SendItemMove(gItemMove.m_BackupSlot, MovePosition::TradeX, gItemMove.m_BackupTargetSlot, MovePosition::Inventory);
							ResetMouseR();
							gItemMove.m_ItemMove = 1;
							gItemMove.m_InventoryCtrlMix = 0;
							gItemMove.m_DeleteInventoryCtrl = 0;
						}
					}
				}
			}

			SizeY += 10;
			LineCount++;
		}

		LineStart++;
	}
}

