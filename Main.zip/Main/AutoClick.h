#pragma once

class CAutoClick
{
public:
	CAutoClick();
	virtual ~CAutoClick();

	void CreateAutoClick();
	static DWORD WINAPI AutoClickWorker(CAutoClick* AutoClick);

	bool m_ClickRight;
	bool m_ClickLeft;

private:
	HANDLE m_Theread;
	POINT CursorCoords;
};

extern CAutoClick gAutoClick;