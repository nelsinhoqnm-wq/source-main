#include "stdafx.h"
#include "ElementSystem.h"
#include "LuaStack.hpp"
#include "LuaObject.h"

using namespace luaaa;
CElementSystem gElementSystem;

CElementSystem::CElementSystem() : m_Lua(true)
{
	this->m_ElementInfo.clear();
}

CElementSystem::~CElementSystem()
{
	//this->m_ElementInfo.clear();
}

void SetElementPet(int ItemIndex) {
	/*ELEMENT_INFO info;

	info.ItemIndex = ItemIndex;

	info.Type = 1;

	info.Movement = Movement;

	info.HeightFloor = Height;

	info.Size = Size;

	strcpy_s(info.Model, Model);

	strcpy_s(info.ObjectModel, ObjectModel);

	g
	System.m_
	
	
	Info.insert(std::make_pair(ItemIndex, info));*/
}

void CElementSystem::Init()
{
	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());

	this->m_LuaEffects.RegisterLuaClass(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("SetElementPet", &SetElementPet);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//ElementPet.lua");

	this->m_Lua.Generic_Call("LoadElementPet", ">");
}

ELEMENT_INFO * CElementSystem::GetElement(int ItemIndex)
{
	std::map<int, ELEMENT_INFO>::iterator it = this->m_ElementInfo.find(ItemIndex);

	if (it == this->m_ElementInfo.end()) {
		return nullptr;
	}

	return &it->second;
}
