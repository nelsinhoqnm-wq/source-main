#include "StdAfx.h"
#include "Hunting.h"
#include <sstream>
#include <filesystem>

struct dotted : std::numpunct<char> {
	char do_thousands_sep()   const { return '.'; }  // separate with dots
	std::string do_grouping() const { return "\3"; } // groups of 3 digits
	static void imbue(std::ostream& os) {
		os.imbue(std::locale(os.getloc(), new dotted));
	}
};

std::string dotInt(uint32_t value) {
	std::stringstream damagess;
	dotted::imbue(damagess);
	damagess << value;
	return damagess.str();
}

Hunting gHunting;

Hunting::Hunting()
{
	experienceNow = 0;
	lastExperience = 0;
	experience = 0;
	media = 0;
	lastZen = 0;
	mediaZen = 0;
}

Hunting::~Hunting()
{
}

void Hunting::ReceiveHunting(PMSG_CHARACTER_HUNTING_INFO_RECV * lpMsg)
{
	level = lpMsg->level;
	experienceNow = lpMsg->experienceNow;
	lastExperience = lpMsg->lastExperience;
	experience = lpMsg->experience;
	media = lpMsg->media;
	lastZen = lpMsg->lastZen;
	mediaZen = lpMsg->mediaZen;

	expperMinute = dotInt(experience);
	expNow = dotInt(experienceNow);
	LastExp = dotInt(lastExperience);

	lastZenc = dotInt(lastZen);
	mediaZenc = dotInt(mediaZen);
}
