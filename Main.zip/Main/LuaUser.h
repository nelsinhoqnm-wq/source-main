#pragma once

#include "Lua.h"

class CLuaUser {
public:
	CLuaUser();
	~CLuaUser();

	void RegisterLuaUser(lua_State* lua);

private:
	static BOOL LuaUserMap(lua_State * Lua)
	{
		lua_pushnumber(Lua, pMapNumber);
		return true;
	};

	static BOOL LuaUserGetName(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushstring(Lua, lpUser->Name);
		return true;
	};

	static BOOL LuaUserGetKey(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, lpUser->aIndex);
		return true;
	};

	static BOOL LuaUserPositionX(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		DWORD PosX = (DWORD)(lpUser->Object.Position[0] / 100.f);

		lua_pushnumber(Lua, (DWORD)(PosX > 0 ? PosX : 0));
		return true;
	};

	static BOOL LuaUserPositionY(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		DWORD PosY = (DWORD)(lpUser->Object.Position[1] / 100.f);

		lua_pushnumber(Lua, (DWORD)(PosY > 0 ? PosY : 0));
		return true;
	};

	static BOOL LuaUserGetHelper(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->PetSlot != (WORD)-1 ? (lpUser->PetSlot - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetWing(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->WingsSlot != (WORD)-1 ? (lpUser->WingsSlot - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetSword(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->WeaponFirstSlot != (WORD)-1 ? (lpUser->WeaponFirstSlot - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetShield(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->WeaponSecondSlot != (WORD)-1 ? (lpUser->WeaponSecondSlot - 1171) : -1));
		return true;
	};

	static BOOL LuaUserUserGetHelm(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->BodyPart[BODYPART_HELM].Type != (WORD)-1 ? (lpUser->BodyPart[BODYPART_HELM].Type - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetArmor(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->BodyPart[BODYPART_ARMOR].Type != (WORD)-1 ? (lpUser->BodyPart[BODYPART_ARMOR].Type - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetPants(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->BodyPart[BODYPART_PANTS].Type != (WORD)-1 ? (lpUser->BodyPart[BODYPART_PANTS].Type - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetGloves(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->BodyPart[BODYPART_GLOVES].Type != (WORD)-1 ? (lpUser->BodyPart[BODYPART_GLOVES].Type - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetBoots(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->BodyPart[BODYPART_BOOTS].Type != (WORD)-1 ? (lpUser->BodyPart[BODYPART_BOOTS].Type - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetRing(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->BodyPart[BODYPART_RING].Type != (WORD)-1 ? (lpUser->BodyPart[BODYPART_RING].Type - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetPendant(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->BodyPart[BODYPART_PENDANT].Type != (WORD)-1 ? (lpUser->BodyPart[BODYPART_PENDANT].Type - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetArtifact(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->BodyPart[BODYPART_ARTIFACT].Type != (WORD)-1 ? (lpUser->BodyPart[BODYPART_ARTIFACT].Type - 1171) : -1));
		return true;
	};

	static BOOL LuaUserGetLevel(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, lpUser->Level);
		return true;
	};

	static BOOL LuaUserGetClass(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;
		lua_pushnumber(Lua, (lpUser->Class & 7));
		return true;
	};

	static BOOL LuaUserGetGuild(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;

		WORD guildIndex = lpUser->GuildMarkIndex;

		if (lpUser->GuildMarkIndex != (WORD)-1) {
			lua_pushnumber(Lua, guildIndex);
		}
		else {
			lua_pushnumber(Lua, -1);
		}
		return true;
	};

	static BOOL LuaGuildGetName(lua_State * Lua)
	{
		lpViewObj lpUser = &*(ObjectPreview*)oUserPreviewStruct;

		if (lpUser->GuildMarkIndex != (WORD)-1) {
			char * gname = (char*)&*(BYTE*)(0x81CB595 + 88 * lpUser->GuildMarkIndex);

			lua_pushstring(Lua, strlen(gname) <= 0 ? " " : gname);
		}
		else {
			lua_pushstring(Lua, " ");
		}
		return true;
	};
};