#include "stdafx.h"
#include "HotKey.h"
#include "Interface.h"
#include "TradeX.h"
#include "ChaosBoxGenesis.h"
#include "Camera.h"
#include "WindowTray.h"
#include "PersonalShop.h"
#include "LoadFiles.h"
#include "resource.h"

BOOL VKF7_State = 0;

// F8 - alterna o botao direito do mouse (pressionado/solto)
BOOL VKF8_RightMouse = FALSE;

HotKey gHotKey;

HotKey::HotKey()
{

}

HotKey::~HotKey()
{

}

void __declspec(naked) iconHook()  //Custom Icon
{
	static DWORD dwIcon = (DWORD)LoadIcon(gHotKey.hIstance, MAKEINTRESOURCE(IDI_ICON8));
	static DWORD dwJmp = 0x004D0E3C;

	_asm
	{
		MOV EAX, dwIcon
		JMP dwJmp
	}
}

void HotKey::InitKeyBoard(HINSTANCE hins)
{
	this->HookKB = SetWindowsHookEx(WH_KEYBOARD, this->KeyboardProc, hins, GetCurrentThreadId());
	this->HookMS = SetWindowsHookEx(WH_MOUSE, this->MouseProc, hins, GetCurrentThreadId());

	this->hIstance = hins;

	SetCompleteHook(0xE8, 0x004D0E2F, iconHook);
}

LRESULT CALLBACK HotKey::KeyboardProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (GetForegroundWindow() != MAIN_WINDOW)
	{
		return CallNextHookEx(gHotKey.HookKB, nCode, wParam, lParam);
	}

	if (*(DWORD*)MAIN_SCREEN_STATE == 5) {
		if (nCode == HC_ACTION)
		{
			if (((DWORD)lParam & (1 << 30)) != 0 && ((DWORD)lParam & (1 << 31)) != 0)
			{
				gInterface.m_Lua.Generic_Call("MainProcWorldKey", "i>", wParam);

				if (gLoadFiles.m_LoadFiles.m_CustomPersonalShop == 1) {
					if (wParam >= 0x30 && wParam <= 0x39
						|| wParam >= 0x60 && wParam <= 0x69)
					{
						gPersonalShop.InsertKeyInInput(wParam);
					}
				}
			}

			if (gLoadFiles.m_LoadFiles.m_CustomPersonalShop == 1) {
				if (wParam == 0x8)
				{
					gPersonalShop.RemoveKeyInInput();
				}
			}

			// F8: alterna o botao direito do mouse.
			// Bit 31 = 0: tecla pressionada. Bit 30 = 0: primeiro pressionamento,
			// evitando que a repeticao automatica do teclado alterne varias vezes.
			if (wParam == VK_F8 &&
				((DWORD)lParam & (1 << 31)) == 0 &&
				((DWORD)lParam & (1 << 30)) == 0)
			{
				if (VKF8_RightMouse == FALSE)
				{
					VKF8_RightMouse = TRUE;

					// Mantem o botao direito realmente pressionado ate o proximo F8.
					mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
				}
				else
				{
					VKF8_RightMouse = FALSE;

					// Libera o botao direito no segundo pressionamento do F8.
					mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);
				}
			}

			switch (wParam)
			{
			//case VK_F7: // CLICA E ANDA
			//	if (GetForegroundWindow() == *(HWND*)(MAIN_WINDOW))
			//	{
			//		VKF7_State ^= 1;
			//		SendMessage(*(HWND*)(MAIN_WINDOW), WM_LBUTTONUP, VK_F7, MK_LBUTTON);
			//	}
			//	break;
			//default:
				break;
			}
		}
	}

	return CallNextHookEx(gHotKey.HookKB, nCode, wParam, lParam);
}


LRESULT CALLBACK HotKey::MouseProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (GetForegroundWindow() != MAIN_WINDOW)
	{
		return CallNextHookEx(gHotKey.HookMS, nCode, wParam, lParam);
	}

	if (nCode == HC_ACTION)
	{
		MOUSEHOOKSTRUCTEX* HookStruct = (MOUSEHOOKSTRUCTEX*)lParam;

		switch (wParam)
		{
		case WM_MOUSEWHEEL:
			gTradeX.MouseWheel(HookStruct);
			gChaosBoxGenesis.Scrolling(HookStruct->mouseData);
			gCamera.Zoom(HookStruct);
			gInterface.m_Lua.Generic_Call("ScrollMouse", "i>", HookStruct->mouseData);
			break;
		case WM_MOUSEMOVE:
			gCamera.Move(HookStruct);
			break;
		case WM_MBUTTONDOWN:
			gCamera.SetIsMove(1);
			gCamera.SetCursorX(HookStruct->pt.x);
			gCamera.SetCursorY(HookStruct->pt.y);
			break;
		case WM_MBUTTONUP:
			gCamera.SetIsMove(0);
			break;
		case WM_LBUTTONUP:
		case WM_LBUTTONDOWN:
		#if(DOWNGRADE)
		gInterface.EventNewInterface97_All(wParam);
		gInterface.SelectCharButton(wParam);
		#endif
		break;
		default:
			break;
		}
	}

	if (nCode == HC_ACTION)
	{
		MOUSEHOOKSTRUCTEX* HookStruct = (MOUSEHOOKSTRUCTEX*)lParam;

		switch (wParam)
		{
		case WM_RBUTTONUP:
			if (*(DWORD*)MAIN_SCREEN_STATE == 5) {
				gInterface.m_Lua.Generic_Call("InterfaceClickRightEvent", ">");
			}
			break;
		case WM_LBUTTONUP:
			if (*(DWORD*)MAIN_SCREEN_STATE == 5) {
				gInterface.m_Lua.Generic_Call("InterfaceClickEvent", ">");
			}
			break;
		default:
			break;
		}
	}

	return CallNextHookEx(gHotKey.HookMS, nCode, wParam, lParam);
}

LRESULT HotKey::Window(HWND Window, DWORD Message, WPARAM wParam, LPARAM lParam)
{
	switch (Message)
	{
		case TRAYMODE_ICON_MESSAGE:
		{
			switch (lParam)
			{
				case WM_LBUTTONDBLCLK:
					gTrayMode.SwitchState();
					break;
			}
		}
		break;
	}

	return CallWindowProc((WNDPROC)gTrayMode.TempWindowProc, Window, Message, wParam, lParam);
}


