#pragma once

#include "Protocol.h"
#include "Lua.h"
#include "LuaLoadImage.h"
#include "LuaInterface.h"
#include "LuaCharacter.h"
#include "LuaBMD.h"
#include "LuaGlobal.h"

struct PMSG_VIEWPORT_RECV
{
	PSWMSG_HEAD header; // C2:[12:13:1F:20:45:65:68]
	BYTE count;
};

struct PMSG_VIEWPORT_PATENT
{
	BYTE index[2];
	DWORD patent;
	BYTE type;
};

class PATENT_MODEL_INFO {
public:
	PATENT_MODEL_INFO() {
		this->PatentIndex = 0;
		memset(this->ModelFolder, 0, sizeof(this->ModelFolder));
		memset(this->ModelName, 0, sizeof(this->ModelName));
	};

	~PATENT_MODEL_INFO() {

	};

	int PatentIndex;
	char ModelFolder[50];
	char ModelName[50];
};

class PATENTE_PLAYER_INFO {
public:
	PATENTE_PLAYER_INFO() {
		this->aIndex = -1;
		this->Patente = 0;
		this->Type = 0;
	};
	~PATENTE_PLAYER_INFO() {

	};

	WORD aIndex;
	DWORD Patente;
	BYTE Type;
};

class CPatente {
public:
	CPatente();
	~CPatente();

	void RestartLua();
	void Init();
	void Clear();
	void StartLoadImage();
	void Resolution();
	//void GetResolution();
	void GCPatentePlayerRecv(PMSG_VIEWPORT_RECV* lpMsg);
	void PatentModelSetIndex(int PatentIndex, int ModelIndex);
	PATENTE_PLAYER_INFO* GetPlayer(int aIndex);
	bool IsPlayer(int aindex, int patent, BYTE type);
	void DeletePlayer(int aIndex);
	void MainProc();
	int PatentModelRender(DWORD BMDStruct, DWORD ObjectStruct, DWORD ItemIndex);

public:
	Lua m_Lua;
	std::map<int, PATENT_MODEL_INFO> m_PatentModelInfo;

private:
	std::vector<PATENTE_PLAYER_INFO> m_PlayerInfo;
	LuaGlobal m_LuaGlobal;

private:
	LuaLoadImage m_LuaLoadImage;
	LuaInterface m_LuaInterface;
	CLuaCharacter m_LuaCharacter;
	LuaBMD m_LuaBMD;
};

extern CPatente gPatente;