#pragma once

#define MAX_ITEM_SPECIAL     8
#define MAX_SOCKETS          5
#define SOCKET_EMPTY         0xFF
#define MAX_CHAT_TYPE1			10

struct MUChatType	//-> 24
{
	DWORD a1;
	DWORD a2;
	DWORD a3;
	/*+12*/	DWORD	Unknown12;
	/*+16*/	DWORD	Unknown16;
	/*+20*/	DWORD	Unknown20;
};

struct MUChat
{
	BYTE	Gap0[4];
	//DWORD Unknown0;
	/*+4*/		DWORD	Unknown4;
	/*+8*/		DWORD	Unknown8;
	/*+12*/		DWORD	Unknown12;
	/*+16*/		MUChatType ChatType[MAX_CHAT_TYPE1];
	/*+256*/	bool	IsActiveChatType[MAX_CHAT_TYPE1];
	BYTE gap266[26];
	/*+268*/	//SomeType LPVOID;
	/*+292*/	DWORD	WindowPosX;
	/*+296*/	DWORD	WindowPosY;
	/*+300*/	DWORD	ScrollX;
	/*+304*/	DWORD	ScrollY;
	/*+308*/	DWORD	WindowWidth;
	/*+312*/	DWORD	WindowHeight;
	/*+316*/	DWORD	WindowLineCount;
	/*+320*/	DWORD	MessageType;
	/*+324*/	DWORD	Unknown324;
	/*+328*/	DWORD	WindowScrollPos;
	/*+332*/	DWORD	Unknown332;
	/*+336*/	float	AlphaColor;
	/*+340*/	DWORD	Unknown340;
	/*+344*/	BYTE	WindowsActivo;
	/*+345*/	BYTE	Unknown345;
	/*+345*/	BYTE	gap346[2];
	/*+348*/	DWORD	Unknown348;
};

#pragma pack(push, 1)
typedef struct tagITEM
{
	short Type;
	int   Level;
	BYTE  Part;
	BYTE  Class;
	bool  TwoHand;
	WORD  DamageMin;
	WORD  DamageMax;
	BYTE  SuccessfulBlocking;
	WORD  Defense;
	WORD  MagicDefense;
	BYTE  MagicPower;
	BYTE  WeaponSpeed;
	WORD  WalkSpeed;
	BYTE  Durability;
	BYTE  Option1;
	BYTE  ExtOption;
	WORD  RequireStrength;
	WORD  RequireDexterity;
	WORD  RequireEnergy;
	WORD  RequireVitality;
	WORD  RequireCharisma;
	WORD  RequireLevel;
	BYTE  SpecialNum;
	WORD  Special[MAX_ITEM_SPECIAL];
	BYTE  SpecialValue[MAX_ITEM_SPECIAL];
	DWORD Key;	//client olny

	BYTE bySelectedSlotIndex;

	union
	{
		BYTE  x;    //client olny
		BYTE  lineal_pos;	// ���� ��ġ(==y*column+x)
	};
	union
	{
		BYTE  y;    //client olny
		BYTE  ex_src_type;	// ������ �޴����� ������ �ʴ� static�� �������� ��� �� ������ �����Ѵ�.
							// 0: ����, 1: �κ��丮 ���â
	};
	WORD  Jewel_Of_Harmony_Option;//�ɼ� ����
	WORD  Jewel_Of_Harmony_OptionLevel;//�ɼ� ����( ���� �ƴ� )
	bool option_380;
	BYTE bySocketOption[MAX_SOCKETS];	// ���� ���� (�������� ������ �״�� ����-������ �����ۿ�)
	BYTE SocketCount;					// ���� ���� (0~MAX_SOCKETS), 0: ���� ������ �ƴ�
	BYTE SocketSeedID[MAX_SOCKETS];		// �õ� ������ȣ (0~49), SOCKET_EMPTY: �� ����
	BYTE SocketSphereLv[MAX_SOCKETS];	// ���Ǿ� ���� (1~5)
	BYTE SocketSeedSetOption;			// �õ� ��Ʈ �ɼ� (���� ������ �����Ǵ�)

										// ������ �� ������ �ϴ� �ҽ�
	int   Number;	//. UI_RENEW_INVENTORY_BASE: ������� ���� ����
	BYTE  Color;	//. UI_RENEW_INVENTORY_BASE: ������� ���� ����

	BYTE byColorState;		// ������ �ؿ� �򸮴� Į�� ����

	bool	bPeriodItem;	// �Ⱓ�� �������ΰ�?
	bool	bExpiredPeriod;	// �Ⱓ�� ����Ǿ���?
							//DWORD	dwLeftTime;		// �Ⱓ�� �������϶� �����ð� (���� : ��)	- Render��
	long	lExpireTime;	// �Ⱓ ���� �ð�.
							//DWORD	dwPastSystemTime;	// ����System�ð�		- ����

	int   RefCount;
} ITEM;
#pragma pack(pop)

typedef struct
{
	char Name[30];
	bool TwoHand;
	WORD Level;
	BYTE m_byItemSlot;
	WORD m_wSkillIndex;
	BYTE Width;
	BYTE Height;
	BYTE DamageMin;
	BYTE DamageMax;
	BYTE SuccessfulBlocking;
	BYTE Defense;
	BYTE MagicDefense;
	BYTE WeaponSpeed;
	BYTE WalkSpeed;
	BYTE Durability;
	BYTE MagicDur;
	BYTE MagicPower;
	WORD RequireStrength;
	WORD RequireDexterity;
	WORD RequireEnergy;
	WORD  RequireVitality;
	WORD RequireCharisma;
	WORD RequireLevel;
	BYTE Value;
	int  iZen;
	BYTE  AttType;
	BYTE RequireClass[7];
	BYTE Resistance[8];
} ITEM_ATTRIBUTE;

#pragma pack(push, 1)
struct ObjectModel	//648? 848!!
{
	BYTE gap00[4];
	/*+4*/	bool	Live;
	BYTE gap01[4];
	/*+9*/	bool	LightEnable;
	bool		  m_bActionStart;
	bool		  m_bRenderAfterCharacter;
	/*+12*/	bool	Visible;
	bool	      AlphaEnable;
	bool          EnableBoneMatrix;
	/*+15*/	bool	ContrastEnable;
	BYTE gap03[2];
	/*+18*/	WORD	CurrentAction;
	/*+20*/	WORD	PriorAction;
	/*+22*/	BYTE	ExtState;
	/*+23*/	BYTE	Teleport;
	/*+24*/	BYTE	Kind;
	BYTE gap04[13];
	/*+38*/	WORD	Unknown38;
	BYTE gap05[8];
	/*+48*/	DWORD	Type;
	DWORD   SubType;
	int			  m_iAnimation;
	int           HiddenMesh;
	int           LifeTime;
	int           BlendMesh;
	BYTE gap06[24];
	/*+96*/	float	Scale;
	float         BlendMeshLight;
	float         BlendMeshTexCoordU;
	float         BlendMeshTexCoordV;
	float         Time;
	/*+116*/	float	Unknown116;
	float         Velocity;
	BYTE gap08[16];
	/*+140*/	float	AnimationFrame;
	/*+144*/	float	PriorAnimationFrame;
	float	      AlphaTarget;
	float         Alpha;
	vec3_t        Light;
	vec3_t        Direction;
	vec3_t		  m_vPosSword;
	vec3_t		  StartPosition;
	/*+204*/	vec3_t	BoundingBoxMin;
	/*+216*/	vec3_t	BoundingBoxMax;
	BYTE gap10[24];
	/*+252*/    vec3_t  Position;
	/*+264*/	vec3_t	Angle;
	vec3_t	 	  HeadAngle;
	vec3_t	   	  HeadTargetAngle;
	vec3_t  	  EyeLeft;
	vec3_t  	  EyeRight;
	vec3_t		  EyeLeft2;
	vec3_t		  EyeRight2;
	vec3_t		  EyeLeft3;
	vec3_t		  EyeRight3;
	vec34_t	 	  Matrix;
	vec34_t       *BoneTransform;
	/*+424*/	OBB_t OBB;
	ObjectModel* Owner;
	ObjectModel* Prior;
	ObjectModel* Next;
	LPVOID m_BuffMap;
	BYTE gap12[160];
	/*+484*/
};
#pragma pack(pop)
							 
#define BODYPART_HEAD        0
#define BODYPART_HELM        1
#define BODYPART_ARMOR       2
#define BODYPART_PANTS       3
#define BODYPART_GLOVES      4
#define BODYPART_BOOTS       5
#define MAX_BODYPART         6
#define BODYPART_RING        7
#define BODYPART_PENDANT     8
#define BODYPART_ARTIFACT    9

typedef struct
{
	short Type;
	BYTE  Level;
	BYTE  Option1;
	BYTE  ExtOption;
	BYTE  LinkBone;
	BYTE  CurrentAction;
	unsigned short  PriorAction;
	float AnimationFrame;
	float PriorAnimationFrame;
	float PlaySpeed;
	BYTE m_byNumCloth;
	void *m_pCloth[2];	// �����ۿ� õ���̱�
} PART_t;

#pragma pack(push, 1)
typedef struct    //-> InDev (size: 1432)
{
	BYTE gap01[14];
	/*+14*/        bool    InSafeZone;
	/*+15*/        BYTE    Change;
	/*+16*/        BYTE    HideShadow;
	/*+17*/        BYTE    IsLiveObject;
	/*+18*/        BYTE    Unknown18;
	/*+19*/        BYTE    Class;
	/*+20*/        BYTE    Skin;
	/*+21*/        BYTE    CtlCode;    //Bit decomposit (0x10)
	/*+22*/        BYTE    ExtState;
	/*+23*/        BYTE    EtcPart;
	/*+24*/        BYTE    GuildStatus;
	/*+25*/        BYTE    GuildType;
	/*+26*/        BYTE    GuildRelationShip;
	/*+27*/        BYTE    Unknown27;
	/*+28*/        BYTE    Unknown28;
	/*+29*/        BYTE    Unknown29;
	/*+30*/        BYTE    Unknown30;
	/*+31*/        BYTE    GensInfluence;    //0 - None, 1 - D, 2 - V
	/*+32*/        BYTE    PKLevel;
	/*+33*/        BYTE    Unknown33;
	/*+34*/        BYTE    AttackTime;
	/*+35*/        BYTE    Unknown35;
	/*+36*/        BYTE    Unknown36;    //Personal Shop
	/*+37*/        BYTE    Unknown37;
	/*+38*/        WORD    Skill;
	/*+40*/        BYTE    Unknown40;
	/*+41*/        BYTE    Unknown41;
	/*+42*/        BYTE    Unknown42;
	BYTE gap03[2];
	/*+45*/        BYTE    RespawnPosX;
	/*+46*/        BYTE    RespawnPosY;
	BYTE gap04[3];
	/*+50*/        BYTE    ActiveMagic;
	BYTE gap05[5];
	/*+56*/        char    Name[25];    //need check size
	BYTE gap06[39];
	/*+120*/    BYTE    Movement;
	/*+121*/    BYTE    MovementType;
	BYTE gap07[2];
	/*+124*/    WORD    GuildMarkIndex;
	/*+126*/    WORD    aIndex;
	/*+128*/    WORD    TargetCharacter;
	/*+130*/    WORD    Level;
	/*+132*/    WORD    MonsterIndex;
	/*+134*/    WORD    Unknown134;
	/*+136*/    //maybe word
	BYTE gap09[36];
	/*+172*/    DWORD    MapPosX;
	/*+176*/    DWORD    MapPosY;
	int         m_iDeleteTime;
	int			m_iFenrirSkillTarget;
	/*+188*/    float    ProtectGuildMarkWorldTime;
	float		AttackRange;
	float       Freeze;
	float       Duplication;
	float		Rot;
	vec3_t		TargetPosition;
	vec3_t      Light;
	PART_t    	BodyPart[MAX_BODYPART];
	/*+448*/    short    WeaponFirstSlot;
	/*+450*/    BYTE    WeaponFirstLevel;
	/*+451*/    BYTE    WeaponFirstExcellent;
	/*+452*/    BYTE    WeaponFirstAncient;
	BYTE gap17[31];
	/*+484*/    short    WeaponSecondSlot;
	/*+486*/    BYTE    WeaponSecondLevel;
	/*+487*/    BYTE    WeaponSecondExcellent;
	/*+488*/    BYTE    WeaponSecondAncient;
	BYTE gap18[31];
	/*+520*/    short    WingsSlot;
	/*+522*/    BYTE    WingsLevel;
	/*+523*/    BYTE    WingsExcellent;
	/*+524*/    BYTE    WingsAncient;
	BYTE gap19[31];
	/*+556*/    short    PetSlot;
	/*+558*/    BYTE    PetLevel;
	/*+559*/    BYTE    PetExcellent;
	/*+560*/    BYTE    PetAncient;
	BYTE gap20[111];
	/*+672*/    LPVOID    m_pParts;
	/*+676*/    DWORD    m_pPet;
	BYTE gap21[84];
	/*+764*/    DWORD    Unknown764;
	BYTE gap22[8];
	/*+776*/    ObjectModel    Object;
	/*+1424*/    BYTE    Unknown1424;    //maybe gens rank
	BYTE gap23[3];
	/*+1428*/    DWORD    Unknown1428;    //-> end
} ObjectPreview, * lpViewObj;
#pragma pack(pop)

struct UnknownStruct0
{
	/*+0*/	WORD	Unknown0;//?
	/*+2*/	WORD	Unknown2;//?
	/*+4*/	WORD	Unknown4;//?
	/*+6*/	WORD	Unknown6;
	/*+8*/	WORD	Unknown8;
	/*+10*/	WORD	Unknown10;
	/*+12*/	WORD	Unknown12;//?
	/*+14*/	WORD	Unknown14;
	/*+16*/	WORD	Unknown16;
};

typedef struct	//-> InDev (size: 6012)
{
	/*+0*/		char	Name[11];
	/*+11*/		char	Class;
	/*+12*/		BYTE	Unknown12;
	/*+13*/		BYTE	Unknown13;
	/*+14*/		short	Level;
	/*+16*/		DWORD	Experience;
	/*+20*/		DWORD	NextExperience;
	/*+24*/		WORD	Strength;
	/*+26*/		WORD	Dexterity;
	/*+28*/		WORD	Vitality;
	/*+30*/		WORD	Energy;
	/*+32*/		WORD	Leadership;
	/*+34*/		WORD	Life;
	/*+36*/		WORD	Mana;
	/*+38*/		WORD	MaxLife;
	/*+40*/		WORD	MaxMana;
	/*+42*/		WORD	Shield;
	/*+44*/		WORD	MaxShield;
	/*+46*/		WORD	AttackRate;
	/*+48*/		WORD	DefenseRate;
	/*+50*/		short	AddStrength;
	/*+52*/		short	AddDexterity;
	/*+54*/		short	AddVitality;
	/*+56*/		short	AddEnergy;
	BYTE gap01[4];
	/*+62*/		WORD	AddLeadership;	//GS use unsigned value...
	/*+64*/		WORD	Stamina;
	/*+66*/		WORD	MaxStamina;
	/*+68*/		BYTE	ItemSpecialUseFlag;		//Bit decomposit (1, 2, 8)
	BYTE UnknownGap;
	/*+70*/		WORD	ItemSpecialUseTime[3];	//[ ]
	/*+76*/		WORD	AddPoint;	//FruitStat start
	/*+78*/		WORD	MaxAddPoint;
	/*+80*/		WORD	MinusPoint;
	/*+82*/		WORD	MaxMinusPoint;	//FruitStat end
	/*+84*/		WORD	AttackSpeed;
	/*+86*/		WORD	DamageRate;
	/*+88*/		WORD	DamageMin;
	/*+90*/		WORD	DamageMax;
	/*+92*/		WORD	Unknown92;
	/*+94*/		WORD	Unknown94;
	/*+96*/		WORD	MagicSpeed;
	BYTE gap02[10];
	/*+108*/	WORD	Unknown108;
	/*+110*/	WORD	Unknown110;
	BYTE gap03[4];
	/*+116*/	WORD	LevelPoint;
	/*+118*/	BYTE	MagicCount;
	/*+119*/	BYTE	Unknown119;
	/*+120*/	WORD	pMagicList[650];	//maybe 150?
	/*1420*/
	BYTE gap04[3252];	//maybe preview struct some here
	/*+4672*/	ITEM pEquipment[12];
	/*+5956*/	DWORD	MoneyInventory;	//(C4)
	/*+5960*/	DWORD	MoneyWarehouse;	//(C4)
	BYTE gap05[8];
	/*+5972*/	UnknownStruct0 Unknown5972;
	BYTE gap06[2];
	/*+5992*/	WORD	Unknown5992;
	/*+5994*/	WORD	Unknown5994;
	BYTE gap07[2];
	/*+5998*/	WORD	Unknown5998;
	/*+6000*/	WORD	Unknown6000;
	/*+6002*/	WORD	Unknown6002;
	/*+6004*/	WORD	Unknown6004;
	/*+6006*/	WORD	Unknown6006;
	/*+6008*/	BYTE	Unknown6008;
	/*+6009*/	BYTE	Unknown6009;
	/*+6010*/	BYTE	Unknown6010;
	/*+6011*/	BYTE	Unknown6011;
} ObjectCharacter, * lpCharObj;

typedef struct
{
	int  Key;
	char UnionName[8 + 1];
	char GuildName[8 + 1];
	BYTE Mark[64];
} MARK_t;

#pragma pack(push, 1)
struct SkillData
{
	/*+216*/	DWORD	SkillSecondID;
	/*+220*/	BOOL	SkillSecondDelayOn;
	/*+224*/	DWORD	SkillSecondDelayTime;
	/*+228*/	BOOL	SkillSecondCounterOn;
	/*+232*/	int		SkillSecondCounterPre;
	/*+236*/	int		SkillSecondCounterSub;
};
#pragma pack(pop)

#pragma pack(push, 1)
typedef struct
{
	BYTE gap01[4];
	/*+4*/		lpViewObj lpPlayer;
	/*+8*/		BYTE	HelperOn;
	BYTE gap02[3];
	/*+12*/		lpViewObj lpTarget;
	/*+16*/		lpViewObj lpIDontKnow;
	/*+20*/		DWORD	Unknown20;
	BYTE gap04[8];
	/*+32*/		DWORD	Time01;
	BYTE gap05[4];
	/*+40*/		DWORD	Unknown40;
	/*+44*/		DWORD	Unknown44;
	/*+48*/		DWORD	Unknown48;
	/*+52*/		DWORD	Unknown52;
	/*+56*/		DWORD	Unknown56;
	/*+60*/		DWORD	Unknown60;
	//BYTE gap06[12];
	/*+64*/		DWORD	Time02;
	/*+68*/		DWORD	MapPosX;
	/*+72*/		DWORD	MapPosY;
	/*+76*/		DWORD	Time03;
	/*+80*/		DWORD	Unknown80;
	BYTE gap07[76];
	/*+160*/	BYTE	Unknown160;
	BYTE gap08[7];
	/*+168*/	BYTE Unknown168;
	BYTE gap09[3];
	/*+172*/	DWORD	HuntingRange;
	/*+176*/	bool	RecoveryPotionOn;
	/*+177*/	BYTE	RecoveryPotionPercent;
	/*+178*/	bool	RecoveryHealOn;			//-> CLASS_ELF
	/*+179*/	BYTE	RecoveryHealPercent;	//-> CLASS_ELF
	/*+180*/	bool	RecoveryDrainOn;		//-> CLASS_SUMMONER
	/*+181*/	BYTE	RecoveryDrainPercent;	//-> CLASS_SUMMONER
	/*+182*/	bool	DistanceLongOn;
	/*+183*/	bool	DistanceReturnOn;
	/*+184*/	DWORD	DistanceMin;
	/*+188*/	DWORD	SkillBasicID;
	/*+192*/	SkillData SkillSecond1;
	/*+216*/	SkillData SkillSecond2;
	///*+192*/	DWORD	SkillSecond1ID;
	///*+196*/	BOOL	SkillSecond1DelayOn;
	///*+200*/	DWORD	SkillSecond1DelayTime;
	///*+204*/	BOOL	SkillSecond1CounterOn;
	///*+208*/	int		SkillSecond1CounterPre;
	///*+212*/	int		SkillSecond1CounterSub;
	///*+216*/	DWORD	SkillSecond2ID;
	///*+220*/	BOOL	SkillSecond2DelayOn;
	///*+224*/	DWORD	SkillSecond2DelayTime;
	///*+228*/	BOOL	SkillSecond2CounterOn;
	///*+232*/	int		SkillSecond2CounterPre;
	///*+236*/	int		SkillSecond2CounterSub;
	/*+240*/	bool	ComboOn;				//-> CLASS_KNIGHT
	/*+241*/	bool	PartyModeOn;
	/*+242*/	bool	PartyModeHealOn;		//-> CLASS_ELF
	/*+243*/	BYTE	PartyModeHealPercent;	//-> CLASS_ELF
	/*+244*/	BOOL	PartyModeBuffOn;
	/*+248*/	DWORD	PartyModeBuffInterval;
	/*+252*/	BOOL	DarkSpiritOn;			//-> CLASS_DARKLORD
	/*+256*/	DWORD	DarkSpiritMode;			//-> CLASS_DARKLORD
	/*+260*/	BOOL	BuffOn;
	/*+264*/	DWORD	BuffSkill[3];
	/*+276*/	DWORD	BuffExtra[3];
	//--
	/*+288*/	DWORD	ObtainRange;
	/*+292*/	bool	ObtainRepairOn;
	/*+293*/	bool	ObtainPickNear;
	/*+294*/	bool	ObtainPickSelected;
	/*+295*/	bool	ObtainPickJewels;
	/*+296*/	bool	ObtainPickAncient;
	/*+297*/	bool	ObtainPickMoney;
	/*+298*/	bool	ObtainPickExcellent;
	/*+299*/	bool	ObtainPickExtra;
	/*+300*/	BYTE	ObtainPickItemList[28][12];
	/*+636*/	BYTE	Unknown636;
	/*+637*/	BYTE	Unknown637;
	/*+638*/	BYTE	Unknown638;
} MUHelper, *lpMUHelper;
#pragma pack(pop)
