#include "stdafx.h"
#include "RenderItem.h"
#include "Util.h"
#include "CustomItemForce.h"
#include "Item.h"
#include "Console.h"

RenderItem gRenderItem;

RenderItem::RenderItem()
{

}

RenderItem::~RenderItem()
{

}

void RenderItem::Init()
{
	SetCompleteHook(0xE8, 0x00842AC7, &this->RenderItemName);
	SetCompleteHook(0xE8, 0x00842B8D, &this->RenderItemName);
}

void RenderItem::RenderItemName(DWORD itemObj, DWORD itemSelected, DWORD itemStruct, DWORD ItemLevel, DWORD ItemOption, DWORD ItemExtOption, bool Sort)
{
	((void(*)(DWORD, DWORD, DWORD, DWORD, DWORD, DWORD, bool))0x5C6980)(itemObj, itemSelected, itemStruct, ItemLevel, ItemOption, ItemExtOption, Sort);

	if (!IsRepeatKey(VK_MENU)) {
		return;
	}

	ITEM* item = &*(ITEM*)(itemObj + 2);

	if (!Sort && item->Type != GET_ITEM(14, 15)) {
		EnableAlphaTest(1);

		static BYTE ItemBuffer[MAX_ITEM_INFO];
		std::memset(&ItemBuffer[0], 0, sizeof(ItemBuffer));

		ItemBuffer[0] = item->Type & 0xFF;
		ItemBuffer[1] = item->Level;
		ItemBuffer[2] = item->Durability;
		ItemBuffer[3] = item->Option1;
		ItemBuffer[4] = item->ExtOption;
		ItemBuffer[5] = item->option_380;
		ItemBuffer[6] = 0;
		ItemBuffer[7] = 0xFF;
		ItemBuffer[8] = 0xFF;
		ItemBuffer[9] = 0xFF;
		ItemBuffer[10] = 0xFF;
		ItemBuffer[11] = 0xFF;

		auto m_Item = ((ITEM*(__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemBuffer);

		gCustomItemForce.ItemConvert(m_Item, ItemBuffer[1], ItemBuffer[3], ItemBuffer[4]);

		((void(__thiscall*)(LPVOID, int, int, ITEM*, bool, int, bool))0x7E3E30)(((LPVOID(__thiscall*)(LPVOID This)) 0x861AA0)(pWindowThis()), pCursorX, pCursorY-15, item, 0, 0, 0);

		DisableAlphaBlend();

		if (m_Item) {
			((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), m_Item);
			m_Item = nullptr;
		}
	}
}
