#include "stdafx.h"
#include "CustomMonster.h"
#include "Util.h"
#include "LuaStack.hpp"
#include "Item.h"

using namespace luaaa;

CCustomMonster gCustomMonster;

CCustomMonster::CCustomMonster() : m_Lua(false)
{
	this->m_CustomMonster.clear();
}

CCustomMonster::~CCustomMonster()
{
	this->m_CustomMonster.clear();
}

void LoadMonster(int MonsterID, int Type, std::string Dir, std::string ModelName) {
	if (Type == 1) {
		LoadItemModel(MonsterID + 644, (char*)Dir.c_str(), (char*)ModelName.c_str(), -1);
		LoadItemTexture(MonsterID + 644, (char*)Dir.c_str(), (char*)ModelName.c_str(), -1);

		DWORD BMDStruct = ((DWORD(__thiscall*)(void*, DWORD))0x00969C50)(((void* (*)())0x004CDA10)(), MonsterID + 644);

		if (BMDStruct != 0) {
			for (int m = 0; ; ++m)
			{
				if (m >= *(signed __int16 *)(BMDStruct + 38)) {
					break;
				}
				*(float *)(*(DWORD *)(BMDStruct + 48) + 16 * m + 4) = 0.25;
			}
		}
	}
	else {
		((void(*)(int)) 0x61FDE0)(MonsterID);
	}
}

DWORD CreateMonsterStruct(int Key, int MonsterID, int PosX, int PosY, int MonsterType, float Size, std::string name) {
	auto Object = ((ObjectPreview*(*)(int, int, unsigned char, unsigned char, float))0x57EEC0)(Key, MonsterID, PosX, PosY, 0.0f);

	if (Object) {
		std::memcpy(Object->Name, name.c_str(), sizeof(Object->Name));

		if (MonsterType == 1) {
			Object->Object.Kind = 4;
		}
		else {
			Object->Object.LifeTime = 100;
			Object->Object.Kind = 2;
		}

		Object->Object.Scale = Size;

		Object->MonsterIndex = MonsterID;

		return (DWORD)(Object);
	}

	return 0;
}

int getMapNumber() {
	return pMapNumber;
}

void SetMonsterInfo(int MonsterID, int MonsterType) {
	CUSTOM_MONSTER_INFO info;

	info.MonsterID = MonsterID;

	info.Type;

	gCustomMonster.m_CustomMonster.insert(std::make_pair(MonsterID, info));
}

void CCustomMonster::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetMonsterInfo", SetMonsterInfo);

	this->m_Lua.DoFile("Data//Files//Lua//Monster//CustomMonster.lua");

	LuaModule(this->m_Lua.GetState()).fun("LoadMonster", LoadMonster);
	LuaModule(this->m_Lua.GetState()).fun("CreateMonsterStruct", CreateMonsterStruct);
	LuaModule(this->m_Lua.GetState()).fun("LoadModel", LoadItemModel);
	LuaModule(this->m_Lua.GetState()).fun("LoadTexture", LoadItemTexture);
	LuaModule(this->m_Lua.GetState()).fun("getMapNumber", getMapNumber);

	SetCompleteHook(0xE8, 0x004E199D, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00587049, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00590CCC, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x005BBEE6, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x0064229D, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00642D51, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00643229, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x0065EA86, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00911A53, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00911A6D, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00911A87, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00911AA1, &this->CreateMonster);
	SetCompleteHook(0xE8, 0x00911ABB, &this->CreateMonster);

	/*SetCompleteHook(0xE8, 0x0058101A, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x0058105B, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x0058109C, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x005810DD, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x0058111E, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x0058115F, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x005811A0, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x005811E1, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x00581222, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x00581263, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x005812A8, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x005812ED, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x0058132E, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x0058136F, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x005813B4, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x005813F9, &this->Setting_Monster);
	SetCompleteHook(0xE8, 0x00586859, &this->Setting_Monster);*/

	SetCompleteHook(0xE8, 0x0061FE3F, &this->LoadMonsterModel);
	SetCompleteHook(0xE8, 0x0061FEEA, &this->LoadMonsterTexture);

	SetCompleteHook(0xE8, 0x0055A35F, &this->EtcStopAnimationSetting);
}

ObjectPreview * CCustomMonster::CreateMonster(int Type, int PositionX, int PositionY, int Key)
{
	int returnValue = 0;
	DWORD ObjectClass = 0;

	gCustomMonster.m_Lua.Generic_Call("CreateMonster", "iiii>ij", Type, PositionX, PositionY, Key, &returnValue, &ObjectClass);

	if (returnValue == 1) {
		return (ObjectPreview*)ObjectClass;
	}

	return ((ObjectPreview*(*)(int, int, int, int))0x580FC0)(Type, PositionX, PositionY, Key);
}

void CCustomMonster::Setting_Monster(ObjectPreview * c, int Type, int PositionX, int PositionY)
{

}

void CCustomMonster::LoadMonsterModel(int ModelID, char* a2, char* a3, int a4)
{
	int returnValue = 0;
	gCustomMonster.m_Lua.Generic_Call("LooadModelMonster", "i>i", ModelID, &returnValue);

	if (returnValue == 1) {
		return;
	}

	((void(*)(int, char*, char*, int)) 0x614D10)(ModelID, a2, a3, a4);
}

void CCustomMonster::LoadMonsterTexture(int ModelID, char* a2, int a3, int a4)
{
	int returnValue = 0;
	gCustomMonster.m_Lua.Generic_Call("LooadTextureMonster", "i>i", ModelID, &returnValue);

	if (returnValue == 1) {
		return;
	}

	((void(*)(int, char*, int, int)) 0x614710)(ModelID, a2, a3, a4);
}

void CCustomMonster::EtcStopAnimationSetting(ObjectPreview * c, ObjectModel * o)
{
	if (o->Type == 232)
	{
		o->CurrentAction = 1;
	}
	else if (((bool(*)(ObjectPreview*, ObjectModel*))0x8CF110)(c, o) == 1)
	{
		((bool(*)(ObjectPreview*, ObjectModel*))0x5567E0)(c, o);
		return;
	}
	else if (pMapNumber != 1 || o->Type != 40)
	{
		if ((o->Type < 644 || o->Type >= 1044) && !gCustomMonster.CheckCustomMonster(o->Type))
		{
			if (o->Type > 1049)
			{
				switch (o->Type)
				{
				case 1116:
					if ((rand() % 16) >= 4 || o->SubType) {
						SetCurrentAction(o, 0, 1);
						o->SubType = 0;
					}
					else {
						SetCurrentAction(o, 1, 1);
						o->SubType = 1;
					}
					break;
				case 1117:
					if ((rand() % 5) >= 4) {
						SetCurrentAction(o, 1, 1);
					}
					else {
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1126:
				case 1127:
					if ((rand() % 5) >= 4 && o->CurrentAction != 1) {
						SetCurrentAction(o, 1, 1);
					}
					else {
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1131:
					if (rand() % 3 < 2 || o->CurrentAction)
					{
						SetCurrentAction(o, 0, 1);
					}
					else
					{
						SetCurrentAction(o, (rand() % 3) + 1, 1);
					}
					break;
				case 1132:
					if ((rand() % 3) >= 2 && o->CurrentAction != 1) {
						SetCurrentAction(o, 1, 1);
					}
					else {
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1133:
				case 1134:
				case 1135:
				case 1136:
					if ((rand() % 5) >= 2)
					{
						SetCurrentAction(o, (rand() % 3) + 2, 1);
					}
					else
					{
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1137:
				case 1138:
				case 1139:
				case 1140:
					if ((rand() % 5) >= 2)
					{
						SetCurrentAction(o, (rand() % 3) + 2, 1);
					}
					else
					{
						SetCurrentAction(o, 1, 1);
					}
					break;
				case 1144:
					SetCurrentAction(o, 0, 1);
					break;
				case 1145:
					if ((rand() % 3) >= 2 && o->CurrentAction != 1 && o->CurrentAction != 2)
					{
						SetCurrentAction(o, (rand() % 2) + 1, 1);
					}
					else
					{
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1147:
				case 1158:
					if ((rand() % 5) >= 4 && o->CurrentAction != 1) {
						SetCurrentAction(o, 1, 1);
					}
					else {
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1151:
				case 1152:
					if ((rand() % 5) >= 4)
					{
						SetCurrentAction(o, (rand() % 2) + 1, 1);
					}
					else
					{
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1153:
				case 1159:
					if ((rand() % 5) >= 3) {
						SetCurrentAction(o, 1, 1);
					}
					else {
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1154:
				case 1155:
					if ((rand() % 5) >= 4)
					{
						SetCurrentAction(o, (rand() % 2) + 1, 1);
					}
					else
					{
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1156:
					if ((rand() % 5) >= 4)
					{
						SetCurrentAction(o, (rand() % 2) + 1, 1);
					}
					else
					{
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1160:
					if ((rand() % 5) >= 4) {
						SetCurrentAction(o, 1, 1);
					}
					else {
						SetCurrentAction(o, 0, 1);
					}
					break;
				case 1161:
					if ((rand() % 5) >= 4 && o->CurrentAction != 1) {
						SetCurrentAction(o, 1, 1);
					}
					else {
						SetCurrentAction(o, 0, 1);
					}
					break;
				default:
					SetCurrentAction(o, (rand() % 2), 1);
					break;
				}
			}
			else if (o->Type >= 1048)
			{
				if (rand() % 16 >= 12)
				{
					SetCurrentAction(o, (rand() % 2) + 1, 1);
				}
				else
				{
					SetCurrentAction(o, 0, 1);
				}
			}
			else if (o->Type < 168 || o->Type > 174)
			{
				SetCurrentAction(o, (rand() % 2), 1);
			}
		}
		else if (o->CurrentAction == 6)
		{
			if (!c->gap01[4])
			{
				c->gap01[4] = 1;
				((void(*)(ObjectModel*))0x72A3D0)(o);
			}
		}
		else
		{
			if (o->CurrentAction == 1
				|| o->CurrentAction == 5
				|| o->CurrentAction == 3
				|| o->CurrentAction == 4
				|| o->CurrentAction == 8
				|| o->CurrentAction == 9
				|| o->CurrentAction == 11)
			{
				SetCurrentAction(o, 0, 1);
			}

			if (o->CurrentAction == 7 && (o->Type == 762 || o->Type == 763 || o->Type == 794))
			{
				if (o->Type == 794) {
					o->CurrentAction = 0;
				}

				SetCurrentAction(o, 0, 1);
			}
		}
	}
	else
	{
		SetCurrentAction(&c->Object, 0, 1);
	}
}

bool CCustomMonster::CheckCustomMonster(int MonsterID)
{
	auto it = this->m_CustomMonster.find(MonsterID);

	if (it == this->m_CustomMonster.end()) {
		return false;
	}

	return (it->second.Type == 1 ? false : true);
}
