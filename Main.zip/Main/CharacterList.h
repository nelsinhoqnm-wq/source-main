#pragma once

#include "Lua.h"
#include "LuaCharacter.h"
#include "LuaInterface.h"
#include "LuaLoadImage.h"
#include "LuaGlobal.h"
#include "LuaMemory.h"
#include "Protocol.h"

class CCharacterList {
public:
	CCharacterList();
	~CCharacterList();

	void Init();
	void RestartLua();
	static void OpenCharacterSceneData();
	static void CGCharacterListRecv(PMSG_CHARACTER_LIST_RECV * lpMsg);
	static void CGCharacterCreateRecv(PMSG_CHARACTER_CREATE_RECV * lpMsg);
	static void MoveCharacterList();
	static void RenderCharacterList();

private:
	CLuaCharacter m_LuaCharacter;
	LuaInterface m_LuaInterface;
	LuaLoadImage m_LuaLoadImage;
	LuaGlobal m_LuaGlobal;
	LuaMemory m_LuaMemory;
	Lua m_Lua;

	int MaxCharactersAccount;

public:
	float MountAddSize;
	float FlyingAddSize;
	float FlyingAddHeight;
};

extern CCharacterList gCharacterList;