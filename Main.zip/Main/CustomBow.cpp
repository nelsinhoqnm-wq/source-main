#include "stdafx.h"
#include "CustomBow.h"
#include "Item.h"
#include "Util.h"
#include "LuaStack.hpp"

using namespace luaaa;

CCustomBow gCustomBow;

CCustomBow::CCustomBow() : m_Lua(true)
{
	this->m_CustomBowInfo.clear();
}

CCustomBow::~CCustomBow()
{
	this->m_CustomBowInfo.clear();
}

void SetBowCross(int ItemIndex, int Type, int Skill) {
	CUSTOM_BOW_INFO info;

	info.ItemIndex = ItemIndex;

	info.Type = Type;

	info.Skill = Skill;

	gCustomBow.m_CustomBowInfo.insert(std::make_pair(info.ItemIndex, info));
}

void __declspec(naked) InventoryBowPosition()
{
	static DWORD m_BowIndex = 0;
	static DWORD m_HookBow = 0x005CC8ED;
	static DWORD m_ReturnBow = 0x005CC92E;

	_asm
	{
		mov ecx, dword ptr ss : [ebp + 0x8]
		mov dword ptr ss : [ebp + 0x8], ecx
		mov m_BowIndex, ecx
	}

	if (m_BowIndex == 0x0CAB) {
		_asm  {
			JMP[m_HookBow];
		}
	}
	else if (gCustomBow.CheckIsBow(m_BowIndex - ITEM_BASE_MODEL)) {
		_asm {
			JMP[m_HookBow];
		}
	}
	else {
		_asm {
			JMP[m_ReturnBow];
		}
	}
}

__declspec(naked) void InventoryCrossBowPosition()
{
	static DWORD m_IndexCrossBow = 0;
	static DWORD m_HookCrossBow = 0x00565994;
	static DWORD m_ReturnCrossBow = 0x005659E7;

	_asm {
		Mov Ecx, Dword ptr ss : [ebp + 0x1C]
		Mov Dword ptr ss : [ebp + 0x1C], Ecx
		Mov m_IndexCrossBow, Ecx
	}

	if (m_IndexCrossBow >= GET_ITEM_MODEL(4, 8) && m_IndexCrossBow <= GET_ITEM_MODEL(4, 14)
		|| m_IndexCrossBow == GET_ITEM_MODEL(4, 16) || m_IndexCrossBow == GET_ITEM_MODEL(4, 18)
		|| m_IndexCrossBow == GET_ITEM_MODEL(4, 19))  {
		_asm {
			JMP[m_HookCrossBow];
		}
	}
	else if (gCustomBow.CheckIsCrossBow(m_IndexCrossBow - ITEM_BASE_MODEL)) {
		_asm {
			JMP[m_HookCrossBow];
		}
	}
	else {
		_asm {
			JMP[m_ReturnCrossBow];
		}
	}
}

void __declspec(naked) RenderPlayerBowCrossPosition()
{
	static DWORD ItemIndex = 0;
	static DWORD m_HookFunc = 0x0056617F;

	_asm
	{

		mov ecx, dword ptr ss : [ebp + 0x1c]
		mov dword ptr ss : [ebp + 0x1c], ecx
		mov ItemIndex, ecx
	}

	if (ItemIndex == 0x0CA7) {
		_asm {
			JE EXIT;
		}
	}
	else if (gCustomBow.CheckIsBow(ItemIndex - ITEM_BASE_MODEL))
	{
		_asm {
			JE EXIT;
		}
	}

	_asm {
	EXIT:
		JMP[m_HookFunc];
	}
}

void __declspec(naked) cBowAddPlayerDimension()
{
	static DWORD BowAddPlayerDimension_Offset = 0x0056623F;
	static DWORD BowAddPlayerNextDimension_Offset = 0x00566185;
	static DWORD RenderBOW = 0;

	_asm
	{
		MOV ECX, DWORD PTR SS : [EBP + 0x1C]
		MOV RenderBOW, ECX
	}

	if (gCustomBow.CheckIsBow(RenderBOW - 1171) == true || RenderBOW >= 3219 && RenderBOW <= 3225 || RenderBOW >= 3239 && RenderBOW <= 3243 || RenderBOW == 3246 || RenderBOW == 3236)
	{
		_asm
		{
			JMP[BowAddPlayerDimension_Offset]
		}
	}
	else
	{
		_asm
		{
			JMP[BowAddPlayerNextDimension_Offset]
		}
	}
}

void __declspec(naked) cCrossBowAddPlayerDimension()
{
	static DWORD Address1 = 0x00565994;
	static DWORD Address2 = 0x005659E7;
	static DWORD IsCrossItem;

	_asm
	{
		Mov Ecx, Dword ptr ss : [ebp + 0x1C]
		Mov Dword ptr ss : [ebp + 0x1C], Ecx
		Mov IsCrossItem, Ecx
	}

	if (IsCrossItem >= GET_ITEM_MODEL(4, 8) && IsCrossItem <= GET_ITEM_MODEL(4, 14)
		|| IsCrossItem == GET_ITEM_MODEL(4, 16)
		|| IsCrossItem == GET_ITEM_MODEL(4, 18)
		|| IsCrossItem == GET_ITEM_MODEL(4, 19)
		|| gCustomBow.CheckIsCrossBow(IsCrossItem - 1171)) // Devil Crossbow
	{
		_asm {jmp Address1}
	}
	else
	{
		_asm {jmp Address2}
	}
}

void CCustomBow::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetBowCross", &SetBowCross);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomBowCross.lua");

	this->m_Lua.Generic_Call("StartLoadBowCross", "");

	MemorySet(0x00566178, 0x90, 7);
	SetCompleteHook(0xE9, 0x00566178, &cBowAddPlayerDimension);

	MemorySet(0x0056595E, 0x90, 7);
	SetCompleteHook(0xE9, 0x0056595E, &cCrossBowAddPlayerDimension);

	//SetCompleteHook(0xE9, 0x005CC8E4, &InventoryBowPosition);

	//SetCompleteHook(0xE9, 0x0056595E, &InventoryCrossBowPosition);

	//SetCompleteHook(0xE9, 0x00566178, &RenderPlayerBowCrossPosition);

	SetCompleteHook(0xE8, 0x005914AB, &this->GetEquipedBowType);
	SetCompleteHook(0xE8, 0x005914C7, &this->GetEquipedBowType);
	SetCompleteHook(0xE8, 0x005A0652, &this->GetEquipedBowType);
	SetCompleteHook(0xE8, 0x005A0775, &this->GetEquipedBowType);
	SetCompleteHook(0xE8, 0x005B6CF4, &this->GetEquipedBowType);
	SetCompleteHook(0xE8, 0x007E05A8, &this->GetEquipedBowType);

	SetCompleteHook(0xE8, 0x0074A6C3, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A791, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A7CC, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A807, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A842, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A87D, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A8D7, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A912, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A94D, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074A988, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074AA05, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074AA40, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074AA7B, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074AAB6, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074AAF8, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074AB33, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074AB6E, &this->CreateArrow);
	SetCompleteHook(0xE8, 0x0074ABAD, &this->CreateArrow);
}

bool CCustomBow::CheckIsBow(int ItemIndex)
{
	std::map<int, CUSTOM_BOW_INFO>::iterator it = this->m_CustomBowInfo.find(ItemIndex);

	if (it == this->m_CustomBowInfo.end()) {
		return 0;
	}

	return (it->second.Type == 1 ? 1 : 0);
}

bool CCustomBow::CheckIsCrossBow(int ItemIndex)
{
	std::map<int, CUSTOM_BOW_INFO>::iterator it = this->m_CustomBowInfo.find(ItemIndex);

	if (it == this->m_CustomBowInfo.end()) {
		return 0;
	}

	return (it->second.Type == 2 ? 1 : 0);
}

int CCustomBow::GetSkillNumber(int ItemIndex)
{
	std::map<int, CUSTOM_BOW_INFO>::iterator it = this->m_CustomBowInfo.find(ItemIndex);

	if (it == this->m_CustomBowInfo.end()) {
		return 0;
	}

	return it->second.Skill;
}

int CCustomBow::GetEquipedBowType(ITEM* pItem)
{
	if ((pItem->Type >= GET_ITEM(4, 0) && pItem->Type <= GET_ITEM(4, 6))
		|| pItem->Type == GET_ITEM(4, 17)
		|| (pItem->Type >= GET_ITEM(4, 20) && pItem->Type <= GET_ITEM(4, 23))
		|| pItem->Type == GET_ITEM(4, 24)
		|| pItem->Type == GET_ITEM(4, 27)
		|| gCustomBow.CheckIsBow(pItem->Type) == 1)
	{
		return 1;
	}

	if ((pItem->Type >= GET_ITEM(4, 8) && pItem->Type <= GET_ITEM(4, 14))
		|| pItem->Type == GET_ITEM(4, 16)
		|| (pItem->Type >= GET_ITEM(4, 18) && pItem->Type <= GET_ITEM(4, 19))
		|| gCustomBow.CheckIsCrossBow(pItem->Type) == 1)
	{
		return 2;
	}

	return 0;
}

void CCustomBow::CreateArrow(ObjectPreview * c, ObjectModel * o, ObjectModel * to, WORD SkillIndex, WORD Skill, WORD SKKey)
{
	short Bow = c->WeaponSecondSlot;
	short CrossBow = c->WeaponFirstSlot;
	int SubType = 0;

	if (c == Hero)
	{
		CrossBow = *(short *)(oUserObjectStruct + 4672);
		Bow = *(short *)(oUserObjectStruct + 4779);

		if (CrossBow != -1) {
			CrossBow += ITEM_BASE_MODEL;
		}
		if (Bow != -1) {
			Bow += ITEM_BASE_MODEL;
		}
	}

	if (SKKey == 52 || SKKey == 416)
	{
		SubType = 2;
		((void(*)(DWORD, ObjectModel*, DWORD))0x6D6C20)(85, o, 0);
	}

	*(int*)0x8793730 = SKKey;

	if (SKKey == 51 || SKKey == 424) {
		((void(*)(DWORD, ObjectModel*, DWORD))0x6D6C20)(130, o, 0);
	}

	if (Skill == 2) {
		SubType = 99;
	}

	if (SKKey == 46)
	{
		((void(*)(int, vec3_t, vec3_t,
			vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
			float, int))0x6D9070)(365, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
	}
	else
	{
		switch (CrossBow)
		{
		case 3227:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(267, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3228:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(267, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3229:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(271, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3230:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(269, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3231:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(268, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3232:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(274, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3233:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(273, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3235:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(294, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3237:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(321, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3238:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(324, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		default:
			if (gCustomBow.CheckIsCrossBow(CrossBow-ITEM_BASE_MODEL)) {
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(gCustomBow.GetSkillNumber(CrossBow - ITEM_BASE_MODEL), o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
				return;
			}
			break;
		}
		switch (Bow)
		{
		case 3219:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(266, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3220:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(266, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3221:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(270, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3222:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(266, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3223:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(266, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3224:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(266, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3225:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(272, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3236:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(295, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3239:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(335, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3240:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(296, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3241:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(297, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3242:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(298, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3243:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(509, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		case 3246:
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(266, o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
			break;
		default:
			if (gCustomBow.CheckIsBow(Bow-ITEM_BASE_MODEL)) {
				((void(*)(int, vec3_t, vec3_t,
					vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
					float, int))0x6D9070)(gCustomBow.GetSkillNumber(Bow - ITEM_BASE_MODEL), o->Position, o->Angle, o->Light, SubType, o, *(WORD *)&o->gap05[4], SkillIndex, Skill, 0, 0.0, -1);
				return;
			}
			return;
		}
	}
}
