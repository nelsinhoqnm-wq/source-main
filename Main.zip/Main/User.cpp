#include "stdafx.h"
#include "Offset.h"
#include "User.h"
#include "Interface.h"
#include "Util.h"
#include "User.h"

User	gObjUser;



DWORD LastTime = 0;


void User::Load()
{
	this->m_TargetUpdateTick	= 0;
	this->m_TargetType			= false;
	this->m_CursorX				= -1;
	this->m_CursorY				= -1;
	this->m_MapNumber			= -1;
}

void User::Refresh()
{
	this->lpPlayer			= &*(ObjectCharacter*)oUserObjectStruct;
	this->lpViewPlayer		= &*(ObjectPreview*)oUserPreviewStruct;

	this->m_CursorX			= pCursorX;

	this->m_CursorY			= pCursorY;

	this->m_MapNumber		= pMapNumber;

	this->CoordenadaX = this->lpViewPlayer->MapPosX;

	this->CoordenadaY = this->lpViewPlayer->MapPosY;

	this->getLevel = gObjUser.lpPlayer->Level;

	sprintf(this->getName,"%s",gObjUser.lpPlayer->Name);



}