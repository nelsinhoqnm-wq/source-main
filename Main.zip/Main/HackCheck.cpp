#include "stdafx.h"
#include "HackCheck.h"
#include "Offset.h"
#include "Util.h"
#include "LoadFiles.h"
#include "AntiHack.h"

typedef int(WINAPI*WSRECV)(SOCKET,char*,int,int);
typedef int(WINAPI*WSSEND)(SOCKET,char*,int,int);

WSRECV HookRecv;
WSSEND HookSend;
BYTE EncDecKey1;
BYTE EncDecKey2;
DWORD FrameValue = 0;
DWORD SpeedValue = 0;
DWORD MainTickCount = 0;
DWORD SyncTickCount = 0;
DWORD CountModifier = 0;
DWORD DelayModifier = 0;
DWORD HasteModifier = 0;
DWORD SleepModifier = 0;
DWORD SpeedModifier1 = 0;
DWORD SpeedModifier2 = 0;
DWORD ModelModifier1 = 0;
DWORD ModelModifier2 = 0;
DWORD ModelModifier3 = 0;

void DecryptData(BYTE* lpMsg,int size) // OK
{
	for(int n=0;n < size;n++)
	{
		lpMsg[n] = (lpMsg[n]^EncDecKey1)-EncDecKey2;
	}
}

void EncryptData(BYTE* lpMsg,int size) // OK
{
	for(int n=0;n < size;n++)
	{
		lpMsg[n] = (lpMsg[n]+EncDecKey2)^EncDecKey1;
	}
}

bool CheckSocketPort(SOCKET s) // OK
{
	SOCKADDR_IN addr;
	int addr_len = sizeof(addr);

	if(getpeername(s,(SOCKADDR*)&addr,&addr_len) == SOCKET_ERROR)
	{
		return 0;
	}

	if(PORT_RANGE(ntohs(addr.sin_port)) == 0)
	{
		return 0;
	}

	return 1;
}

int WINAPI MyRecv(SOCKET s,char* buf,int len,int flags) // OK
{
	int result = HookRecv(s,(char*)buf,len,flags);

	if(result == SOCKET_ERROR || result == 0)
	{
		return result;
	}

	if(CheckSocketPort(s) != 0)
	{
		DecryptData((BYTE*)buf,result);
	}

	gAntiHack.m_TickCountRecv = GetTickCount();

	return result;
}

int WINAPI MySend(SOCKET s,char* buf,int len,int flags) // OK
{
	if(CheckSocketPort(s) != 0)
	{
		EncryptData((BYTE*)buf,len);
	}

	gAntiHack.m_TickCountSend = GetTickCount();

	return HookSend(s,buf,len,flags);
}

_declspec(naked) void CheckTickCount1() // OK
{
	static DWORD CheckTickCountAddress1 = 0x004DA29B;

	_asm
	{
		Mov Dword Ptr Ss:[Ebp-0x68],0x00
		Mov Edx,MainTickCount
		Mov Dword Ptr Ss:[Ebp-0x74],Edx
		Call Dword Ptr Ds:[GetTickCount]
		Mov MainTickCount,Eax
		Mov SyncTickCount,Eax
		Jmp [CheckTickCountAddress1]
	}
}

_declspec(naked) void CheckTickCount2() // OK
{
	static DWORD CheckTickCountAddress1 = 0x004DA3F0;
	static DWORD FPS = gLoadFiles.m_LoadFiles.m_LimitFps;
	_asm
	{
		MOV EAX, DWORD PTR DS : [0xE8CB30]
		SUB EAX, DWORD PTR SS : [EBP - 0x74]
		MOV DWORD PTR SS : [EBP - 0x68], EAX
		MOV ECX, FPS
		CMP DWORD PTR SS : [EBP - 0x68], ECX
		JGE CONTINUE
		MOV ECX, FPS
		SUB ECX, DWORD PTR SS : [EBP - 0x68]
		MOV DWORD PTR SS : [EBP - 0x18C], ECX
		MOV EDX, DWORD PTR SS : [EBP - 0x18C]
		PUSH EDX;
		CALL[Sleep];
		MOV EAX, DWORD PTR DS : [0xE8CB30]
		ADD EAX, DWORD PTR SS : [EBP - 0x18C]
		MOV DWORD PTR DS : [0xE8CB30], EAX
		MOV DWORD PTR SS : [EBP - 0x68], 0x28
		MOV ECX, DWORD PTR SS : [EBP - 0x178]
		ADD ECX, DWORD PTR SS : [EBP - 0x68]
		MOV DWORD PTR SS : [EBP - 0x6C], ECX
		MOVZX EDX, BYTE PTR DS : [0xE8CB1F]
		JMP[CheckTickCountAddress1];


	CONTINUE:
		MOV ECX, DWORD PTR SS : [EBP - 0x178]
		ADD ECX, DWORD PTR SS : [EBP - 0x68]
		MOV DWORD PTR SS : [EBP - 0x6C], ECX
		MOVZX EDX, BYTE PTR DS : [0xE8CB1F]
		JMP[CheckTickCountAddress1];
	}
}

void InitHackCheck() // OK
{
	WORD EncDecKey = 0;

	char CustomerName[100] = {0};

	memcpy(CustomerName, "wJefCd3oTS2ZmhtTMPLaVgv/fqUmjANBgkqh", sizeof("wJefCd3oTS2ZmhtTMPLaVgv/fqUmjANBgkqh"));

	for(int n=0;n < sizeof(CustomerName);n++)
	{
		EncDecKey += (BYTE)(CustomerName[n]^ gLoadFiles.m_LoadFiles.m_Serial[(n%sizeof(gLoadFiles.m_LoadFiles.m_Serial))]);
	}

	EncDecKey1 = (BYTE)0xB5;
	EncDecKey2 = (BYTE)0x22;

	EncDecKey1 += LOBYTE(EncDecKey);
	EncDecKey2 += HIBYTE(EncDecKey);

	HookRecv = *(WSRECV*)(0x00D227B0);

	HookSend = *(WSSEND*)(0x00D227F8);

	SetDword(0x00D227B0,(DWORD)&MyRecv);

	SetDword(0x00D227F8,(DWORD)&MySend);

}
