#pragma once

#define Color4f(r, b, g, o)			((o << 24) + (g << 16) + (b << 8) + r)

enum ObjWindow // -> Season 6.3
{
	FriendList = 1,
	MoveList = 2,
	Party = 3,
	Quest = 4,//
	QuestDevin = 5,//
	Guild = 6,
	Trade = 7,
	Warehouse = 8,
	ChaosBox = 9,
	CommandWindow = 10,
	PetInfo = 11,
	Shop = 12,
	Inventory = 13,
	Store = 14,
	OtherStore = 15,
	Character = 16,
	DevilSquery = 19,//
	BloodCastle = 20,//
	GuildMaster = 21,
	GuardNPC = 24,//
	VorotaCS = 25,//
	ChatWindow = 33,
	FastMenu = 34,
	Options = 35,
	Help = 36,
	FastDial = 39,
	SkillTree = 57,
	Rena = 59,//
	LuckyCoins = 60,//?
	LuckCoinsNPC = 61,
	Titus = 62,//
	NPC_Titus = 63,
	CashShop = 65,
	ElfQuest = 68,
	FullMap = 72,
	NPC_Dialog = 73,
	GensInfo = 74,
	NPC_Julia = 75,
	ExpandInventory = 77,
	ExpandWarehouse = 78,
	Helper = 79,
};

enum CLASS_TYPE
{
	CLASS_WIZARD = 0,
	CLASS_KNIGHT,
	CLASS_ELF,
	CLASS_DARK,
	CLASS_DARK_LORD,
	CLASS_SUMMONER,
	CLASS_RAGEFIGHTER
};

namespace MovePosition
{
	enum T
	{
		Inventory = 0,
		Trade = 1,
		Warehouse = 2,
		ChaosMachine = 3,
		TradeX = 38,
		ElementSlot = 39,
		ChaosBoxGenesis = 40,
	};
};

enum eClassCode // -> Complete -> Season 5.2 JPN
{
	DarkWizard = 0,
	SoulMaster = 8,
	GrandMaster = 24,
	// ----
	DarkKnight = 1,
	BladeKnight = 9,
	BladeMaster = 25,
	// ----
	Elf = 2,
	MuseElf = 10,
	HightElf = 26,
	// ----
	MagicGladiator = 3,
	DuelMaster = 19,
	// ----
	DarkLord = 4,
	LordEmperor = 28,
	// ----
	Summoner = 5,
	BloodySummoner = 13,
	DimensionMaster = 29,
	// ----
	Monk = 6,
	FirstMaster = 16
};

enum ColorMacro
{
	eTextShop = Color4f(0xFFu, 0xDCu, 0x96u, 0xFFu),
	eExcellentS15 = Color4f(67, 204, 65, 255),
	eBlack = Color4f(0, 0, 0, 255),
	eShinyGreen = Color4f(172, 255, 56, 255),
	eShinyGreen100 = Color4f(172, 255, 56, 100),
	eGold = Color4f(255, 189, 25, 255),
	eGold150 = Color4f(255, 189, 25, 150),
	eGold180 = Color4f(255, 189, 25, 180),
	eWhite = Color4f(255, 255, 255, 255),
	eWhite150 = Color4f(255, 255, 255, 150),
	eWhite180 = Color4f(255, 255, 255, 180),
	eOrange = Color4f(255, 105, 25, 255),
	eGray100 = Color4f(211, 211, 211, 100),
	eGray150 = Color4f(50, 50, 50, 150),
	eGray190 = Color4f(50, 50, 50, 190),
	eBlowPink = Color4f(220, 20, 60, 255),
	eRed = Color4f(225, 0, 0, 255),
	eRed2 = Color4f(225, 95, 45, 255),
	eExcellent = Color4f(0, 225, 139, 255),
	eAncient = Color4f(1, 223, 119, 255),
	eSocket = Color4f(153, 102, 204, 255),
	eBlue = Color4f(36, 242, 252, 255),
	eBlue250 = Color4f(36, 242, 252, 250),
	eYellow = Color4f(255, 255, 0, 255),
	eYellow170 = Color4f(255, 255, 0, 170),
	eBrown = Color4f(69, 39, 18, 255),
	eColorAdvance = Color4f(109, 25, 192, 255),
	TEXTURE_START_INDEX = 100000,
	TEXTURE_EMOJI_LIST1,
	TEXTURE_EMOJI_LIST2,
	TEXTURE_EMOJI_LIST3,
	TEXTURE_EMOJI_LIST_BTN,
	TEXTURE_EMOJI_LIST_ON,
	TEXTURE_EMOJI_LIST_ARROW,
};

typedef char arraytooltip[100];

extern void ItemByteConvert(BYTE* lpMsg, int ItemIndex, int Level, int Op1, int Op2, int Op3, int Exc, int Ancient, int JoH, int Socket, BYTE Sock1, BYTE Sock2, BYTE Sock3, BYTE Sock4, BYTE Sock5);