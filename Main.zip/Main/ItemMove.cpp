#include "stdafx.h"
#include "ItemMove.h"
#include "Item.h"
#include "CustomWing.h"
#include "HelperSystem.h"
#include "Protocol.h"
#include "TradeX.h"
#include "CustomJewelStack.h"
#include "ChaosBoxGenesis.h"
#include "ElementSlots.h"
#include "VisualInventory.h"
#include "CustomWing.h"
#include "Console.h"

CItemMove gItemMove;

CItemMove::CItemMove()
{
	this->m_ItemMove = false;
	this->m_BackupSlot = -1;
	this->m_DeleteInventoryCtrl = false;
	this->m_InventoryCtrlMix = false;
}

CItemMove::~CItemMove()
{

}

void CItemMove::AutoMoveItem()
{
	if (GetPickedItem() != 0) {
		return;
	}

	if (gTradeX.isVisible()) {
		if (!this->checkAutoItemMove()) {
			if (IsPressKey(VK_RBUTTON)) {
				gTradeX.MoveItemToInventory();
			}
		}
	}
	else if (gChaosBoxGenesis.isVisible()) {
		if (!this->checkAutoItemMove()) {
			if (IsPressKey(VK_RBUTTON)) {
				gChaosBoxGenesis.MoveItemToInventory();
			}
		}
	}

	if (gCustomJewelStack.IsVisible()) {
		return;
	}

	if (CheckWindowOpen(ObjWindow::Trade) == 1) {
		if (CheckWindowOpen(ObjWindow::Warehouse) == 0
			&& CheckWindowOpen(ObjWindow::ChaosBox) == 0
			&& CheckWindowOpen(ObjWindow::Shop) == 0
			&& CheckWindowOpen(ObjWindow::Store) == 0
			&& CheckWindowOpen(ObjWindow::OtherStore) == 0
			&& CheckWindowOpen(ObjWindow::ExpandWarehouse) == 0) {
			if (IsPressKey(VK_RBUTTON)) {
				if (this->checkAutoItemMove()) {
					return;
				}

				if (gTradeX.isVisible()) {
					gTradeX.MoveItemFromInventory();
					return;
				}

				bool IsExtInv = ((bool(__thiscall*)(LPVOID This)) 0x007D5200)(((LPVOID(__thiscall*)(LPVOID))0x861A60)(pWindowThis()));

				this->m_InventoryCtrlMix = 0;

				this->m_BackupMouseX = pCursorX;
				this->m_BackupMouseY = pCursorY;

				if (IsExtInv) {

				}
				else if (CheckMouseIn(*((DWORD *)pInventoryThis(pWindowThis()) + 9), *((DWORD *)pInventoryThis(pWindowThis()) + 10), 190, 429)) {
					int PointedSlot = *((DWORD *)pInventoryThis(pWindowThis()) + 71);

					//unequip item
					if (PointedSlot != -1) {
						if (this->CheckItemEquiped(PointedSlot)) {
							auto item = this->getItem(PointedSlot);

							if (item->Type != -1) {
								auto itemAttribute = pGetItemAttr(item->Type);

								int value = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttribute->Width, itemAttribute->Height);

								if (value != -1) {
									this->m_BackupSlot = PointedSlot;
									this->m_BackupTargetSlot = value + 12;
									SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::Inventory);
									ResetMouseR();
									this->m_ItemMove = 1;
									this->m_DeleteInventoryCtrl = 0;
								}
							}
						}
					}
					else {
						DWORD InventoryCtrl = -1;
						ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

						if (pItemObj != nullptr) {
							auto itemAttribute = pGetItemAttr(pItemObj->Type);

							int slotEmpty = pInventoryCtrlFindEmptySlot(pTradeGetMyInventoryCtrl(pTradeInventoryThis(pWindowThis())), itemAttribute->Width, itemAttribute->Height);

							if (slotEmpty != -1) {
								this->m_BackupTargetSlot = slotEmpty;
								this->m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
								//SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::ChaosMachine);
								((void(__thiscall*)(LPVOID This, ITEM*, DWORD, DWORD)) 0x00865560)(((LPVOID(__thiscall*)(LPVOID This)) 0x861540)(pWindowThis()), pItemObj, this->m_BackupSlot, this->m_BackupTargetSlot);
								ResetMouseR();
								this->m_ItemMove = 1;
								this->m_DeleteInventoryCtrl = 1;
							}
						}
					}
				}
				else {

				}
			}
		}
	}
	else if (CheckWindowOpen(ObjWindow::ChaosBox) == 1) {
		if (CheckWindowOpen(ObjWindow::Warehouse) == 0
			&& CheckWindowOpen(ObjWindow::Trade) == 0
			&& CheckWindowOpen(ObjWindow::Shop) == 0
			&& CheckWindowOpen(ObjWindow::Store) == 0
			&& CheckWindowOpen(ObjWindow::OtherStore) == 0
			&& CheckWindowOpen(ObjWindow::ExpandWarehouse) == 0) {
			if (IsPressKey(VK_RBUTTON)) {
				if (this->checkAutoItemMove()) {
					return;
				}

				if (gChaosBoxGenesis.isVisible()) {
					gChaosBoxGenesis.MoveItemFromInventory();
					return;
				}

				bool IsExtInv = ((bool(__thiscall*)(LPVOID This)) 0x007D5200)(((LPVOID(__thiscall*)(LPVOID))0x861A60)(pWindowThis()));

				this->m_InventoryCtrlMix = 0;

				this->m_BackupMouseX = pCursorX;
				this->m_BackupMouseY = pCursorY;

				if (IsExtInv) {
					DWORD ItemExpanded1 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), pCursorX, pCursorY);
					DWORD ItemExpanded2 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), pCursorX, pCursorY);

					if (ItemExpanded1 != -1) {
						DWORD InventoryCtrl = -1;
						ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

						if (pItemObj) {
							auto itemAttribute = pGetItemAttr(pItemObj->Type);

							int slotEmpty = pInventoryCtrlFindEmptySlot(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), itemAttribute->Width, itemAttribute->Height);

							if (slotEmpty != -1) {
								this->m_BackupSlot = ItemExpanded1 + 76;
								this->m_BackupTargetSlot = slotEmpty;
								SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::ChaosMachine);
								ResetMouseR();
								this->m_ItemMove = 1;
								this->m_DeleteInventoryCtrl = 1;
							}
						}
					}
					else if (ItemExpanded2 != -1) {
						DWORD InventoryCtrl = -1;
						ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

						if (pItemObj) {
							auto itemAttribute = pGetItemAttr(pItemObj->Type);

							int slotEmpty = pInventoryCtrlFindEmptySlot(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), itemAttribute->Width, itemAttribute->Height);

							if (slotEmpty != -1) {
								this->m_BackupSlot = ItemExpanded2 + 108;
								this->m_BackupTargetSlot = slotEmpty;
								SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::ChaosMachine);
								ResetMouseR();
								this->m_ItemMove = 1;
								this->m_DeleteInventoryCtrl = 1;
							}
						}
					}
				}
				else if (CheckMouseIn(*((DWORD *)pInventoryThis(pWindowThis()) + 9), *((DWORD *)pInventoryThis(pWindowThis()) + 10), 190, 429)) {
					int PointedSlot = *((DWORD *)pInventoryThis(pWindowThis()) + 71);

					//unequip item
					if (PointedSlot != -1) {
						if (this->CheckItemEquiped(PointedSlot)) {
							auto item = this->getItem(PointedSlot);

							if (item->Type != -1) {
								auto itemAttribute = pGetItemAttr(item->Type);

								int value = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttribute->Width, itemAttribute->Height);

								if (value != -1) {
									this->m_BackupSlot = PointedSlot;
									this->m_BackupTargetSlot = value + 12;
									SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::Inventory);
									ResetMouseR();
									this->m_ItemMove = 1;
									this->m_DeleteInventoryCtrl = 0;
								}
							}
						}
					}
					else {
						DWORD InventoryCtrl = -1;
						ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

						if (pItemObj != nullptr) {
							auto itemAttribute = pGetItemAttr(pItemObj->Type);

							int slotEmpty = pInventoryCtrlFindEmptySlot(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), itemAttribute->Width, itemAttribute->Height);

							if (slotEmpty != -1) {
								this->m_BackupTargetSlot = slotEmpty;
								this->m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
								SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::ChaosMachine);
								ResetMouseR();
								this->m_ItemMove = 1;
								this->m_DeleteInventoryCtrl = 1;
							}
						}
					}
				}
				else if (CheckMouseIn(*(DWORD *)((DWORD)pMixInventoryThis(pWindowThis()) + 20), *(DWORD *)((DWORD)pMixInventoryThis(pWindowThis()) + 24), 190, 429)) {
					auto pItemObj = pInventoryCtrlFindItem(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis())), pCursorX, pCursorY);

					if (pItemObj) {
						int SourceSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pMixGetMyInventoryCtrl(pMixInventoryThis(pWindowThis()))) + pItemObj->x);
						auto itemAttribute = pGetItemAttr(pItemObj->Type);

						int slotInventory = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttribute->Width, itemAttribute->Height);

						if (slotInventory != -1) {
							this->m_BackupSlot = SourceSlot;
							this->m_BackupTargetSlot = slotInventory + 12;
							SendItemMove(this->m_BackupSlot, MovePosition::ChaosMachine, this->m_BackupTargetSlot, MovePosition::Inventory);
							ResetMouseR();
							this->m_ItemMove = 1;
							this->m_InventoryCtrlMix = 1;
							this->m_DeleteInventoryCtrl = 1;
						}
						else {
							int slotEmptyInv1 = pInventoryCtrlFindEmptySlot(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), itemAttribute->Width, itemAttribute->Height);

							if (slotEmptyInv1 != -1) {
								this->m_BackupSlot = SourceSlot;
								this->m_BackupTargetSlot = slotEmptyInv1 + 76;
								SendItemMove(this->m_BackupSlot, MovePosition::ChaosMachine, this->m_BackupTargetSlot, MovePosition::Inventory);
								ResetMouseR();
								this->m_ItemMove = 1;
								this->m_DeleteInventoryCtrl = 1;
								this->m_InventoryCtrlMix = 1;
							}
							else {
								int slotEmptyInv2 = pInventoryCtrlFindEmptySlot(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), itemAttribute->Width, itemAttribute->Height);

								if (slotEmptyInv2 != -1) {
									this->m_BackupSlot = SourceSlot;
									this->m_BackupTargetSlot = slotEmptyInv2 + 108;
									SendItemMove(this->m_BackupSlot, MovePosition::ChaosMachine, this->m_BackupTargetSlot, MovePosition::Inventory);
									ResetMouseR();
									this->m_ItemMove = 1;
									this->m_DeleteInventoryCtrl = 1;
									this->m_InventoryCtrlMix = 1;
								}
							}
						}
					}
				}
			}
		}
	}
	else if (CheckWindowOpen(ObjWindow::Inventory) == 1) {
		if (CheckWindowOpen(ObjWindow::Warehouse) == 0
			&& CheckWindowOpen(ObjWindow::ChaosBox) == 0
			&& CheckWindowOpen(ObjWindow::Trade) == 0
			&& CheckWindowOpen(ObjWindow::Shop) == 0
			&& CheckWindowOpen(ObjWindow::Store) == 0
			&& CheckWindowOpen(ObjWindow::OtherStore) == 0
			&& CheckWindowOpen(ObjWindow::ExpandWarehouse) == 0) {
			if (IsPressKey(VK_RBUTTON)) {
				if (this->checkAutoItemMove()) {
					return;
				}

				bool IsExtInv = ((bool(__thiscall*)(LPVOID This)) 0x007D5200)(((LPVOID(__thiscall*)(LPVOID))0x861A60)(pWindowThis()));

				this->m_BackupMouseX = pCursorX;
				this->m_BackupMouseY = pCursorY;

				if (IsExtInv) {
					DWORD ItemExpanded1 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), pCursorX, pCursorY);
					DWORD ItemExpanded2 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), pCursorX, pCursorY);

					if (ItemExpanded1 != -1) {
						DWORD InventoryCtrl = -1;
						ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

						if (pItemObj) {
							auto itemAttribute = pGetItemAttr(pItemObj->Type);

							int slotEmpty = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttribute->Width, itemAttribute->Height);

							if (slotEmpty != -1) {
								this->m_BackupSlot = ItemExpanded1 + 76;
								this->m_BackupTargetSlot = slotEmpty + 12;
								SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::Inventory);
								ResetMouseR();
								this->m_ItemMove = 1;
								this->m_DeleteInventoryCtrl = 1;
							}
						}
					}
					else if (ItemExpanded2 != -1) {
						DWORD InventoryCtrl = -1;
						ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

						if (pItemObj) {
							auto itemAttribute = pGetItemAttr(pItemObj->Type);

							int slotEmpty = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttribute->Width, itemAttribute->Height);

							if (slotEmpty != -1) {

								this->m_BackupSlot = ItemExpanded2 + 108;
								this->m_BackupTargetSlot = slotEmpty + 12;
								SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::Inventory);
								ResetMouseR();
								this->m_ItemMove = 1;
								this->m_DeleteInventoryCtrl = 1;
							}
						}
					}
				}
				else if (CheckMouseIn(*((DWORD *)pInventoryThis(pWindowThis()) + 9), *((DWORD *)pInventoryThis(pWindowThis()) + 10), 190, 429)) {
					int PointedSlot = *((DWORD *)pInventoryThis(pWindowThis()) + 71);

					if (CheckWindowOpen(ObjWindow::ExpandInventory) == 1 && PointedSlot == -1) {
						DWORD InventoryCtrl = -1;
						ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);

						if (pItemObj != nullptr) {
							auto itemAttribute = pGetItemAttr(pItemObj->Type);

							int slotEmptyInv1 = pInventoryCtrlFindEmptySlot(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), itemAttribute->Width, itemAttribute->Height);

							if (slotEmptyInv1 != -1) {
								this->m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
								this->m_BackupTargetSlot = slotEmptyInv1 + 76;
								SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::Inventory);
								ResetMouseR();
								this->m_ItemMove = 1;
								this->m_DeleteInventoryCtrl = 1;
							}
							else {
								int slotEmptyInv2 = pInventoryCtrlFindEmptySlot(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), itemAttribute->Width, itemAttribute->Height);

								if (slotEmptyInv2 != -1) {
									this->m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
									this->m_BackupTargetSlot = slotEmptyInv2 + 108;
									SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::Inventory);
									ResetMouseR();
									this->m_ItemMove = 1;
									this->m_DeleteInventoryCtrl = 1;
								}
							}
						}
					}
					else {

						if (PointedSlot != -1) {
							if (this->CheckItemEquiped(PointedSlot)) {

								auto item = this->getItem(PointedSlot);

								if (item == nullptr) {
									return;
								}

								if (PointedSlot == 7) {
									if (pMapNumber == 10) {
										if (gCustomWing.CheckCustomWingByItem(item->Type)) {
											return;
										}
									}
								}

								if (item->Type != -1) {
									auto itemAttribute = pGetItemAttr(item->Type);

									int value = pInventoryFindEmptySlot(pInventoryThis(pWindowThis()), itemAttribute->Width, itemAttribute->Height);

									if (value != -1) {
										this->m_BackupSlot = PointedSlot;
										this->m_BackupTargetSlot = value + 12;
										SendItemMove(this->m_BackupSlot, MovePosition::Inventory, this->m_BackupTargetSlot, MovePosition::Inventory);
										ResetMouseR();
										this->m_ItemMove = 1;
										this->m_DeleteInventoryCtrl = 0;
									}
								}
							}
						}
						else {
							DWORD InventoryCtrl = -1;
							ITEM* pItemObj = pInventoryCtrlFindItemAtPt(pInventoryThis(pWindowThis()), pCursorX, pCursorY, &InventoryCtrl);
							auto hero = Hero;

							if (pItemObj != nullptr) {
								auto itemAttribute = pGetItemAttr(pItemObj->Type);

								if (itemAttribute) {
									if (itemAttribute->m_byItemSlot == (BYTE)-1) {
										return;
									}

									//check equiped class
									if (itemAttribute->RequireClass[GetBaseClass(hero->Class)] == 0) {
										return;
									}

									int32_t TargetSlot = itemAttribute->m_byItemSlot;

									if (TargetSlot == 0) {
										if (GetBaseClass(hero->Class) == CLASS_KNIGHT ||
											GetBaseClass(hero->Class) == CLASS_DARK ||
											GetBaseClass(hero->Class) == CLASS_RAGEFIGHTER) {
											if (this->CheckItemEquiped(0) == 1) {
												if (this->CheckItemEquiped(1) == 0) {
													TargetSlot = 1;
												}
												else {
													TargetSlot = -1;
												}
											}
										}
									}
									if (TargetSlot == 10) {
										if (this->CheckItemEquiped(10)) {
											if (this->CheckItemEquiped(11) == 0) {
												TargetSlot = 11;
											}
											else {
												TargetSlot = -1;
											}
										}
									}

									if (TargetSlot == 2 || TargetSlot == 242) {
										if (GetBaseClass(hero->Class) == CLASS_DARK) {
											TargetSlot = -1;
										}
									}

									if (TargetSlot == 5 || TargetSlot == 245) {
										if (GetBaseClass(hero->Class) == CLASS_RAGEFIGHTER) {
											TargetSlot = -1;
										}
									}

									if (TargetSlot == -1) {
										return;
									}

									if (this->CheckItemEquiped(TargetSlot)) {
										return;
									}

									this->m_BackupTargetSlot = TargetSlot;
									this->m_BackupSlot = (pItemObj->y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + pItemObj->x) + 12;
									SendItemMove(this->m_BackupSlot, MovePosition::Inventory, TargetSlot, MovePosition::Inventory);
									ResetMouseR();
									this->m_ItemMove = 1;
									this->m_DeleteInventoryCtrl = 1;
								}
							}
						}
					}
				}
			}
		}
	}
}

void CItemMove::UnequipItem()
{

}

BYTE CItemMove::GetTargetSlot(int ItemIndex)
{
	return 0;
}

bool CItemMove::CheckItemEquiped(BYTE slot)
{
	if (slot >= 240 && slot <= 248) {
		if (gVisualInventory.CheckVisualOpen() == 0) {
			return true;
		}

		int StackEquiped = slot - 240;

		if (StackEquiped < 0) {
			StackEquiped = 0;
		}

		if (StackEquiped > 8) {
			StackEquiped = 8;
		}

		auto itemCheck = gVisualInventory.getItem(slot);

		if (itemCheck != nullptr) {
			if (itemCheck->Type == -1) {
				return false;
			}
			return true;
		}

		return false;
	}
	else if (slot >= 236 && slot <= 239) {
		int StackEquiped = slot - 236;

		if (StackEquiped < 0) {
			StackEquiped = 0;
		}

		if (StackEquiped > 3) {
			StackEquiped = 3;
		}

		if (gElementSlots.m_ElementEquiped[StackEquiped].Active == 0) {
			return true;
		}

		auto itemCheck = gElementSlots.getItemElement(slot);

		if (itemCheck != nullptr) {
			if (itemCheck->Type == -1) {
				return false;
			}
			return true;
		}

		return false;
	}
	else {
		auto itemCheck = &*(ITEM*)(*(DWORD*)0x8128AC4 + 107 * slot + 4672);

		if (itemCheck != nullptr) {
			if (itemCheck->Type == -1) {
				return false;
			}
			return true;
		}

		return false;
	}
}

ITEM * CItemMove::getItem(BYTE slot)
{
	if (slot >= 240 && slot <= 248) {
		if (!gVisualInventory.CheckVisualOpen()) {
			return nullptr;
		}

		return gVisualInventory.getItem(slot);
	}
	else if (slot >= 236 && slot <= 239) {
		int StackEquiped = slot - 236;

		if (StackEquiped < 0) {
			StackEquiped = 0;
		}

		if (StackEquiped > 3) {
			StackEquiped = 3;
		}

		if (gElementSlots.m_ElementEquiped[StackEquiped].Active == 0) {
			return nullptr;
		}

		return gElementSlots.getItemElement(slot);
	}
	else {
		return &*(ITEM*)(*(DWORD*)0x8128AC4 + 107 * slot + 4672);
	}
}

bool CItemMove::checkAutoItemMove()
{
	return this->m_ItemMove;
}

void CItemMove::SetAutoItemMove(bool value)
{
	this->m_ItemMove = value;
}
