#ifndef Logger_H
#define Logger_H

//#include "StdAfx.h"

#define CONSOLETITLE "[ DEBUG MODE ] "

class CConsole
{
public:
	CConsole();
	~CConsole();
	void InitCore();
	void ConsoleOutput(bool WriteToFile, const char* Format, ...);
	void closeMenu();
};
extern CConsole Console;

#endif