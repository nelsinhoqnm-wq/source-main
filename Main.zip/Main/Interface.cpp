#include "stdafx.h"
#include "Interface.h"
#include "Util.h"
#include "LuaSocket.h"
#include "AntiHack.h"
#include "LuaCharacter.h"
#include "Reconnect.h"
#include "HelperManager.h"
#include "Item.h"
#include "ItemMove.h"
#include "TradeX.h"
#include "HotKey.h"
#include "WindowTray.h"
#include "Camera.h"
#include "LoadFiles.h"
#include "CustomMessage.h"
#include "MuHelperInterface.h"
#include "PersonalShop.h"
#include "Console.h"
#include "CharacterList.h"
#include "CustomJewelStack.h"
#include "AutoLoginWin.h"
#include "Descriptions.h"
#include "CustomCape.h"
#include "RenderModel.h"
#include "CustomWing.h"
#include "CustomItemSize.h"
#include "CustomItemPosition.h"
#include "CustomItem.h"
#include "CustomSetEffect.h"
#include "CustomEffects.h"
#include "DisableExcellent.h"
#include "CustomSkillEffect.h"
#include "DarkSpirit.h"
#include "ChaosBoxGenesis.h"
#include "Patente.h"
#include "HelperSystem.h"
#include "Protocol.h"
#include "RemakeInterface.h"
#include "User.h"
#include "PrintPlayer.h"
#include "CustomMonsterEffect.h"

// defines:
#define pWinWidth				*(GLsizei*)0x0E61E58
#define pWinHeight				*(GLsizei*)0x0E61E5C
#define sub_6363D0_Addr ((void(__cdecl*)(GLint x, int a2, GLsizei width, GLsizei height)) 0x6363D0)
#define sub_6358A0_Addr ((int(__cdecl*)(float a1, float a2, float a3, float a4)) 0x6358A0)

// code:
void fix_resolution_items_size_1()
{
	return sub_6363D0_Addr(0, 0, pWinWidth, pWinHeight);
}

int fix_resolution_items_size_2()
{
	float v2 = (float)pWinWidth / (float)pWinHeight;
	return sub_6358A0_Addr(1.0, v2, 20.0, 2000.0);
}

CInterface gInterface;

CInterface::CInterface() : m_Lua(true) {
	this->interfaceLock = 0;

	this->frameStartTime = GetTickCount();
	this->frames = 0;
	this->frameTimes = 0;
	this->FPS = 0;
}

CInterface::~CInterface() {

}

// HP do pet (normal e custom) - desce a barra para nao ficar embaixo dos botoes Menu/Shop.
// Ajuste PET_HP_OFFSET_Y (pixels, tela 640x480) para subir/descer.
#define PET_HP_OFFSET_Y 14

void PetHPBarEx(signed int x, signed int y, int nameIndex, signed int hp, signed int hpmax, char a9)
{
	float v15;

	y += PET_HP_OFFSET_Y;

	EnableAlphaTest(1);
	pSetBackgroundTextColor(pTextThis(), 0, 0, 0, 0);
	pSetTextColor(pTextThis(), 0xFFu, 0xFFu, 0xFFu, 0xFFu);

	if (a9)
		glColor4f(0.2f, 0.0f, 0.0f, 0.7f);
	else
		glColor4f(0.0f, 0.0f, 0.0f, 0.7f);

	pDrawBarForm((float)(x + 2), (float)(y + 2), 53.0f, 13.0f, 0.0f, 0);
	((void(__cdecl*)())0x00637A30)();
	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	pDrawGUI(31624, (float)x, (float)y, 57.0f, 23.0f);

	v15 = (float)hp / (float)hpmax * 50.0f;
	pDrawGUI(31625, (float)(x + 4), (float)(y + 16), v15, 3.0f);

	pDrawText(pTextThis(), x + 28, y + 5, (LPCTSTR)nameIndex, 0, 0, 8, 0);
	pGLSwitch();
}

void StartCallInterface() {
	EnableAlphaTest(1);

	glColor4f(1.f, 1.f, 1.f, 1.f);

	gInterface.m_Lua.Generic_Call("BeforeMainProc", ">");

	DisableAlphaBlend();
}


__declspec(naked) void InterfaceRender() {
	static DWORD m_ReturnFunc = 0x00815DC1;

	_asm {
		CALL[StartCallInterface];
		MOV AL, 0x1
		MOV ESP, EBP
		POP EBP
		RETN
	}
}


void UpdateFrame(HDC hdc)
{
	gInterface.frameStartTime = timeGetTime();

	if (hdc) {
		((void(*)(HDC))0x4D9CF0)(hdc);
	}

	gInterface.frameTimes = gInterface.frameTimes + timeGetTime() - gInterface.frameStartTime;

	++gInterface.frames;

	if (gInterface.frameTimes >= 1000)
	{
		gInterface.FPS = gInterface.frames;
		gInterface.frames = 0;
		gInterface.frameTimes = 0;
	}
}


void SetTickCountFrame() {
	gInterface.frameStartTime = timeGetTime();
}

__declspec(naked) void SetFirstFrame() {
	static DWORD m_HookFunc = 0x004D9D08;

	_asm {
		CALL[SetTickCountFrame];
		MOV DWORD PTR FS : [0x0], ESP
		JMP[m_HookFunc];
	}
}

void SetCalcFps() {
	gInterface.frameTimes = gInterface.frameTimes + timeGetTime() - gInterface.frameStartTime;

	++gInterface.frames;

	if (gInterface.frameTimes >= 1000)
	{
		gInterface.FPS = gInterface.frames;
		gInterface.frames = 0;
		gInterface.frameTimes = 0;
	}
}

__declspec(naked) void SetFrameFps() {
	static DWORD m_HookFunc = 0x004DAC6E;

	_asm {
		CALL[SetCalcFps];
		MOV ECX, DWORD PTR SS : [EBP - 0xC];
		MOV DWORD PTR FS : [0x0], ECX;
		JMP[m_HookFunc];
	}
}

void CInterface::Init()
{
	gSocket.SetGlobalFunctions(this->m_Lua.GetState());

	m_LuaGlobal.RegisterGlobal(this->m_Lua.GetState());

	m_LuaInterface.RegisterInterface(this->m_Lua.GetState());

	m_LuaCharacter.RegisterLuaCharacter(this->m_Lua.GetState());

	m_LuaUser.RegisterLuaUser(this->m_Lua.GetState());

	m_LoadImage.SetFunctions(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//Controller//Interface.lua");

	SetCompleteHook(0xE8, 0x0080F7FE, &this->MainProc);

	SetCompleteHook(0xE8, 0x00860AE8, &this->UpdateMouse);

	SetCompleteHook(0xE8, 0x00860AF2, &this->UpdateKey);

	SetCompleteHook(0xE8, 0x00860AFC, &this->UpdateProc);

	SetCompleteHook(0xE9, 0x0084283C, &InterfaceRender);

	SetCompleteHook(0xE9, 0x007DFA60, &PetHPBarEx);

	SetCompleteHook(0xE9, 0x004D9D01, &SetFirstFrame);

	SetCompleteHook(0xE9, 0x004DAC64, &SetFrameFps);

	SetCompleteHook(0xE8, 0x004D9CCC, &RenderInformation);

	SetCompleteHook(0xE8, 0x00772960, &fix_resolution_items_size_1);
	SetCompleteHook(0xE8, 0x007729B3, &fix_resolution_items_size_2);




	#if(DOWNGRADE)
	this->BindObject(CharacterSelect, 51522, 85, 150, 219, 178);
	this->BindObject(CharacterSelect_Button1, 51519, 150, 35, -1, -1);
	this->BindObject(CharacterSelect_Button2, 51519, 150, 35, -1, -1);
	this->BindObject(CharacterSelect_Button3, 51519, 150, 35, -1, -1);
	this->BindObject(CharacterSelect_Button4, 51519, 150, 35, -1, -1);
	this->BindObject(CharacterSelect_Button5, 51519, 150, 35, -1, -1);
	this->BindObject(CharacterOption_Button1, 521519, 70, 17, -1, -1);
	this->BindObject(CharacterOption_Button2, 521519, 70, 17, -1, -1);
	this->BindObject(eMain, 31293, 960, 160, 50, 388);
	this->BindObject(eParty, iNewParty1, 23, 30, 340, 449);
	this->BindObject(eCharacter, iNewCharacter1, 23, 30, 370, 449);
	this->BindObject(eInventory, iNewInventory1, 23, 30, 400, 449);
	this->BindObject(eGuild, iNewGuild1, 40, 18, 523, 461);
	this->BindObject(eOrelhinha, 0x700021, 16, 16, -10, 359);
	this->BindObject(eJanelinha, 0x700022, 16, 16, -10, 359);
	this->BindObject(eLuizinha, 0x700023, 16, 16, -10, 359);
	this->BindObject(ebtnWisper, 0x7A34, 15, 15, -10, 359);
	#endif
}

void CInterface::RestartLua()
{
	this->m_Lua.CloseLua();

	this->m_Lua.RegisterLua();

	gSocket.SetGlobalFunctions(m_Lua.GetState());

	m_LuaGlobal.RegisterGlobal(this->m_Lua.GetState());

	m_LuaInterface.RegisterInterface(this->m_Lua.GetState());

	m_LuaCharacter.RegisterLuaCharacter(this->m_Lua.GetState());

	m_LuaUser.RegisterLuaUser(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//Controller//Interface.lua");

}

void CInterface::RenderInformation()
{
	if (gAntiHack.LicenseChecked) {
		gInterface.m_Lua.Generic_Call("MainProc", ">");
	}

	((void(*)())0x4D5EC0)();
}

DWORD TimeEventVKAdv4;
int PotionHPAdv;

void CInterface::MainProc()
{
	((void(*)())0x0080F8E0)();

	ReconnectMainProc();

	gTradeX.RenderButtomHidden();

	gCustomJewelStack.Render(); 
	
#if(DOWNGRADE)
	gInterface.DrawInterface97Menu();
#endif

	if (GetKeyState(VK_F6) & 0x8000 && GetTickCount() >= TimeEventVKAdv4 + 250)
	{

		if (PotionHPAdv != 0)
		{

			PotionHPAdv = 0;
			gInterface.DrawMessage(1, gCustomMessage.GetMessage(49));
			AutoPotionType(0, 0, 0, 0);

		}
		else
		{
			PotionHPAdv = 1;
			gInterface.DrawMessage(1, gCustomMessage.GetMessage(52));
			AutoPotionType(1, 1, 1, 1);

		}
		TimeEventVKAdv4 = GetTickCount();

	}

	if (gLoadFiles.m_LoadFiles.m_Camera3D == 1) {
		if ((GetTickCount() - gCamera.LastPress) > 200) {
			#if USE_CONSOLE == false
			if (GetKeyState(VK_F9) & 0x8000) {

				gInterface.DrawMessage(1, gCustomMessage.GetMessage(48));

				gCamera.LastPress = GetTickCount();

				//gInterface.RestartLua();
				gCharacterList.RestartLua();
				gDescriptions.RestartLua();
				gCustomCape.RestartLua();
				gRenderModel.RestartLua();
				gCustomWing.RestartLua();
				gCustomItemSize.RestartLua();
				gCustomItemPosition.RestartLua();
				gCustomItem.RestartLua();
				gCCustomSetEffect.RestartLua();
				gCustomEffects.RestartLua();
				gDisableExcellent.RestartLua();
				gCustomSkillEffect.RestartLua();
				gDarkSpirit.RestartLua();
				gChaosBoxGenesis.RestartLua();
				gPatente.RestartLua();
				gHelperSystem.RestartLua();
				gCustomMonsterEffect.RestartLua();
			}
			#endif

			if (GetKeyState(VK_F11) & 0x8000) {
				gCamera.Toggle();

				gCamera.LastPress = GetTickCount();
			}
			else if (GetKeyState(VK_F10) & 0x8000) {
				gCamera.Restore();

				gInterface.DrawMessage(1, gCustomMessage.GetMessage(27));

				gCamera.LastPress = GetTickCount();
			}
		}
	}

	if (gLoadFiles.m_LoadFiles.m_Minimizer == 1) {
		if ((GetTickCount() - gTrayMode.LastPress) > 200) {
			if (GetKeyState(VK_F12) & 0x8000) {
				if (gTrayMode.TempWindowProc == NULL)
				{
					gTrayMode.TempWindowProc = SetWindowLongPtr(MAIN_WINDOW, GWL_WNDPROC, (long)gHotKey.Window);
				}

				gTrayMode.SwitchState();
				gTrayMode.LastPress = GetTickCount();
			}
		}
	}
}

bool CInterface::UpdateProc(DWORD* Class)
{
	if (gAntiHack.LicenseChecked) {
		gInterface.m_Lua.Generic_Call("UpdateProc", ">");
	}

	return ((bool(__thiscall*)(DWORD))0x815CE0)(*(DWORD *)Class);
}

bool CInterface::UpdateMouse(DWORD * Class)
{
	gInterface.interfaceLock = 0;

	if (gAntiHack.LicenseChecked) {
		gInterface.m_Lua.Generic_Call("UpdateMouse", ">");
	}

	if (gInterface.interfaceLock) {
		return 1;
	}

	gCustomJewelStack.Update();

	gItemMove.AutoMoveItem();
	gTradeX.UpdateMouseEvent();
	gMuHelperInterface.UpdateMouseEvent();

	return ((bool(__thiscall*)(DWORD))0x8159D0)(*(DWORD *)Class);
}

bool CInterface::UpdateKey(DWORD * Class)
{
	gInterface.interfaceLock = 0;

	if (gAntiHack.LicenseChecked) {
		gInterface.m_Lua.Generic_Call("UpdateKey", ">");
	}

	if (gInterface.interfaceLock) {
		return 1;
	}

	return ((bool(__thiscall*)(DWORD))0x815B50)(*(DWORD *)Class);
}


//void CInterface::WebzenScene(HDC hdc)
//{
//	((void(*)(HDC))0x4D54F0)(hdc);
//
//	gInterface.hdc = hdc;
//
//	gInterface.m_Lua.Generic_Call("FinalBoot", ">");
//}

int CInterface::DrawToolTip(int X, int Y, LPCSTR Text, ...)
{
	char Buff[2048];
	int BuffLen = sizeof(Buff);
	ZeroMemory(Buff, BuffLen);

	va_list args;
	va_start(args, Text);
	int Len = vsprintf_s(Buff, BuffLen, Text, args);
	va_end(args);

	return pDrawToolTip(X, Y, Buff);
}

int CInterface::DrawFormat(DWORD Color, int PosX, int PosY, int Width, int Align, LPCSTR Text, ...)
{
	char Buff[2048];
	int BuffLen = sizeof(Buff) - 1;
	ZeroMemory(Buff, BuffLen);

	va_list args;
	va_start(args, Text);
	int Len = vsprintf_s(Buff, BuffLen, Text, args);
	va_end(args);

	int LineCount = 0;

	char * Line = strtok(Buff, "\n");

	while (Line != NULL)
	{
		pDrawColorText(Line, PosX, PosY, Width, 0, Color, 0, Align);
		PosY += 10;
		Line = strtok(NULL, "\n");
	}

	return PosY;
}


int CInterface::DrawMessage(int Mode, LPCSTR Text, ...)
{
	char Buff[2048];
	int BuffLen = sizeof(Buff);
	ZeroMemory(Buff, BuffLen);
	// ----
	va_list args;
	va_start(args, Text);
	int Len = vsprintf_s(Buff, BuffLen, Text, args);
	va_end(args);
	// ----
	return pDrawMessage(Buff, Mode);
}




void CInterface::BindObject(short MonsterID, DWORD ModelID, float Width, float Height, float X, float Y)
{
	this->Data[MonsterID].EventTick = 0;
	this->Data[MonsterID].OnClick = false;
	this->Data[MonsterID].OnShow = false;
	this->Data[MonsterID].ModelID = ModelID;
	this->Data[MonsterID].Width = Width;
	this->Data[MonsterID].Height = Height;
	this->Data[MonsterID].X = X;
	this->Data[MonsterID].Y = Y;
	this->Data[MonsterID].MaxX = X + Width;
	this->Data[MonsterID].MaxY = Y + Height;
	this->Data[MonsterID].Attribute = 0;
}

bool CInterface::IsWorkZone(short ObjectID)
{
	if ((pCursorX < this->Data[ObjectID].X || pCursorX > this->Data[ObjectID].MaxX) || (pCursorY < this->Data[ObjectID].Y || pCursorY > this->Data[ObjectID].MaxY))
		return false;

	return true;
}

void CInterface::DrawButton(short ObjectID, float PosX, float PosY, float ScaleX, float ScaleY)
{
	this->Data[ObjectID].X = PosX;
	this->Data[ObjectID].Y = PosY;
	this->Data[ObjectID].MaxX = PosX + this->Data[ObjectID].Width;
	this->Data[ObjectID].MaxY = PosY + this->Data[ObjectID].Height;

	((void(__cdecl*)(DWORD, float, float, float, float, float, float))0x00790E40)
		(this->Data[ObjectID].ModelID, PosX, PosY,
			this->Data[ObjectID].Width,
			this->Data[ObjectID].Height,
			ScaleX, ScaleY);
}


void CInterface::SelectCharButton(DWORD Event)
{
	DWORD CurrentTick = GetTickCount();
	// ----
	if (*(DWORD*)(MAIN_SCREEN_STATE) != 4)
	{
		return;
	}
	// ----
	if (gInterface.IsWorkZone(CharacterSelect_Button1))
	{
		DWORD Delay = (CurrentTick - gInterface.Data[CharacterSelect_Button1].EventTick);
		// ----
		if (Event == WM_LBUTTONDOWN)
		{
			gInterface.Data[CharacterSelect_Button1].OnClick = true;
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button1].OnClick = false;
		// ----
		if (Delay < 500)
		{
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button1].EventTick = GetTickCount();
		// ----
	}
	else if (gInterface.IsWorkZone(CharacterSelect_Button2))
	{
		DWORD Delay = (CurrentTick - gInterface.Data[CharacterSelect_Button2].EventTick);
		// ----
		if (Event == WM_LBUTTONDOWN)
		{
			gInterface.Data[CharacterSelect_Button2].OnClick = true;
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button2].OnClick = false;
		// ----
		if (Delay < 500)
		{
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button2].EventTick = GetTickCount();
		// ----
	}
	else if (gInterface.IsWorkZone(CharacterSelect_Button3))
	{
		DWORD Delay = (CurrentTick - gInterface.Data[CharacterSelect_Button3].EventTick);
		// ----
		if (Event == WM_LBUTTONDOWN)
		{
			gInterface.Data[CharacterSelect_Button3].OnClick = true;
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button3].OnClick = false;
		// ----
		if (Delay < 500)
		{
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button3].EventTick = GetTickCount();
		// ----
	}
	else if (gInterface.IsWorkZone(CharacterSelect_Button4))
	{
		DWORD Delay = (CurrentTick - gInterface.Data[CharacterSelect_Button4].EventTick);
		// ----
		if (Event == WM_LBUTTONDOWN)
		{
			gInterface.Data[CharacterSelect_Button4].OnClick = true;
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button4].OnClick = false;
		// ----
		if (Delay < 500)
		{
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button4].EventTick = GetTickCount();
		// ----
	}
	else if (gInterface.IsWorkZone(CharacterSelect_Button5))
	{
		DWORD Delay = (CurrentTick - gInterface.Data[CharacterSelect_Button5].EventTick);
		// ----
		if (Event == WM_LBUTTONDOWN)
		{
			gInterface.Data[CharacterSelect_Button5].OnClick = true;
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button5].OnClick = false;
		// ----
		if (Delay < 500)
		{
			return;
		}
		// ----
		gInterface.Data[CharacterSelect_Button5].EventTick = GetTickCount();
		// ----
	}
}

bool CInterface::CheckWindow(int WindowID)
{
	return pCheckWindow(pWindowThis(), WindowID);
}

int CInterface::CCloseWindow(int WindowID)
{
	return CloseWindow(WindowID);
}

DWORD VKBUTTONQUEST_DELAY;


float TransForXS(float num)
{
	return (float)(pWinWidthReal <= 1.25) ? num * pWinWidthReal : num * pWinHeightReal;
}

float TransForYS(float num)
{
	return (float)num * pWinHeightReal;
}

float TransFor2XS(float num)
{
	return (float)num * pWinWidthReal;
}

float ReturnXS(float num)
{
	return (float)(pWinWidthReal <= 1.25) ? num / pWinWidthReal : num / pWinHeightReal;
}

float Return2XS(float num)
{
	return (float)num / pWinWidthReal;
}

float ReturnYS(float num)
{
	return (float)num / pWinHeightReal;
}

bool CheckButtonPressedS(int x, int y, int w, int h)
{
	return pCheckMouseOver(x, y, w, h) && *(BYTE*)0x8793386;
}

void CInterface::DrawIMG(short ObjectID, float PosX, float PosY, float ScaleX, float ScaleY)
{
	if (this->Data[ObjectID].X == -1 || this->Data[ObjectID].Y == -1)
	{
		this->Data[ObjectID].X = PosX;
		this->Data[ObjectID].Y = PosY;
		this->Data[ObjectID].MaxX = PosX + this->Data[ObjectID].Width;
		this->Data[ObjectID].MaxY = PosY + this->Data[ObjectID].Height;
	}

	RenderBitmap(this->Data[ObjectID].ModelID, PosX, PosY, this->Data[ObjectID].Width, this->Data[ObjectID].Height, 0, 0, ScaleX, ScaleY, 1, 1, 0);
}

void CInterface::DrawInterface97Menu()
{
	gInterface.DrawIMG(eMain, 36, 415, 1.5, 2.0);

	if (IsWorkZone(eParty))
	{
		this->DrawToolTip(345, 420, "Party (P)");
	}
	if (this->CheckWindow(Party))
	{
		gInterface.DrawButton(eParty, 342, 448, 0.0, 0.0);
	}
	if (IsWorkZone(eCharacter))
	{
		this->DrawToolTip(375, 420, "Character (C)");
	}
	if (this->CheckWindow(Character))
	{
		gInterface.DrawButton(eCharacter, 371.5f, 448, 0.0, 0.0);
	}
	if (IsWorkZone(eInventory))
	{
		this->DrawToolTip(405, 420, "Inventory (I-V)");
	}
	if (this->CheckWindow(Inventory))
	{
		gInterface.DrawButton(eInventory, 399, 448, 0.0, 0.0);
	}
	if (IsWorkZone(eShop))
	{
		this->DrawToolTip(430, 420, "CashShop");
	}
	if (this->CheckWindow(CashShop))
	{
		gInterface.DrawButton(eShop, 442.5f, 450, 0.0, 0.0);
	}
	if (IsWorkZone(eFriend))
	{
		this->DrawToolTip(580, 420, "Friends");
	}
	if (this->CheckWindow(FriendList))
	{
		gInterface.DrawButton(eFriend, 581, 433, 0.0, 0.0);
	}
	if (IsWorkZone(eGuild))
	{
		this->DrawToolTip(580, 444, "Guild (G)");
	}
	if (this->CheckWindow(Guild))
	{
		gInterface.DrawButton(eGuild, 529, 460, 0.0, 0.0);
	}


	float Width = TransForXS(640);
	float y = TransForYS(480 - 73);
	float x = TransFor2XS(320) - TransForXS(320);
	int Active;
	float nRenderX;
	float nRenderY;
	float nDropMoveY;

	float LiveRate; // [sp+16Ch] [bp-14h]@16;
	float nHeight; // [sp+158h] [bp-28h]@18
	float nCoord; // [sp+170h] [bp-10h]@18
	float nDropScale1; // ST38_4@18
	float nDropScale2; // ST38_4@18
	float nScale; // ST38_4@18

	//-- HP
	nDropScale1 = 0.986000061;
	nDropScale2 = 0.986000061;

	LiveRate = (double)ViewMaxHP / 100;
	nScale = ((double)ViewCurHP / LiveRate) * (nDropScale1 / 100);
	nDropMoveY = nDropScale1 - nScale; //-- HPCurrent
	nHeight = ((double)ViewCurHP / LiveRate) * (TransForYS(63.75) / 100);
	nCoord = TransForYS(408.125) + TransForYS(63.75) - nHeight;

	nRenderX = x + TransForXS(107.25);

	//RenderBitmap(51502, nRenderX, TransForYS(408.125), TransForXS(63.75), TransForYS(63.75), 0.0, 0.0, nDropScale2, nDropScale1, 0, 0, 0);
	//
	//if (pCheckEffectPlayer((DWORD*)(*(DWORD*)0x7BC4F04 + 1260), 55))
	//{
	//	RenderBitmap(31297, nRenderX, nCoord, TransForXS(63.75), nHeight, 0.0, nDropMoveY, nDropScale2, nScale, 0, 0, 0);
	//}
	//else
	//{
	//	RenderBitmap(31298, nRenderX, nCoord, TransForXS(63.75), nHeight, 0.0, nDropMoveY, nDropScale2, nScale, 0, 0, 0);
	//}
	//-- MP
	nDropScale1 = 0.986000061;
	nDropScale2 = 0.986000061;

	LiveRate = (double)ViewMaxMP / 100;
	nScale = ((double)ViewCurMP / LiveRate) * (nDropScale1 / 100);
	nDropMoveY = nDropScale1 - nScale;
	nHeight = ((double)ViewCurMP / LiveRate) * (TransForYS(63.75) / 100);
	nCoord = TransForYS(408.125) + TransForYS(63.75) - nHeight;

	nRenderX = x + TransForXS(463.75);

	//RenderBitmap(51501, nRenderX, TransForYS(408.125), TransForXS(63.75), TransForYS(63.75), 0.0, 0.0, nDropScale2, nDropScale1, 0, 0, 0);
	//RenderBitmap(31296, nRenderX, nCoord, TransForXS(63.75), nHeight, 0.0, nDropMoveY, nDropScale2, nScale, 0, 0, 0);

	//-- Interface
	//RenderBitmap(31293, x, y, Width, TransForYS(73), 0.0, 0.0, 0.9129598141, 0.8629598618, 0, 0, 0.0);

	for (int i = 0; i < 6; i++)
	{
		nRenderY = y + TransForYS(42.3);
		Active = 0;

		switch (i)
		{
		case 0: //-- XShop
			nRenderX = x + TransForXS(43.5f);
			nDropMoveY = 0.0017000035f;

			if (pCheckWindow(pWindowThis(), CashShop))
			{
				Active = 1;
			}
			break;
		case 1: //-- Character
			nRenderX = x + TransForXS(67.0f);
			nDropMoveY = 0.1100000367f;

			if (pCheckWindow(pWindowThis(), Character))
			{
				Active = 1;
			}
			break;
		case 2: //-- Inventory
			nRenderX = x + TransForXS(92.0f);
			nDropMoveY = 0.2199999988f;

			if (pCheckWindow(pWindowThis(), Inventory))
			{
				Active = 1;
			}
			break;
		case 3: //-- Quest
			nRenderX = x + TransForXS(527.5);
			nDropMoveY = 0.3319000006f;

			if (pCheckWindow(pWindowThis(), Quest))
			{
				Active = 1;
			}
			break;
		case 4: //-- FrientList
			nRenderX = x + TransForXS(552.0f);
			nRenderY = y + TransForYS(42.3);
			nDropMoveY = 0.4429999590f;

			if (pCheckWindow(pWindowThis(), FriendList))
			{
				Active = 1;
			}
			break;
		case 5: //-- Settings
			nRenderX = x + TransForXS(576.0f);
			nRenderY = y + TransForYS(41.4);
			nDropMoveY = 0.5518001318;

			if (pCheckWindow(pWindowThis(), FastMenu))
			{
				Active = 1;
			}
			break;
		}

		if (pCheckMouseOver(Return2XS(nRenderX), ReturnYS(nRenderY), Return2XS(TransForXS(21.5)), 21.5) && i == 3)
		{
			pDrawToolTip(Return2XS(nRenderX), ReturnYS(nRenderY - 15), pGetTextLine(pTextLineThis, 3427));
		}

		if (CheckButtonPressedS(Return2XS(nRenderX), ReturnYS(nRenderY), Return2XS(TransForXS(21.5)), 21.5))
		{
			//RenderBitmap(0x901, nRenderX, nRenderY, TransForXS(21.5), TransForYS(21.5), 0.4560999572, nDropMoveY, 0.4390000105, 0.1105510294, 0, 0, 0.0);

			if (i == 3) //-- Evento Boton Quest
			{
				if (GetTickCount() >= VKBUTTONQUEST_DELAY + 200)
				{
					if (pCheckWindow(pWindowThis(), Quest))
					{
						((int(__thiscall*)(LPVOID This, int Code)) 0x0085F9A0)(pWindowThis(), Quest);
					}
					else
					{
						((int(__thiscall*)(LPVOID This, int Code)) 0x0085EC50)(pWindowThis(), Quest);
						PlayBuffer(25, 0, 0);
					}
					VKBUTTONQUEST_DELAY = GetTickCount();
				}
			}
		}
		else
		{
			//RenderBitmap(0x901, nRenderX, nRenderY, TransForXS(21.5), TransForYS(21.5), (Active == 1) ? 0.4560999572 : 0.0, nDropMoveY, 0.4390000105, 0.1105510294, 0, 0, 0.0);
		}
	}
}

void CInterface::EventNewInterface97_All(DWORD Event)
{
	DWORD CurrentTick = GetTickCount();
	if (this->CheckWindow(ChaosBox))
	{
		return;
	}

	if (IsWorkZone(eParty))
	{
		DWORD Delay = (CurrentTick - this->Data[eParty].EventTick);
		if (Event == WM_LBUTTONDOWN) {
			this->Data[eParty].OnClick = true;
			return;
		}
		this->Data[eParty].OnClick = false;
		if (Delay < 500) {
			return;
		}
		this->Data[eParty].EventTick = GetTickCount();
		if (this->CheckWindow(Party))
		{
			CloseWindow(Party);
		}
		else
		{
			OpenWindow(Party);
		}
	}

	else if (IsWorkZone(eCharacter))
	{
		DWORD Delay = (CurrentTick - this->Data[eCharacter].EventTick);
		if (Event == WM_LBUTTONDOWN) {
			this->Data[eCharacter].OnClick = true;
			return;
		}
		this->Data[eCharacter].OnClick = false;
		if (Delay < 500)
		{
			return;
		}
		this->Data[eCharacter].EventTick = GetTickCount();
		if (this->CheckWindow(Character))
		{
			CloseWindow(Character);
		}
		else
		{
			OpenWindow(Character);
		}
	}
	else if (IsWorkZone(eInventory))
	{
		DWORD Delay = (CurrentTick - this->Data[eInventory].EventTick);
		if (Event == WM_LBUTTONDOWN)
		{
			this->Data[eInventory].OnClick = true;
			return;
		}
		this->Data[eInventory].OnClick = false;
		if (Delay < 500) {
			return;
		}
		this->Data[eInventory].EventTick = GetTickCount();
		if (this->CheckWindow(Inventory))
		{
			CloseWindow(Inventory);
		}
		else
		{
			OpenWindow(Inventory);
		}
	}
	else if (IsWorkZone(eGuild))
	{
		DWORD Delay = (CurrentTick - this->Data[eGuild].EventTick);
		if (Event == WM_LBUTTONDOWN)
		{
			this->Data[eGuild].OnClick = true;
			return;
		}
		this->Data[eGuild].OnClick = false;
		if (Delay < 500)
		{
			return;
		}
		this->Data[eGuild].EventTick = GetTickCount();
		if (this->CheckWindow(Guild))
		{
			CloseWindow(Guild);
		}
		else
		{
			OpenWindow(Guild);
		}
	}
}

void CInterface::DrawCoord()
{
	gObjUser.Refresh();


	if (*(DWORD*)MAIN_SCREEN_STATE == 5)
	{
		pSetBlend(1);
		glColor3f(0.60000002, 0.60000002, 0.60000002);
		RenderNumberRemake(86, 466, gObjUser.lpViewPlayer->MapPosX, 7.0, 7.0);
		RenderNumberRemake(102, 466, gObjUser.lpViewPlayer->MapPosY, 7.0, 7.0);
		glColor3f(1.0, 0.94999999, 0.75);
	}
}

void CInterface::DrawGUI(short ObjectID, float PosX, float PosY)
{
	if (this->Data[ObjectID].X == -1 || this->Data[ObjectID].Y == -1)
	{
		this->Data[ObjectID].X = PosX;
		this->Data[ObjectID].Y = PosY;
		this->Data[ObjectID].MaxX = PosX + this->Data[ObjectID].Width;
		this->Data[ObjectID].MaxY = PosY + this->Data[ObjectID].Height;
	}

	pDrawGUI(this->Data[ObjectID].ModelID, PosX, PosY, this->Data[ObjectID].Width, this->Data[ObjectID].Height);
}

