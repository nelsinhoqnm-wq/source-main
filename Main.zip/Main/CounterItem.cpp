#include "stdafx.h"
#include "CounterItem.h"
#include "Item.h"
#include "Util.h"
#include "LuaStack.hpp"
#include "TradeX.h"
#include "ChaosBoxGenesis.h"
#include "Descriptions.h"

using namespace luaaa;

CCounterItem gCounterItem;

CCounterItem::CCounterItem() : m_Lua(true)
{
	this->m_CounterItemInfo.clear();

	this->m_Inventory.clear();
	this->m_Warehouse.clear();
	this->m_ChaosBox.clear();
	this->m_Trade.clear();
	this->m_TradeTarget.clear();
	this->m_TargetPersonalShop.clear();
	this->m_TradeX.clear();
	this->m_TradeXTarget.clear();
	this->m_ChaosBoxGenesis.clear();
}

CCounterItem::~CCounterItem()
{
	this->m_CounterItemInfo.clear();

	this->m_Inventory.clear();
	this->m_Warehouse.clear();
	this->m_ChaosBox.clear();
	this->m_Trade.clear();
	this->m_TradeTarget.clear();
	this->m_TargetPersonalShop.clear();
	this->m_TradeX.clear();
	this->m_TradeXTarget.clear();
	this->m_ChaosBoxGenesis.clear();
}

DWORD RenderAfterName(DWORD Line, ITEM* itemObject) {
	if (itemObject == nullptr) {
		return Line;
	}

	auto itemInfo = gCounterItem.getItemInfo(itemObject->Type);

	if (itemInfo != nullptr) {
		DWORD count = gCounterItem.getCount(itemObject->x, itemObject->y);

		char buffer[128];

		if (strcmp((char*)MAIN_LANGUAGE, "Eng") == 0) {
			sprintf_s(buffer, itemInfo->TextEng, count);
		}
		else if (strcmp((char*)MAIN_LANGUAGE, "Spn") == 0) {
			sprintf_s(buffer, itemInfo->TextSpn, count);
		}
		else {
			sprintf_s(buffer, itemInfo->TextPor, count);
		}

		memcpy(textLine[Line], buffer, 100);
		textColor[Line] = itemInfo->Color;
		textBold[Line] = itemInfo->Bold;
		Line++;

		memcpy(textLine[Line], "\n", 100);
		textColor[Line] = 0;
		textBold[Line] = 0;
		Line++;
	}

	return Line;
}

__declspec(naked) void RenderDescAfterName() {
	static DWORD m_ReturnFunc = 0x007E4A7A;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x10];
		PUSH EDX;
		MOV EAX, DWORD PTR SS : [EBP - 0x74];
		PUSH EAX;
		CALL[RenderAfterName];
		MOV DWORD PTR SS : [EBP - 0x74], EAX;
		ADD ESP, 0x8;

		MOV EDX, DWORD PTR SS : [EBP + 0x10];
		MOVSX EAX, WORD PTR DS : [EDX];
		CMP EAX, 0x1A1D;
		JMP[m_ReturnFunc];
	}
}

void RegisterItemCount(int ItemIndex, char* TextPor, char* TextEng, char* TextSpn, int Color, int Bold) {
	COUNTER_ITEM_INFO info;

	info.ItemIndex = ItemIndex;

	strcpy_s(info.TextPor, TextPor);

	strcpy_s(info.TextEng, TextEng);

	strcpy_s(info.TextSpn, TextSpn);

	info.Color = Color;

	info.Bold = Bold;

	gCounterItem.m_CounterItemInfo.insert(std::make_pair(info.ItemIndex, info));
}

void CCounterItem::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("RegisterItemCounter", &RegisterItemCount);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//CounterItem.lua");

	this->m_Lua.Generic_Call("StartLoadCounterItem", "");

	SetCompleteHook(0xE9, 0x007E4A72, &RenderDescAfterName);
}

void CCounterItem::ClearById(int type)
{
	if (type == 0) {
		this->m_Inventory.clear();
	}
	else if (type == 1) {
		this->m_Warehouse.clear();
	}
	else if (type == 2) {
		this->m_Trade.clear();
	}
	else if (type == 3) {
		this->m_ChaosBox.clear();
	}
	else if (type == 4) {
		this->m_TradeTarget.clear();
	}
	else if (type == 5) {
		this->m_TargetPersonalShop.clear();
	}
	else if (type == 6) {
		this->m_TradeX.clear();
	}
	else if (type == 7) {
		this->m_TradeXTarget.clear();
	}
	else if (type == 8) {
		this->m_ChaosBoxGenesis.clear();
	}
}

COUNTER_ITEM_INFO* CCounterItem::getItemInfo(int ItemIndex)
{
	std::map<int, COUNTER_ITEM_INFO>::iterator it = this->m_CounterItemInfo.find(ItemIndex);

	if (it == this->m_CounterItemInfo.end()) {
		return 0;
	}

	return &it->second;
}

bool CCounterItem::CheckIsItem(int ItemIndex)
{
	std::map<int, COUNTER_ITEM_INFO>::iterator it = this->m_CounterItemInfo.find(ItemIndex);

	if (it == this->m_CounterItemInfo.end()) {
		return 0;
	}

	return 1;
}

void CCounterItem::InserCounterItem(WORD ItemIndex, BYTE Slot, WORD Type, DWORD kills)
{
	COUNTER_ITEMS info;

	info.ItemIndex = ItemIndex;
	info.Slot = Slot;
	info.kills = kills;

	if (Type == 0) {
		this->m_Inventory.insert(std::make_pair(info.Slot, info));
	}
	else if (Type == 1) {
		this->m_Warehouse.insert(std::make_pair(info.Slot, info));
	}
	else if (Type == 2) {
		this->m_Trade.insert(std::make_pair(info.Slot, info));
	}
	else if (Type == 3) {
		this->m_ChaosBox.insert(std::make_pair(info.Slot, info));
	}
	else if (Type == 4) {
		this->m_TradeTarget.insert(std::make_pair(info.Slot, info));
	}
	else if (Type == 5) {
		this->m_TargetPersonalShop.insert(std::make_pair(info.Slot, info));
	}
	else if (Type == 6) {
		this->m_TradeX.insert(std::make_pair(info.Slot, info));
	}
	else if (Type == 7) {
		this->m_TradeXTarget.insert(std::make_pair(info.Slot, info));
	}
	else if (Type == 8) {
		this->m_ChaosBoxGenesis.insert(std::make_pair(info.Slot, info));
	}
}

DWORD CCounterItem::getCount(int x, int y)
{
	int type = 0;
	int slot = -1;

	if (CheckWindowOpen(ObjWindow::Inventory)) {
		bool slotFind = false;

		if (CheckWindowOpen(ObjWindow::Store)) {
			if (CheckMouseIn(*(DWORD *)((DWORD)pMyShopInventoryThis(pWindowThis()) + 20), *(DWORD *)((DWORD)pMyShopInventoryThis(pWindowThis()) + 24), 190, 429)) {
				slot = (y * 4 + x) + 204;
				slotFind = true;
			}
		}
		else if (CheckWindowOpen(ObjWindow::OtherStore)) {
			if (CheckMouseIn(*(DWORD *)((DWORD)pMyShopInventoryTargetThis(pWindowThis()) + 20), *(DWORD *)((DWORD)pMyShopInventoryTargetThis(pWindowThis()) + 24), 190, 429)) {
				type = 5;
				slot = (y * 4 + x) + 204;
				slotFind = true;
			}
		}
		else if (CheckWindowOpen(ObjWindow::Warehouse)) {
			if (CheckMouseIn(*(DWORD *)((DWORD)pMyStorageThis(pWindowThis()) + 16), *(DWORD *)((DWORD)pMyStorageThis(pWindowThis()) + 20), 190, 429)) {
				type = 1;
				slot = (y * 8 + x);
				slotFind = true;
			}
		}
		else if (CheckWindowOpen(ObjWindow::ChaosBox)) {
			if (gChaosBoxGenesis.isVisible()) {
				if (gChaosBoxGenesis.ItemPointer != -1) {
					slot = gChaosBoxGenesis.ItemPointer;
					type = 8;
					slotFind = true;
				}
			}
			else {
				if (CheckMouseIn(*(DWORD *)((DWORD)pMixInventoryThis(pWindowThis()) + 20), *(DWORD *)((DWORD)pMixInventoryThis(pWindowThis()) + 24), 190, 429)) {
					type = 3;
					slot = (y * 4 + x);
					slotFind = true;
				}
			}
		}
		else if (CheckWindowOpen(ObjWindow::Trade)) {
			if (gTradeX.isVisible()) {
				if (gTradeX.ItemPointer != -1) {
					slot = gTradeX.ItemPointer;
					type = 6;
					slotFind = true;
				}
				else if (gTradeX.ItemPointerTarget != -1) {
					slot = gTradeX.ItemPointerTarget;
					type = 7;
					slotFind = true;
				}
			}
			else {
				if (CheckMouseIn(*(DWORD *)((DWORD)pTradeInventoryThis(pWindowThis()) + 16), *(DWORD *)((DWORD)pTradeInventoryThis(pWindowThis()) + 20), 190, 429)) {
					if (pTradeGetPointedMyInvItemIndex(pTradeInventoryThis(pWindowThis())) != -1) {
						type = 2;
						slot = (y * 4 + x);
					}
					else if (pTradeGetPointedYourItemIndex(pTradeInventoryThis(pWindowThis())) != -1) {
						type = 4;
						slot = (y * 4 + x);
					}

					slotFind = true;
				}
			}
		}

		if (!slotFind) {
			bool IsExtInv = ((bool(__thiscall*)(LPVOID This)) 0x007D5200)(((LPVOID(__thiscall*)(LPVOID))0x861A60)(pWindowThis()));

			if (IsExtInv) {
				DWORD ItemExpanded1 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 1), pCursorX, pCursorY);

				if (ItemExpanded1 != -1) {
					slot = ItemExpanded1 + 76;
				}
				else {
					DWORD ItemExpanded2 = pInventoryCtrlFindItemptIndex(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 2), pCursorX, pCursorY);

					if (ItemExpanded2 != -1) {
						slot = ItemExpanded2 + 108;
					}
				}
			}
			else if (CheckMouseIn(*((DWORD *)pInventoryThis(pWindowThis()) + 9), *((DWORD *)pInventoryThis(pWindowThis()) + 10), 190, 429)) {
				if (*((DWORD *)pInventoryThis(pWindowThis()) + 71) != -1) {
					slot = *((DWORD *)pInventoryThis(pWindowThis()) + 71);
				}
				else {
					slot = (y * pInventoryCtrlGetNumberOfColumn(pInventoryGetMyInventoryCtrl(pInventoryThis(pWindowThis()), 0)) + x) + 12;
				}
			}
		}
	}

	if (slot == -1) {
		return 0;
	}

	if (type == 0) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_Inventory.find(slot);

		if (it == this->m_Inventory.end()) {
			return 0;
		}

		return it->second.kills;
	}
	else if (type == 1) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_Warehouse.find(slot);

		if (it == this->m_Warehouse.end()) {
			return 0;
		}

		return it->second.kills;
	}
	else if (type == 2) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_Trade.find(slot);

		if (it == this->m_Trade.end()) {
			return 0;
		}

		return it->second.kills;
	}
	else if (type == 3) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_ChaosBox.find(slot);

		if (it == this->m_ChaosBox.end()) {
			return 0;
		}

		return it->second.kills;
	}
	else if (type == 4) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_TradeTarget.find(slot);

		if (it == this->m_TradeTarget.end()) {
			return 0;
		}

		return it->second.kills;
	}
	else if (type == 5) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_TargetPersonalShop.find(slot);

		if (it == this->m_TargetPersonalShop.end()) {
			return 0;
		}

		return it->second.kills;
	}
	else if (type == 6) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_TradeX.find(slot);

		if (it == this->m_TradeX.end()) {
			return 0;
		}

		return it->second.kills;
	}
	else if (type == 7) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_TradeXTarget.find(slot);

		if (it == this->m_TradeXTarget.end()) {
			return 0;
		}

		return it->second.kills;
	}
	else if (type == 8) {
		std::map<int, COUNTER_ITEMS>::iterator it = this->m_ChaosBoxGenesis.find(slot);

		if (it == this->m_ChaosBoxGenesis.end()) {
			return 0;
		}

		return it->second.kills;
	}

	return 0;
}
