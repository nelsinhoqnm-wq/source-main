#include "stdafx.h"
#include "LoginRemake.h"
#include "Util.h"
#include "Interface.h"
#include "Offset.h"

int PointSY1 = 220;

float getX2(float x)
{
	return x / g_fScreenRate_x;
}
float getY2(float y)
{
	float fixResu = ((float)pWinWidth) / (((float)pWinHeight) * (640.0f / 480.0f)); //fix custom res
	return y / g_fScreenRate_x * fixResu;
}

void LoginBoxRemake()
{	
	int v8; // eax@8
	int v11; // ST04_4@11
	int v17; // ST00_4@11
	int v25; // [sp+101Ch] [bp-1Ch]@32
	int v26; // [sp+1020h] [bp-18h]@26
	char v24; // [sp+814h] [bp-824h]@33
	int v29; // [sp+1034h] [bp-4h]@33
	int v48; // [sp+2Ch] [bp-7Ch]@7	

	//Complementa��o para resolu��es
	int PosXLoginAndSenha = 0;
	int PosXLoginAndSenha2 = 0;
	int PosYLoginAndSenha = 0;
	int PosXConnect = 0;
	int PosYConnect = 0;
	int PosXExit = 0;
	int PosYExit = 0;
	//1280x1024
	int PosPart1Y = 0;
	
	int Baixar = 53;
	int Struct = _Instance() + 16968;
	float startX = (640.0 - getX2(329)) / 2, startY = (480.0 - getY2(245)) * 2.0 / 3.0;

	if(pWinWidth <= 800)
	{
		PosXLoginAndSenha = 17;
		PosXLoginAndSenha2 = 62;
		PosYLoginAndSenha = 16; // CAMPO DE SENHA
		PosXConnect = -25;
		PosYConnect = 5;
		PosXExit = -2;
		PosYExit = -19;
	}
	if(pWinWidth == 1024)
	{
		PosXLoginAndSenha = 8;
		PosXLoginAndSenha2 = 37;
		PosXConnect = -8;
	}
	if(pWinWidth == 1280 && pWinHeight == 1024)
	{
		PosXLoginAndSenha = 15;
		PosXLoginAndSenha2 = 19;
		PosYLoginAndSenha = -13;
		PosXConnect = -25;
		PosYConnect = 5;
		PosXExit = -2;
		PosYExit = -19;
	}
	if(pWinWidth == 1440 && pWinHeight == 900)
	{
		PosXLoginAndSenha = -2;
		PosYLoginAndSenha = -10;
		PosPart1Y = 7;
		PosYExit = 12;
		PosXConnect = 3;
		PosYConnect = -3;
	}
	if(pWinWidth == 1680 && pWinHeight == 1050)
	{
		PosXLoginAndSenha2 = -9;
		PosXLoginAndSenha = -5;
		PosYLoginAndSenha = -18;
		PosPart1Y = 7;
		PosYExit = 19;
		PosXConnect = 8;
		PosYConnect = -3;
	}
	if(pWinWidth >= 1920)
	{
		PosXLoginAndSenha2 = -15;
		PosXLoginAndSenha = -7;
		PosYLoginAndSenha = -18;
		PosPart1Y = 7;
		PosYExit = 22;
		PosXConnect = 10;
		PosYConnect = -3;
	}

// - Campo de Login e Senha
	if (*(DWORD*)0xE60960 == 1)
	{
		SetBoundInputField(*(DWORD *)(Struct + 848),startX + getX2(114) + PosXLoginAndSenha, startY + getY2(56) + Baixar + PointSY1 + PosYLoginAndSenha);
		SetBoundInputField(*(DWORD *)(Struct + 852),startX + getX2(114) + PosXLoginAndSenha, startY + getY2(88) + Baixar + PointSY1 + PosYLoginAndSenha + PosPart1Y);
	}

	if(*(int*)0x87935A4 == 2) //Tela de Login
	{	
		if (SEASON3B_CheckMouseIn(326, 351, 67, 15))	
		{
			if (IsPress(1))
			{	
				PlayBuffer(27, 0, 0);
				RequestLogin(Struct);
			}
		}
		if (SEASON3B_CheckMouseIn(287, 436, 67, 15))	
		{
			if (IsPress(1))
			{	
				PlayBuffer(27, 0, 0);
				CancelLogin(Struct);
			}
		}

		if (PointSY1 >= 20)
		{
			PlayBuffer(27, 0, 0);
			PointSY1 -= 20;
		}
	}
	else
	{
		if(SceneFlag == 4)
		{
			if (PointSY1 <= 220)
			{
				PointSY1 += 20;		
			}	
		}
		else
		{
			if (PointSY1 <= 220)
			{
				PointSY1 += 20;		
			}
		}
	}
	//	
	EnableAlphaTest(1);
	// - Imagem LoginBox
	((void(*)()) 0x637770)();
	glColor4f(1.0, 1.0, 1.0, 1.0); //Bota isso antes da imagem
	RenderBitmap(531020, 195.0, 200.5 + Baixar + PointSY1, 250.0, 216.0, 0, 0, 0.9765625, 0.84375, 1, 1, 0.0); //LoginBox

	if(*(int*)0x87935A4 == 2) //Tela de Login
	{	
		if (SEASON3B_CheckMouseIn(326, 351, 67, 15))	
		{
			RenderBitmap(531021, 324.0, 295.0 + Baixar + PointSY1, 70.0, 19.0, 0, 0, 0.546875, 0.59375, 1, 1, 0.0); //Connect
		}

		if (SEASON3B_CheckMouseIn(287, 436, 67, 15))	
		{
			RenderBitmap(531022, 285.0, 380.5 + Baixar, 70.0, 20.0, 0, 0, 0.546875, 0.625, 1, 1, 0.0);
		}

		DisableAlphaBlend();
	}

	glColor4f(1.0, 1.0, 1.0, 1.0); //Bota isso depois da imagem
	((void(*)()) 0x6366F0)();

	// - Vari�veis de texto
	pSetBackgroundTextColor(pTextThis(), 0, 0, 0, 0);
	pSetFont(pTextThis(), (int)pFontNormal2);
	pSetTextColor(pTextThis(), 250, 219, 168, 0xFF);
	//pDrawText(pTextThis(), startX + getX(124), startY + getY(158) + Baixar, "Save password", getX(120), 0, (PINT)4, 0);
	pDrawText(pTextThis(), startX + getX2(142) + PosXConnect, startY + getY2(134) + Baixar + PointSY1 + PosYConnect, GlobalText(452)/*Connect*/, getX2(120), 0, 4, 0);
	pDrawText(pTextThis(), startX - getX2(93) + PosXLoginAndSenha2, startY + getY2(50) + Baixar + PointSY1 + PosYLoginAndSenha, GlobalText(450)/*Login*/, getX2(120), 0, 4, 0);
	pDrawText(pTextThis(), startX - getX2(90) + PosXLoginAndSenha2, startY + getY2(85) + Baixar + PointSY1 + PosYLoginAndSenha + PosPart1Y, GlobalText(451)/*Senha*/, getX2(120), 0, 4, 0);
	pDrawText(pTextThis(), startX + getX2(55) + PosXExit, startY + getY2(270) + Baixar + PointSY1 + PosYExit, GlobalText(453)/*Exit*/, getX2(120), 0, 4, 0);

	pSetTextColor(pTextThis(), 255, 255, 255, 0xFFu);
}

int __fastcall LoginBoxText(int a1, int a2, signed int a3, signed int a4, char a5)
{
	return DisplayInfoBarCharacter(a1, a2, a3, a4 - 56 + PointSY1, a5);
}

int __fastcall PasswordBoxText(int a1, int a2, signed int a3, signed int a4, char a5)
{
	return DisplayInfoBarCharacter(a1, a2, a3, a4 - 45 + PointSY1, a5);
}

void CentralTextLoginBox(int iPos_x, int iPos_y, LPCSTR pszText, int iBoxWidth, int iBoxHeight, int iSort, OUT SIZE* lpTextSize)
{	
	pRender_rendertext(g_Fontthis(), iPos_x - 25, iPos_y - 32, "", iBoxWidth, iBoxHeight, iSort, lpTextSize);
}

void RemakeLoginLoad()
{
	SetDword(0x006311B6+1, (DWORD)"Custom\\InterfaceS2\\none.tga");		//Remo��o Interface LoginBox
	SetDword(0x006311D6+1, (DWORD)"Custom\\InterfaceS2\\none.tga");		//Remo��o Interface LoginBox

	SetCompleteHook(0xE8, 0x004D7D13, &LoginBoxRemake);					//Adi��o de nova Login_back.tga
	SetCompleteHook(0xE8, 0x0040B1EF, &LoginBoxText);					//Deslocamento do campo de Login
	SetCompleteHook(0xE8, 0x0040B210, &PasswordBoxText);				//Deslocamento do campo de Senha
	SetCompleteHook(0xE8, 0x0040B6A7, &CentralTextLoginBox);			//Deslocamento do texto de Login e Senha - Fazendo sua remo��o
	SetCompleteHook(0xE8, 0x0040B635, &CentralTextLoginBox);			//Deslocamento do texto de Login e Senha - Fazendo sua remo��o
	
	MemorySet(0x0040B7A2,0x90,0x5);										//Remo��o Room Name
	MemorySet(0x0040B2E2,0x90,0x5);										//Remo��o Bot�o OK e Cancelar
	MemorySet(0x0040B306,0x90,0x5);										//Remo��o Bot�o OK e Cancelar
	MemorySet(0x0040B380,0x90,0x5);										//Remo��o Bot�o OK e Cancelar

	MemorySet(0x00401F56,0x90,0x5);
}