#pragma once

#define MAX_MAIN_VIEWPORT 400

#define pMapNumber *(int*)0x0E61E18
#define MAIN_LANGUAGE 0x00E8C5C4
#define MAIN_CONNECTION_STATUS 0x08793704
#define MAIN_SCREEN_STATE 0x00E609E8
#define MAIN_CHARACTER_STRUCT 0x08128AC8
#define MAIN_VIEWPORT_STRUCT 0x07BC4F04
#define MAIN_PACKET_SERIAL 0x08793700
#define MAIN_HELPER_STRUCT 0x00E8CB7C
#define MAIN_FONT_SIZE 0x081C0380
#define MAIN_RESOLUTION 0x00E8C240
#define MAIN_RESOLUTION_X 0x00E61E58
#define MAIN_RESOLUTION_Y 0x00E61E5C
#define MAIN_PARTY_MEMBER_COUNT 0x081F6B6C
#define MAIN_WINDOW *(HWND*)0x0E8C578
#define MAIN_HDC *(HDC*)0xE8C580

#define g_hFont *(HFONT*)0xE8C588
#define g_hFontBold *(HFONT*)0xE8C58C
#define g_hFontBig *(HFONT*)0xE8C590
#define g_hFontFix *(HFONT*)0xE8C594

#define ProtocolCore ((BOOL(*)(DWORD,BYTE*,DWORD,DWORD))0x00663B20)
#define DrawInterface ((void(*)(DWORD,float,float,float,float))0x00790B50)
#define DrawInterfaceText ((void(*)(char*,int,int,int,int,int,int,int))0x007D04D0)

#define pInputKeyThis ((LPVOID(*)()) 0x791100)
#define pInputRepeat ((bool(__thiscall*)(LPVOID, BYTE value)) 0x791300)

#define pWindowThis ((LPVOID(*)()) 0x861110)
#define pSetCursorFocus *(DWORD*)0xE8CB3C

#define pSetBlend ((void(__cdecl*)(BYTE Mode)) 0x635FD0)
#define pGLSwitchBlend  ((void(__cdecl*)()) 0x636070)
#define pGLSwitch ((void(__cdecl*)()) 0x635F50)
#define pCursorX *(int*)0x879340C
#define pCursorY *(int*)0x8793410
#define pDrawBarForm ((void(__cdecl*)(float PosX, float PosY, float Width, float Height, float Arg5, int Arg6)) 0x6378A0)
#define EnableAlphaTest ((void(__cdecl*)(bool Mode)) 0x00635FD0)
#define EnableAlphaBlend ((void(__cdecl*)()) 0x00635F50)
#define DisableAlphaBlend ((void(__cdecl*)()) 0x00635F50)


#define pTextThis ((LPVOID(*)()) 0x0041FE10)
#define pTextSetFont ((void(__thiscall*)(LPVOID This, HFONT font)) 0x00420120)
#define pSetTextColor ((void(__thiscall*)(LPVOID This, BYTE r, BYTE g, BYTE b, BYTE h)) 0x00420040)
#define pSetTextBgColor ((void(__thiscall*)(LPVOID This, BYTE r, BYTE g, BYTE b, BYTE h)) 0x004200B0)
#define pSetTextBgColor2 ((void(__thiscall*)(LPVOID This, DWORD color)) 0x004200F0)
#define pDrawText ((int(__thiscall*)(LPVOID This, int PosX, int PosY, LPCTSTR Text, int nCount, int nTabPositions, int lpnTabStopPositions, SIZE* nTabOrigin)) 0x00420150)

#define pChatThis ((LPVOID(__thiscall*)(LPVOID This)) 0x861220)
#define pChatBoxThis ((LPVOID(__thiscall*)(LPVOID This)) 0x861180)
#define pChatOutput ((void(__thiscall*)(LPVOID This, char* Name, char* Message, DWORD Type, DWORD Arg4)) 0x007894E0)
#define pChatIsClosed ((bool(__thiscall*)(LPVOID This)) 0x786110)

#define pGetPosFromAngle		((void(__cdecl*)(vec3_t * Angle, int * PosX, int * PosY)) 0x635B00)
#define pTextThis				((LPVOID(*)()) 0x0041FE10)

#define pInventoryThis ((LPVOID(__thiscall*)(LPVOID This)) 0x861260)
#define pInventoryGetPointedItemIndex ((int(__thiscall*)(LPVOID This)) 0x0083BF60)
#define pInventoryGetMyInventoryCtrl ((LPVOID(__thiscall*)(LPVOID This, DWORD type)) 0x00835720)
#define pInventoryFindItem ((ITEM*(__thiscall*)(LPVOID This, DWORD, DWORD)) 0x00835750)
#define pInventoryUnequipItem ((ITEM*(__thiscall*)(LPVOID This, DWORD)) 0x00833B20)
#define pInventoryCtrlFindItem ((ITEM*(__thiscall*)(LPVOID This, DWORD, DWORD)) 0x007DAC10)
#define pInventoryIsInvenctrlSame ((DWORD(__thiscall*)(LPVOID This, DWORD)) 0x83C710)
#define pInventorySlotCntSendSrcInvenIndex ((DWORD(__thiscall*)(LPVOID This, DWORD, DWORD)) 0x83C480)

#define pMyShopInventoryThis ((LPVOID(__thiscall*)(LPVOID This)) 0x861400)
#define pMyShopInventoryFindItemThis ((ITEM*(__thiscall*)(LPVOID This, DWORD)) 0x840F40)
#define pMyShopInventorySetInputValueTextBox ((void(__thiscall*)(LPVOID This, bool)) 0x842590)
#define pMyShopInventoryIsEnablePersonalShop ((bool(__thiscall*)(LPVOID This)) 0x841350)
#define pMyShopInventoryGetTargetIndex ((int(__thiscall*)(LPVOID This)) 0x668A00)
#define pMyShopInventoryGetMyInventoryCtrl ((DWORD(__thiscall*)(LPVOID This)) 0x668850)

#define pMyShopInventoryTargetThis ((LPVOID(__thiscall*)(LPVOID This)) 0x861420)

#define pMyStorageThis ((LPVOID(__thiscall*)(LPVOID This)) 0x861360)
#define pMyStorageGetPointedItemIndex ((int(__thiscall*)(LPVOID This)) 0x8591C0)

#define pInventoryCtrlFindItemptIndex ((int(__thiscall*)(LPVOID This, DWORD, DWORD)) 0x007DAC40)
#define pInventoryCtrlFindItemAtPt ((ITEM*(__thiscall*)(LPVOID This, DWORD, DWORD, DWORD*)) 0x0083CAB0)
#define pInventoryCtrlGetNumberOfColumn ((int(__thiscall*)(LPVOID This))0x7DC280)
#define pInventoryCtrlDeleteItem ((void(__thiscall*)(LPVOID This, ITEM*)) 0x007DA480)
#define pInventoryFindEmptySlot ((int(__thiscall*)(LPVOID This, DWORD, DWORD)) 0x00835940)
#define pInventoryCtrlFindEmptySlot ((int(__thiscall*)(LPVOID This, DWORD, DWORD)) 0x007DACA0)

#define pMixInventoryThis ((LPVOID(__thiscall*)(LPVOID This)) 0x8612C0)
#define pMixGetMyInventoryCtrl ((LPVOID(__thiscall*)(LPVOID Thise)) 0x0082C780)

#define pTradeInventoryThis ((LPVOID(__thiscall*)(LPVOID This)) 0x861540)
#define pTradeGetMyInventoryCtrl ((LPVOID(__thiscall*)(LPVOID Thise)) 0x007D9130)
#define pTradeGetPointedMyInvItemIndex ((int(__thiscall*)(LPVOID This)) 0x866980)
#define pTradeGetPointedYourItemIndex ((int(__thiscall*)(LPVOID This)) 0x8669A0)

#define OpenWindow(x) ((int(__thiscall*)(LPVOID This, int Code)) 0x0085EC50)(((LPVOID(*)()) 0x861110)(), x)
#define CloseWindow(x) ((int(__thiscall*)(LPVOID This, int Code)) 0x0085F9A0)(((LPVOID(*)()) 0x861110)(), x)

#define pGetItemAttr(index)   (ITEM_ATTRIBUTE*)(*(DWORD*)0x8128AC0 + sizeof(ITEM_ATTRIBUTE) * index)

#define pGetPreviewStruct        ((DWORD(__thiscall*)(LPVOID This, int ViewportID)) 0x96A340)
#define pPreviewThis            ((LPVOID(*)()) 0x402BC0)

#define oUserObjectStruct		*(int*)0x8128AC8
#define oUserObjectStruct_		*(int*)0x8128AC4
#define pUserObjectStruct		&*(ObjectCharacter*)oUserObjectStruct
#define oUserPreviewStruct		*(int*)0x7BC4F04

#define pDrawButton					((void(__cdecl*)(DWORD ModelID, float X, float Y, float W, float H, float CurrentX, float CurrentY)) 0x00790E40)
#define pSetBackgroundTextColor		((void(__thiscall*)(LPVOID This, int r, int g, int b, int h)) 0x004200B0)
#define pGetTextLine				((char*(__thiscall*)(LPVOID This, int LineNumber)) 0x00402320)
#define pTextLineThis				((LPVOID(*)()) 0x008128ADC)
#define pDrawToolTip				((int(__cdecl*)(int X, int Y, LPCSTR Text)) 0x00597220)
#define pDrawGUI					((void(__cdecl*)(DWORD, float, float, float, float)) 0x00790B50)
#define pDrawColorText				((int(__cdecl*)(LPCTSTR Text, int PosX, int PosY, int Width, int Arg5, int Color, int Arg7, int Align)) 0x007D04D0)
#define pDrawMessage				((int(__cdecl*)(LPCSTR Text, int Mode)) 0x00597630)


#define oGuildMarkStruct		*(int*)0x81CB588
#define GuildMarkStruct(GuildMarkIndex)   (MARK_t*)(oGuildMarkStruct + sizeof(MARK_t) * GuildMarkIndex)

#define GuildMarkGetName(GuildMarkIndex) (char*)(*(BYTE*)0x81CB595 + 88 * GuildMarkIndex)

#define KIND_PLAYER  1
#define KIND_MONSTER 2
#define KIND_NPC     4
#define KIND_TRAP    8
#define KIND_OPERATE 16     //  
#define KIND_EDIT    32
#define KIND_PET     64
#define KIND_TMP     128

#define Hero &*(ObjectPreview*)oUserPreviewStruct

#define MAX_ITEM_INFO 12

#define pGetMapName					((char*(__cdecl*)(int MapNumber)) 0x005D2C10)

#define g_isCharacterBuff ((bool(__thiscall*)(LPVOID, BYTE))0x4C8640)

#define CreateAngle ((float(*)(float, float, float, float))0x540C30)
#define TurnAngle2 ((float(*)(float, float, float))0x540EA0)
#define PositionMap ((int(*)(int, int)) 0x5D6700)
#define SetCurrentAction ((void(*)(ObjectModel *, int, int))0x542310)

#define CheckWindowOpen(window) ((bool(__thiscall*)(LPVOID This, int Code)) 0x0085EC20)(((LPVOID(*)()) 0x861110)(), window)
#define IsPressKey(key) ((int(*)(int))0x791070)(key)
#define IsRepeatKey(key) ((int(*)(int))0x791090)(key)
#define CheckMouseIn ((bool(*)(int, int, int, int))0x790B10)

#define GetPickedItem ((DWORD(*)())0x7DD0F0)
#define ResetMouseR ((void(*)())0x83C0A0)
#define ResetMouseL ((void(*)())0x83C080)

#define GetBaseClass ((BYTE(*)(BYTE))0x405230)

#define RenderImage ((void(__cdecl*)(DWORD, float, float, float, float)) 0x00790B50)
#define RenderImage2 ((void(__cdecl*)(int Texture, float x, float y, float Width, float Height, float u, float v, float uWidth, float vHeight, bool Scale, bool StartScale, float Alpha)) 0x00637C60)

#define GlobalText(x) ((char*(__thiscall*)(DWORD, int))0x402320)(*(DWORD*)0x8128ADC, x)

#define pRecoveryPotionOn			*(BYTE*)(*(DWORD*)(0x00E8CB7C) + 176)
#define pRecoveryPotionPercent		*(BYTE*)(*(DWORD*)(0x00E8CB7C) + 177)
#define pRecoveryHealOn				*(BYTE*)(*(DWORD*)(0x00E8CB7C) + 178)
#define pRecoveryHealPercent		*(BYTE*)(*(DWORD*)(0x00E8CB7C) + 179)
#define pGetItemList( x )			((const char*) (*(DWORD*)(0x00E8CB7C)+ 304 + ( 28 * x )))

#define pGetThisEffect ((LPVOID(__cdecl*)(int a1)) 0x009D00C5)
#define pAddEffect ((LPVOID(__thiscall*)(LPVOID, int32_t, int32_t, bool, float_t, float_t, float_t, float_t, float_t, float_t)) 0x004EFFF0)
#define pAddEffect2 ((LPVOID(__thiscall*)(LPVOID, int32_t, int32_t, int32_t, float_t, float_t, float_t)) 0x4F0730)

#define pEventEffectThis			((LPVOID(__cdecl*)(int Arg1)) 0x9D00C5)
#define pAddEventEffect				((LPVOID(__thiscall*)(LPVOID This, int ModelID, int a3, bool bFixRotation, float a5, float a6, float a7, float a8, float a9, float a10)) 0x4EFFF0)
#define pAddEventEffect2			((LPVOID(__thiscall*)(LPVOID This, int ModelID, int a3, int a4, float a5, float a6, float a7)) 0x4F0730)

#define pWzAudioPlay  ((void(__cdecl*)(PCHAR MusicId,int Arg2))0x004CF050)
#define pWzAudioStop  ((void(__cdecl*)(PCHAR MusicId,int Arg2))0x004CF000)
#define pLoadGameStuffs  ((void(__cdecl*)(HDC Arg1))0x004D9CF0)
#define pCheckMouseOver					((bool(__cdecl*)(int a1, int a2, int a3, int a4)) 0x00790B10)
#define RenderBitmap						((void(__cdecl*)(int a1, float a2, float a3, float a4, float a5, float a6, float a7, float a8, float a9, char a10, char a11, float a12)) 0x00637C60)
#define PlayBuffer						((signed int(__cdecl*)(int a1, int a2, int a3)) 0x006D6C20)
#define pWinWidth				*(GLsizei*)0x0E61E58
#define pWinHeight				*(GLsizei*)0x0E61E5C
#define pWinWidthReal			*(float*)0xE7C3D4
#define pWinWidthReal2	        1.5f
#define pWinHeightReal			*(float*)0xE7C3D8
#define pWinHeightReal2	        1.25f
#define pWinFontHeight			*(int*)0x81C0380
#define pCheckEffectPlayer					((bool(__thiscall*)(void * This,char a2)) 0x004C8640)
#define pCheckWindow			((bool(__thiscall*)(LPVOID This, int Code)) 0x0085EC20)
#define pDrawItemModel			((int(__cdecl*)(float PosX, float PosY, float Width, float Height, int ItemID, int a6, int a7, float a8, char a9)) 0x5CF310)
#define pGetUserCoorX				*(DWORD *)(*(DWORD *)0x7BC4F04 + 0xAC)
#define pGetUserCoorY				*(DWORD *)(*(DWORD *)0x7BC4F04 + 0xB0)