#include "stdafx.h"
#include "MakePreview.h"
#include "CustomPreview.h"
#include "CustomWing.h"
#include "HelperSystem.h"
#include "HelperManager.h"
#include "Item.h"
#include "Util.h"
#include "AntiHack.h"
#include "Console.h"
#include "ElementPet.h"
#include "DarkSpirit.h"

CMakePreview gMakePreview;

CMakePreview::CMakePreview()
{

}

CMakePreview::~CMakePreview()
{

}

void CMakePreview::Init()
{
	SetCompleteHook(0xE8, 0x0048FB8C, &this->ChangeCharacterExt);
	SetCompleteHook(0xE8, 0x0063D2D8, &this->ChangeCharacterExt);
	SetCompleteHook(0xE8, 0x00641189, &this->ChangeCharacterExt);
	SetCompleteHook(0xE8, 0x00641F42, &this->ChangeCharacterExt);
	SetCompleteHook(0xE8, 0x00642598, &this->ChangeCharacterExt);
	SetCompleteHook(0xE8, 0x0065EA2D, &this->ChangeCharacterExt);

	SetCompleteHook(0xE8, 0x00664267, &this->ReceiveChangePlayer);

	SetCompleteHook(0xE9, 0x0057F920, &this->SetChangeClass);
}

void CMakePreview::ChangeCharacterExt(int Key, BYTE * Equipment, ObjectPreview * pCharacter, ObjectModel * pHelper)
{
	//((void(*)(int, BYTE*, ObjectPreview*, ObjectModel*))0x57FD90)(Key, Equipment, pCharacter, pHelper);

	ObjectPreview* character = nullptr;

	if (pCharacter)
	{
		character = pCharacter;
	}
	else
	{
		character = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), Key);
	}

	if (character == nullptr) {
		return;
	}

	if (character->Object.Type != 1163) {
		return;
	}

	WORD ExtType = *Equipment | (WORD)(16 * (Equipment[11] & 0xF0));

	if (ExtType == 4095) {
		character->WeaponFirstSlot = -1;
		character->WeaponFirstExcellent = 0;
		character->WeaponFirstAncient = 0;
	}
	else {
		character->WeaponFirstSlot = ExtType + 1171;
	}

	ExtType = Equipment[1] | (WORD)(16 * (Equipment[12] & 0xF0));

	if (ExtType == 4095) {
		character->WeaponSecondSlot = -1;
		character->WeaponSecondExcellent = 0;
		character->WeaponSecondAncient = 0;
	}
	else {
		if (((BYTE(*)(BYTE))0x405230)(character->Class) == 4 && ExtType == 2565) {
			DWORD PetInfo = ((DWORD(*)(DWORD))0x4F9930)((DWORD)*(WORD*)(*(DWORD*)0x8128AC4 + 4779));

			((void(*)(ObjectPreview*))0x4F8B80)(character);

			if (!((bool(*)(int))0x4E65A0)(pMapNumber)) {
				((void(__thiscall*)(DWORD*, DWORD))0x4FA780)((DWORD*)character->m_pPet, PetInfo);
			}
		}
		else {
			character->WeaponSecondSlot = ExtType + 1171;
		}

		if (gDarkSpirit.checkIsDarkSpirit(ExtType)) {
			DWORD PetInfo = ((DWORD(*)(DWORD))0x4F9930)((DWORD)*(WORD*)(*(DWORD*)0x8128AC4 + 4779));

			((void(*)(ObjectPreview*))0x4F8B80)(character);

			if (!((bool(*)(int))0x4E65A0)(pMapNumber)) {
				((void(__thiscall*)(DWORD*, DWORD))0x4FA780)((DWORD*)character->m_pPet, PetInfo);
			}
		}
	}

	BYTE Type = (Equipment[4] >> 2) & 3;

	switch (Type)
	{
	case 1:
		Type = Equipment[8] & 0x07;

		if (Type == 4) {
			character->WingsSlot = 7356;
		}
		else {
			character->WingsSlot = Type + 7314;
		}
		break;
	case 2:
		Type = Equipment[8] & 0x07;
		switch (Type)
		{
		case 5:
			character->WingsSlot = 7857;
			break;
		case 6:
			character->WingsSlot = 7357;
			break;
		case 7:
			character->WingsSlot = 7364;
			break;
		default:
			character->WingsSlot = Type + 7317;
			break;
		}
		break;
	case 3:
		Type = Equipment[8] & 7;
		if (Type)
		{
			if (Type == 6) {
				character->WingsSlot = 7358;
			}
			else if (Type == 7) {
				character->WingsSlot = 7365;
			}
			else {
				character->WingsSlot = Type + 7350;
			}
		}
		else
		{
			Type = (Equipment[16] >> 5);

			character->WingsSlot = (Type) + 7444;
		}
		break;
	default:
		character->WingsSlot = -1;
		character->WingsExcellent = 0;
		character->WingsAncient = 0;
		break;
	}

	if (pHelper)
	{
		pHelper->Live = 0;
	}
	else
	{
		((void(*)(ObjectModel*))0x5012D0)(&character->Object);

		((void(__thiscall*)(void*, ObjectPreview*, int))0x009253D0)(((void* (*)())0x004DB230)(), character, character->PetSlot);
	}

	Type = Equipment[4] & 3;

	if (Type == 3)
	{
		if ((Equipment[9] & 1) == 1)
		{
			character->PetSlot = 7830;

			if (pHelper) {
				((void(*)(int, vec3_t, ObjectModel*, ObjectModel*, int))0x5013B0)(323, character->Object.Position, &character->Object, pHelper, 0);
			}
			else {
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(323, character->Object.Position, &character->Object, 0, 0);
			}
		}
		else
		{
			character->PetSlot = -1;
			character->PetExcellent = 0;
			character->PetAncient = 0;
		}
	}
	else
	{
		BYTE pet = Equipment[15] & 0xE0;

		if (pet != 32 && pet != 64 && pet != 128 && pet != 224 && pet != 160 && pet != 96)
		{
			character->PetSlot = Type + 7827;

			int HelperType = 0;
			int Create = 1;

			if (Type) {
				if (Type == 2) {
					HelperType = 233;
				}
				else if (Type == 3) {
					HelperType = 323;
				}
				else {
					Create = 0;
				}
			}
			else {
				HelperType = 7827;
			}

			if (Create == 1)
			{
				if (pHelper) {
					((void(*)(int, vec3_t, ObjectModel*, ObjectModel*, int))0x5013B0)(HelperType, character->Object.Position, &character->Object, pHelper, 0);
				}
				else {
					((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(HelperType, character->Object.Position, &character->Object, 0, 0);
				}
			}
		}
		else
		{
			int HelperType = 0;
			switch (pet)
			{
			case 0x20:
				HelperType = 64;
				break;
			case 0x40:
				HelperType = 65;
				break;
			case 0x60:
				HelperType = 123;
				break;
			case 0x80:
				HelperType = 67;
				break;
			case 0xA0:
				HelperType = 106;
				break;
			case 0xE0:
				HelperType = 80;
				break;
			default:
				break;
			}

			character->PetSlot = HelperType + 7827;

			((void(__thiscall*)(void*, int, int, vec3_t, ObjectPreview*, int, int))0x009250E0)(((void* (*)())0x004DB230)(), HelperType + 6656, character->PetSlot, character->Object.Position, character, 0, 0);
		}
	}

	if ((Equipment[11] & 1) == 1)
	{
		character->PetSlot = 7831;

		if (pHelper) {
			((void(*)(int, vec3_t, ObjectModel*, ObjectModel*, int))0x5013B0)(226, character->Object.Position, &character->Object, pHelper, 0);
		}
		else {
			((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(226, character->Object.Position, &character->Object, 0, 0);
		}
	}

	if ((Equipment[11] & 4) == 4)
	{
		character->PetSlot = 7864;
		BYTE Exc = Equipment[15] & 3;

		if (Equipment[16] & 1) {
			Exc = 4;
		}

		character->PetExcellent = Exc;

		switch (Exc)
		{
		case 1:
			if (pHelper) {
				((void(*)(int, vec3_t, ObjectModel*, ObjectModel*, int))0x5013B0)(384, character->Object.Position, &character->Object, pHelper, 0);
			}
			else {
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(384, character->Object.Position, &character->Object, 0, 0);
			}
			break;
		case 2:
			if (pHelper) {
				((void(*)(int, vec3_t, ObjectModel*, ObjectModel*, int))0x5013B0)(386, character->Object.Position, &character->Object, pHelper, 0);
			}
			else {
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(386, character->Object.Position, &character->Object, 0, 0);
			}
			break;
		case 4:
			if (pHelper) {
				((void(*)(int, vec3_t, ObjectModel*, ObjectModel*, int))0x5013B0)(387, character->Object.Position, &character->Object, pHelper, 0);
			}
			else {
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(387, character->Object.Position, &character->Object, 0, 0);
			}
			break;
		default:
			if (pHelper) {
				((void(*)(int, vec3_t, ObjectModel*, ObjectModel*, int))0x5013B0)(385, character->Object.Position, &character->Object, pHelper, 0);
			}
			else {
				((void(*)(int, vec3_t, ObjectModel*, int, int))0x501700)(385, character->Object.Position, &character->Object, 0, 0);
			}
			break;
		}
	}

	((void(*)(ObjectPreview*))0x4EFF70)(character);

	Type = (Equipment[11] >> 1) & 0x01;

	if (Type == 1) {
		if (character->EtcPart <= 0 || character->EtcPart > 3) {
			character->EtcPart = 4;
		}
	}
	else {
		if (character->EtcPart <= 0 || character->EtcPart > 3) {
			character->EtcPart = 0;
		}
	}

	int Level = Equipment[7] + (Equipment[6] << 8) + (Equipment[5] << 16);
	character->WeaponFirstLevel = ((BYTE(*)(BYTE))0x57FC30)(Equipment[7] & 7);
	character->WeaponSecondLevel = ((BYTE(*)(BYTE))0x57FC30)((Level >> 3) & 7);
	character->WingsLevel = 0;
	character->PetLevel = 0;

	if (!character->Change)
	{
		ExtType = 32 * (Equipment[12] & 0xF) + 16 * ((Equipment[8] >> 7) & 1) + (Equipment[2] >> 4);

		if (ExtType == 511) {
			character->BodyPart[BODYPART_HELM].Type = ((BYTE(*)(BYTE))0x587500)(character->Class) + 9389;
		}
		else {
			character->BodyPart[BODYPART_HELM].Type = ExtType + 4755;
		}

		ExtType = 32 * ((Equipment[13] >> 4) & 0xF) + 16 * ((Equipment[8] >> 6) & 1) + (Equipment[2] & 0xF);

		if (ExtType == 511) {
			character->BodyPart[BODYPART_ARMOR].Type = ((BYTE(*)(BYTE))0x587500)(character->Class) + 9413;
		}
		else {
			character->BodyPart[BODYPART_ARMOR].Type = ExtType + 5267;
		}

		ExtType = 32 * (Equipment[13] & 0xF) + 16 * ((Equipment[8] >> 5) & 1) + (Equipment[3] >> 4);

		if (ExtType == 511) {
			character->BodyPart[BODYPART_PANTS].Type = ((BYTE(*)(BYTE))0x587500)(character->Class) + 9437;
		}
		else {
			character->BodyPart[BODYPART_PANTS].Type = ExtType + 5779;
		}

		ExtType = 32 * ((Equipment[14] >> 4) & 0xF) + 16 * ((Equipment[8] >> 4) & 1) + (Equipment[3] & 0xF);

		if (ExtType == 511) {
			character->BodyPart[BODYPART_GLOVES].Type = ((BYTE(*)(BYTE))0x587500)(character->Class) + 9461;
		}
		else {
			character->BodyPart[BODYPART_GLOVES].Type = ExtType + 6291;
		}

		ExtType = 32 * (Equipment[14] & 0xF) + 16 * ((Equipment[8] >> 3) & 1) + (Equipment[4] >> 4);

		if (ExtType == 511) {
			character->BodyPart[BODYPART_BOOTS].Type = ((BYTE(*)(BYTE))0x587500)(character->Class) + 9485;
		}
		else {
			character->BodyPart[BODYPART_BOOTS].Type = ExtType + 6803;
		}

		character->BodyPart[BODYPART_HELM].Level = ((BYTE(*)(BYTE))0x57FC30)((Level >> 6) & 7);
		character->BodyPart[BODYPART_ARMOR].Level = ((BYTE(*)(BYTE))0x57FC30)((Level >> 9) & 7);
		character->BodyPart[BODYPART_PANTS].Level = ((BYTE(*)(BYTE))0x57FC30)((Level >> 12) & 7);
		character->BodyPart[BODYPART_GLOVES].Level = ((BYTE(*)(BYTE))0x57FC30)((Level >> 15) & 7);
		character->BodyPart[BODYPART_BOOTS].Level = ((BYTE(*)(BYTE))0x57FC30)((Level >> 18) & 7);
		character->BodyPart[BODYPART_HELM].Option1 = (Equipment[9] & 0x80) >> 7;
		character->BodyPart[BODYPART_ARMOR].Option1 = (Equipment[9] & 0x40) >> 6;
		character->BodyPart[BODYPART_PANTS].Option1 = (Equipment[9] & 0x20) >> 5;
		character->BodyPart[BODYPART_GLOVES].Option1 = (Equipment[9] & 0x10) >> 4;
		character->BodyPart[BODYPART_BOOTS].Option1 = (Equipment[9] & 8) >> 3;
		character->BodyPart[BODYPART_HELM].ExtOption = (Equipment[10] & 0x80) >> 7;
		character->BodyPart[BODYPART_ARMOR].ExtOption = (Equipment[10] & 0x40) >> 6;
		character->BodyPart[BODYPART_PANTS].ExtOption = (Equipment[10] & 0x20) >> 5;
		character->BodyPart[BODYPART_GLOVES].ExtOption = (Equipment[10] & 0x10) >> 4;
		character->BodyPart[BODYPART_BOOTS].ExtOption = (Equipment[10] & 8) >> 3;
		character->WeaponFirstExcellent = (Equipment[9] & 4) >> 2;
		character->WeaponSecondExcellent = (Equipment[9] & 2) / 2;
		character->WeaponFirstAncient = (Equipment[10] & 4) >> 2;
		character->WeaponSecondAncient = (Equipment[10] & 2) / 2;
		character->ExtState = Equipment[10] & 1;

		((void(*)(ObjectPreview*))0x4E6670)(character);
		((void(*)(ObjectPreview*))0x57F020)(character);
	}

	gHelperManager.DeleteHelper(character);
	gElementPetFirst.DeleteHelper(character);
	gElementPetSecond.DeleteHelper(character);

	if (*(DWORD*)MAIN_SCREEN_STATE == 4) {
		auto lpCharList = gCustomPreview.GetCustomPreviewCharList(character->Name);

		if (lpCharList != 0) {
			if (lpCharList->WingIndex > 0) {
				if (gCustomWing.CheckCustomWingByItem(GET_ITEM(12, lpCharList->WingIndex)))
				{
					character->WingsSlot = GET_ITEM_MODEL(12, lpCharList->WingIndex);
				}
			}

			if (lpCharList->PetIndex > 0) {
				if (pHelper) {
					pHelper->Live = 0;
				}
				else {
					((void(*)(ObjectModel*))0x5012D0)(&character->Object);

					((void(__thiscall*)(void*, ObjectPreview*, int))0x009253D0)(((void* (*)())0x004DB230)(), character, -1);
				}

				if (gHelperSystem.CheckIsHelper(GET_ITEM_MODEL(13, lpCharList->PetIndex))) {
					character->PetSlot = GET_ITEM_MODEL(13, lpCharList->PetIndex);

					gHelperManager.CreateHelper(GET_ITEM(13, lpCharList->PetIndex), gHelperSystem.GetHelperModel(character->PetSlot), character->Object.Position, character, 0);
				}
			}
		}
	}
	else {
		auto lpList = gCustomPreview.GetCustomPreviewList(character->aIndex);

		if (lpList != 0) {
			if (lpList->WingIndex > 0) {
				if (gCustomWing.CheckCustomWingByItem(GET_ITEM(12, lpList->WingIndex)))
				{
					character->WingsSlot = GET_ITEM_MODEL(12, lpList->WingIndex);
				}
			}

			if (lpList->PetIndex > 0) {
				if (pHelper) {
					pHelper->Live = 0;
				}
				else {
					((void(*)(ObjectModel*))0x5012D0)(&character->Object);

					((void(__thiscall*)(void*, ObjectPreview*, int))0x009253D0)(((void* (*)())0x004DB230)(), character, -1);
				}

				if (gHelperSystem.CheckIsHelper(GET_ITEM_MODEL(13, lpList->PetIndex))) {
					character->PetSlot = GET_ITEM_MODEL(13, lpList->PetIndex);

					gHelperManager.CreateHelper(GET_ITEM(13, lpList->PetIndex), gHelperSystem.GetHelperModel(character->PetSlot), character->Object.Position, character, 0);
				}
			}

			if (lpList->Element[0] > 0) {
				if (gDarkSpirit.checkIsDarkSpirit(lpList->Element[0])) {
					auto backupWeapon = character->WeaponSecondSlot;

					character->WeaponSecondSlot = lpList->Element[0] + 1171;

					DWORD PetInfo = ((DWORD(*)(DWORD))0x4F9930)((DWORD)*(WORD*)(*(DWORD*)0x8128AC4 + 4779));

					((void(*)(ObjectPreview*))0x4F8B80)(character);

					if (!((bool(*)(int))0x4E65A0)(pMapNumber)) {
						((void(__thiscall*)(DWORD*, DWORD))0x4FA780)((DWORD*)character->m_pPet, PetInfo);
					}

					gDarkSpirit.CreateDarkSpirit(character, character->WeaponSecondSlot);

					character->WeaponSecondSlot = backupWeapon;
				}
				else if (gHelperSystem.CheckIsHelper(lpList->Element[0] + ITEM_BASE_MODEL)) {
					gElementPetFirst.CreateHelper(lpList->Element[0], gHelperSystem.GetHelperModel(lpList->Element[0] + ITEM_BASE_MODEL), character->Object.Position, character, 0);
				}
			}

			if (lpList->Element[1] > 0) {
				if (gHelperSystem.CheckIsHelper(lpList->Element[1] + ITEM_BASE_MODEL)) {
					gElementPetSecond.CreateHelper(lpList->Element[1], gHelperSystem.GetHelperModel(lpList->Element[1] + ITEM_BASE_MODEL), character->Object.Position, character, 0);
				}
			}
		}
	}
}

void CMakePreview::ReceiveChangePlayer(PMSG_ITEM_CHANGE_RECV * lpMsg)
{
	ObjectPreview* c = &*(ObjectPreview*)((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), ((int(*)(int))0x57D9A0)(lpMsg->index[1] + (lpMsg->index[0] << 8)));

	if (c) {
		int Type = ((int(*)(BYTE*))0x58AA80)(lpMsg->ItemInfo);
		BYTE Level = lpMsg->ItemInfo[1] & 0xF;
		BYTE Option = lpMsg->ItemInfo[3] & 0x3F;
		BYTE ExtOption = lpMsg->ItemInfo[4];

		if (lpMsg->ElementSlot == 236) {
			if (Type == 0x1FFF) {
				gElementPetFirst.DeleteHelper(c);

				if (gDarkSpirit.CheckExistDarkSpirit(c)) {
					((void(*)(ObjectPreview*))0x4F94A0)(c);
					gDarkSpirit.DeleteDarkSpirit(Hero, -1, false);
				}
			}
			else {
				if (gElementPetFirst.CheckExistsHelper(c)) {
					gElementPetFirst.DeleteHelper(c);
				}

				if (gDarkSpirit.CheckExistDarkSpirit(c)) {
					((void(*)(ObjectPreview*))0x4F94A0)(c);
				}

				if (gDarkSpirit.checkIsDarkSpirit(Type)) {
					auto backupWeapon = c->WeaponSecondSlot;

					c->WeaponSecondSlot = Type + 1171;

					DWORD PetInfo = ((DWORD(*)(DWORD))0x4F9930)((DWORD)*(WORD*)(*(DWORD*)0x8128AC4 + 4779));

					((void(*)(ObjectPreview*))0x4F8B80)(c);

					if (!((bool(*)(int))0x4E65A0)(pMapNumber)) {
						((void(__thiscall*)(DWORD*, DWORD))0x4FA780)((DWORD*)c->m_pPet, PetInfo);
					}

					gDarkSpirit.CreateDarkSpirit(c, c->WeaponSecondSlot);

					c->WeaponSecondSlot = backupWeapon;
				}
				else if (gHelperSystem.CheckIsHelper(Type + ITEM_BASE_MODEL)) {
					gElementPetFirst.CreateHelper(Type, gHelperSystem.GetHelperModel(Type + ITEM_BASE_MODEL), c->Object.Position, c, 0);
				}
			}
		}
		else if (lpMsg->ElementSlot == 237) {
			if (Type == 0x1FFF) {
				gElementPetSecond.DeleteHelper(c);
			}
			else {
				if (gHelperSystem.CheckIsHelper(Type + ITEM_BASE_MODEL)) {
					if (gElementPetSecond.CheckExistsHelper(c)) {
						gElementPetSecond.DeleteHelper(c);
					}

					gElementPetSecond.CreateHelper(Type, gHelperSystem.GetHelperModel(Type + ITEM_BASE_MODEL), c->Object.Position, c, 0);
				}
			}
		}

		switch (lpMsg->ItemInfo[1] >> 4)
		{
		case 0:
			if (Type == 0x1FFF)
			{
				c->WeaponFirstSlot = -1;
				c->WeaponFirstExcellent = 0;
			}
			else
			{
				c->WeaponFirstSlot = Type + 1171;
				c->WeaponFirstLevel = ((BYTE(*)(BYTE))0x57FC30)(Level);
				c->WeaponFirstExcellent = Option;
			}
			break;
		case 1:
			if (Type == 0x1FFF)
			{
				// FIX SECOND WEAPON
				c->WeaponSecondSlot = -1;
				c->WeaponSecondExcellent = 0;
				//((void(*)(ObjectPreview*))0x4F94A0)(c);
			}
			else
			{
				c->WeaponSecondSlot = Type + 1171;
				c->WeaponSecondLevel = ((BYTE(*)(BYTE))0x57FC30)(Level);
				c->WeaponSecondExcellent = Option;

				//((void(*)(ObjectPreview*))0x4F8C30)(c);
				//((void(*)(ObjectPreview*))0x534B40)(c);
			}
			break;
		case 2:
			if (Type == 0x1FFF)
			{
				c->BodyPart[BODYPART_HELM].Type = ((BYTE(*)(BYTE))0x587500)(c->Class) + 9389;
				c->BodyPart[BODYPART_HELM].Level = 0;
				c->BodyPart[BODYPART_HELM].Option1 = 0;
				c->BodyPart[BODYPART_HELM].ExtOption = 0;
			}
			else
			{
				c->BodyPart[BODYPART_HELM].Type = Type + 1171;
				c->BodyPart[BODYPART_HELM].Level = ((BYTE(*)(BYTE))0x57FC30)(Level);
				c->BodyPart[BODYPART_HELM].Option1 = Option;
				c->BodyPart[BODYPART_HELM].ExtOption = ExtOption;
			}
			break;
		case 3:
			if (Type == 0x1FFF)
			{
				c->BodyPart[BODYPART_ARMOR].Type = ((BYTE(*)(BYTE))0x587500)(c->Class) + 9413;
				c->BodyPart[BODYPART_ARMOR].Level = 0;
				c->BodyPart[BODYPART_ARMOR].Option1 = 0;
				c->BodyPart[BODYPART_ARMOR].ExtOption = 0;
			}
			else
			{
				c->BodyPart[BODYPART_ARMOR].Type = Type + 1171;
				c->BodyPart[BODYPART_ARMOR].Level = ((BYTE(*)(BYTE))0x57FC30)(Level);
				c->BodyPart[BODYPART_ARMOR].Option1 = Option;
				c->BodyPart[BODYPART_ARMOR].ExtOption = ExtOption;
			}
			break;
		case 4:
			if (Type == 0x1FFF)
			{
				c->BodyPart[BODYPART_PANTS].Type = ((BYTE(*)(BYTE))0x587500)(c->Class) + 9437;
				c->BodyPart[BODYPART_PANTS].Level = 0;
				c->BodyPart[BODYPART_PANTS].Option1 = 0;
				c->BodyPart[BODYPART_PANTS].ExtOption = 0;
			}
			else
			{
				c->BodyPart[BODYPART_PANTS].Type = Type + 1171;
				c->BodyPart[BODYPART_PANTS].Level = ((BYTE(*)(BYTE))0x57FC30)(Level);
				c->BodyPart[BODYPART_PANTS].Option1 = Option;
				c->BodyPart[BODYPART_PANTS].ExtOption = ExtOption;
			}
			break;
		case 5:
			if (Type == 0x1FFF)
			{
				c->BodyPart[BODYPART_GLOVES].Type = ((BYTE(*)(BYTE))0x587500)(c->Class) + 9461;
				c->BodyPart[BODYPART_GLOVES].Level = 0;
				c->BodyPart[BODYPART_GLOVES].Option1 = 0;
				c->BodyPart[BODYPART_GLOVES].ExtOption = 0;
			}
			else
			{
				c->BodyPart[BODYPART_GLOVES].Type = Type + 1171;
				c->BodyPart[BODYPART_GLOVES].Level = ((BYTE(*)(BYTE))0x57FC30)(Level);
				c->BodyPart[BODYPART_GLOVES].Option1 = Option;
				c->BodyPart[BODYPART_GLOVES].ExtOption = ExtOption;
			}
			break;
		case 6:
			if (Type == 0x1FFF)
			{
				c->BodyPart[BODYPART_BOOTS].Type = ((BYTE(*)(BYTE))0x587500)(c->Class) + 9485;
				c->BodyPart[BODYPART_BOOTS].Level = 0;
				c->BodyPart[BODYPART_BOOTS].Option1 = 0;
				c->BodyPart[BODYPART_BOOTS].ExtOption = 0;
			}
			else
			{
				c->BodyPart[BODYPART_BOOTS].Type = Type + 1171;
				c->BodyPart[BODYPART_BOOTS].Level = ((BYTE(*)(BYTE))0x57FC30)(Level);
				c->BodyPart[BODYPART_BOOTS].Option1 = Option;
				c->BodyPart[BODYPART_BOOTS].ExtOption = ExtOption;
			}
			break;
		case 7:
			if (Type == 0x1FFF)
			{
				if (c->WingsSlot == 7354
					|| c->WingsSlot == 7857
					|| c->WingsSlot == 7445
					|| c->WingsSlot == 7364
					|| c->WingsSlot == 7365
					|| c->WingsSlot == 7450
					|| c->WingsSlot == 7355
					|| gCustomWing.CheckCustomWingIsCape(c->WingsSlot))
				{
					((void(*)(ObjectPreview*, ObjectModel*, int))0x558630)(c, &c->Object, 0);
				}

				c->WingsSlot = -1;
			}
			else
			{
				c->WingsSlot = Type + 1171;

				c->WingsLevel = 0;

				if (c->WingsSlot == 7354
					|| c->WingsSlot == 7857
					|| c->WingsSlot == 7445
					|| c->WingsSlot == 7364
					|| c->WingsSlot == 7365
					|| c->WingsSlot == 7450
					|| c->WingsSlot == 7355
					|| gCustomWing.CheckCustomWingIsCape(c->WingsSlot))
				{
					((void(*)(ObjectPreview*, ObjectModel*, int))0x558630)(c, &c->Object, 0);
				}
			}
			break;
		case 8:
			if (Type == 0x1FFF)
			{
				c->PetSlot = -1;

				((void(*)(ObjectModel*))0x5012D0)(&c->Object);

				((void(__thiscall*)(void*, ObjectPreview*, int))0x009253D0)(((void* (*)())0x004DB230)(), c, -1);

				// BUG VISUAL MONTARIAS  FALTAVA ELA AQUI
				gHelperManager.DeleteHelper(c);
			}
			else if (gHelperSystem.CheckIsHelper(Type + ITEM_BASE_MODEL)) {
				((void(*)(ObjectModel*))0x5012D0)(&c->Object);

				// BUG VISUAL MONTARIAS 
				gHelperManager.DeleteHelper(c);

				((void(__thiscall*)(void*, ObjectPreview*, int))0x009253D0)(((void* (*)())0x004DB230)(), c, -1);

				c->PetSlot = Type + ITEM_BASE_MODEL;

				gHelperManager.CreateHelper(Type, gHelperSystem.GetHelperModel(c->PetSlot), c->Object.Position, c, 0);
			}
			else
			{
				gHelperManager.DeleteHelper(c);

				c->PetSlot = Type + 1171;
				c->PetLevel = 0;

				switch (Type)
				{
				case 6656:
					((void(*)(int, vec3_t, ObjectModel *, int, int))0x501700)(7827, c->Object.Position, &c->Object, 0, 0);
					break;
				case 6658:
					((void(*)(int, vec3_t, ObjectModel *, int, int))0x501700)(233, c->Object.Position, &c->Object, 0, 0);
					break;
				case 6659:
					((void(*)(int, vec3_t, ObjectModel *, int, int))0x501700)(323, c->Object.Position, &c->Object, 0, 0);
					break;
				case 6660:
					((void(*)(int, vec3_t, ObjectModel *, int, int))0x501700)(226, c->Object.Position, &c->Object, 0, 0);
					break;
				case 6693:
					c->PetExcellent = Option;

					switch (Option)
					{
					case 1:
						((void(*)(int, vec3_t, ObjectModel *, int, int))0x501700)(384, c->Object.Position, &c->Object, 0, 0);
						break;
					case 2:
						((void(*)(int, vec3_t, ObjectModel *, int, int))0x501700)(386, c->Object.Position, &c->Object, 0, 0);
						break;
					case 4:
						((void(*)(int, vec3_t, ObjectModel *, int, int))0x501700)(387, c->Object.Position, &c->Object, 0, 0);
						break;
					default:
						((void(*)(int, vec3_t, ObjectModel *, int, int))0x501700)(385, c->Object.Position, &c->Object, 0, 0);
						break;
					}
					break;
				case 6720:
				case 6721:
					((void(__thiscall*)(void*, int, int, vec3_t, ObjectPreview*, int, int))0x009250E0)(((void* (*)())0x004DB230)(), Type, c->PetSlot, c->Object.Position, c, 0, 0);
					break;
				case 6723:
				case 6736:
				case 6762:
				case 6779:
					((void(__thiscall*)(void*, int, int, vec3_t, ObjectPreview*, int, int))0x009250E0)(((void* (*)())0x004DB230)(), Type, c->PetSlot, c->Object.Position, c, 0, 0);
					break;
				default:
					break;
				}
			}
			break;
		default:
			break;
		}

		((void(*)(ObjectPreview*))0x4E6670)(c);
		((void(*)(ObjectPreview*))0x57F020)(c);
	}
}

void CMakePreview::SetChangeClass(ObjectPreview * pCharacter)
{
	if (pCharacter->Object.Type == 1163)
	{
		bool stop = 1;

		if (pCharacter->Object.CurrentAction >= 233 && pCharacter->Object.CurrentAction <= 240) {
			stop = 0;
		}
		if (pCharacter->Object.CurrentAction >= 38 && pCharacter->Object.CurrentAction <= 155) {
			stop = 0;
		}

		if (stop) {
			((void(*)(ObjectPreview*))0x54EA80)(pCharacter);
		}

		int skin = ((BYTE(*)(BYTE))0x587500)(pCharacter->Class);

		if (pCharacter->BodyPart[BODYPART_HELM].Type >= 9389)
		{
			pCharacter->BodyPart[BODYPART_HELM].Type = skin + 9389;
			pCharacter->BodyPart[BODYPART_HELM].Level = 0;
			pCharacter->BodyPart[BODYPART_HELM].Option1 = 0;
			pCharacter->BodyPart[BODYPART_HELM].ExtOption = 0;
		}
		if (pCharacter->BodyPart[BODYPART_ARMOR].Type >= 9413)
		{
			pCharacter->BodyPart[BODYPART_ARMOR].Type = skin + 9413;
			pCharacter->BodyPart[BODYPART_ARMOR].Level = 0;
			pCharacter->BodyPart[BODYPART_ARMOR].Option1 = 0;
			pCharacter->BodyPart[BODYPART_ARMOR].ExtOption = 0;
		}
		if (pCharacter->BodyPart[BODYPART_PANTS].Type >= 9437)
		{
			pCharacter->BodyPart[BODYPART_PANTS].Type = skin + 9437;
			pCharacter->BodyPart[BODYPART_PANTS].Level = 0;
			pCharacter->BodyPart[BODYPART_PANTS].Option1 = 0;
			pCharacter->BodyPart[BODYPART_PANTS].ExtOption = 0;
		}
		if (pCharacter->BodyPart[BODYPART_GLOVES].Type >= 9461)
		{
			pCharacter->BodyPart[BODYPART_GLOVES].Type = skin + 9461;
			pCharacter->BodyPart[BODYPART_GLOVES].Level = 0;
			pCharacter->BodyPart[BODYPART_GLOVES].Option1 = 0;
			pCharacter->BodyPart[BODYPART_GLOVES].ExtOption = 0;
		}
		if (pCharacter->BodyPart[BODYPART_BOOTS].Type >= 9485)
		{
			pCharacter->BodyPart[BODYPART_BOOTS].Type = skin + 9485;
			pCharacter->BodyPart[BODYPART_BOOTS].Level = 0;
			pCharacter->BodyPart[BODYPART_BOOTS].Option1 = 0;
			pCharacter->BodyPart[BODYPART_BOOTS].ExtOption = 0;
		}
		((void(*)(ObjectPreview*))0x57F020)(pCharacter);
	}
}
