#include "stdafx.h"
#include "Lua.h"
#include "Util.h"
#include "LuaMemory.h"
#include "LuaStack.hpp"

using namespace luaaa;

LuaMemory::LuaMemory()
{

}

LuaMemory::~LuaMemory()
{

}

int MemoryGetByte(DWORD offset) {
	return *(BYTE*)(offset);
}

void MemorySetByte(DWORD offset, int value) {
	SetByte(offset, (BYTE)value);
}

DWORD MemoryGetDword(DWORD offset) {
	return *(DWORD*)(offset);
}

void MemorySetDword(DWORD offset, DWORD value) {
	SetDword(offset, value);
}

float MemoryGetFloat(DWORD offset) {
	return *(float*)(offset);
}

void MemorySetFloat(DWORD offset, float value) {
	SetFloat(offset, value);
}

void MemorySetOffset(DWORD offset, DWORD value, DWORD size) {
	MemorySet(offset, value, size);
}

void LuaMemory::RegisterLua(lua_State* lua)
{
	LuaModule(lua).fun("MemoryGetByte", &MemoryGetByte);
	LuaModule(lua).fun("MemorySetByte", &MemorySetByte);

	LuaModule(lua).fun("MemoryGetDword", &MemoryGetDword);
	LuaModule(lua).fun("MemorySetDword", &MemorySetDword);

	LuaModule(lua).fun("MemoryGetFloat", &MemoryGetFloat);
	LuaModule(lua).fun("MemorySetFloat", &MemorySetFloat);

	LuaModule(lua).fun("MemorySet", &MemorySetOffset);
}
