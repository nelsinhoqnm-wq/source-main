#include "stdafx.h"
#include "CharacterLevel.h"
#include "Util.h"
#include "LoadFiles.h"

CCharacterLevel gCharacterLevel;

CCharacterLevel::CCharacterLevel()
{
}

CCharacterLevel::~CCharacterLevel()
{
}

__declspec(naked) void SetLevelWhenMaxLevel() {
	static DWORD m_HookMasterLevel = 0x0081072B	;
	static DWORD m_HookLevel = 0x0081075D;

	if (((bool(*)(DWORD))0x5878E0)(*(BYTE *)(*(DWORD*)0x8128AC8 + 11)) && *(WORD*)(*(DWORD*)0x8128AC8 + 14) >= gLoadFiles.m_LoadFiles.MaxLevel) {
		_asm {
			JMP[m_HookMasterLevel];
		}
	}
	else {
		_asm {
			JMP[m_HookLevel];
		}
	}
}

__declspec(naked) void SetRenderLevelMaxLevel() {
	static DWORD m_HookMasterLevel = 0x008107AF;
	static DWORD m_HookLevel = 0x00810FF4;

	if (((bool(*)(DWORD))0x5878E0)(*(BYTE *)(*(DWORD*)0x8128AC8 + 11)) && *(WORD*)(*(DWORD*)0x8128AC8 + 14) >= gLoadFiles.m_LoadFiles.MaxLevel) {
		_asm {
			JMP[m_HookMasterLevel];
		}
	}
	else {
		_asm {
			JMP[m_HookLevel];
		}
	}
}

__declspec(naked) void SetMaxLevelCharacter() {
	static DWORD m_ReturnFunc = 0x00811027;
	static DWORD m_Level = 0x0;

	_asm {
		MOV WORD PTR SS : [EBP - 0x1AC], DX;
		MOVZX ECX, WORD PTR SS : [EBP - 0x1AC];
		MOV m_Level, ECX;
	}

	if (m_Level >= 400) {
		static DWORD m_SetLevel = 399;

		_asm {
			MOV EDX, m_SetLevel;
			MOV WORD PTR SS : [EBP - 0x1AC], DX;
		}
	}

	_asm {
		JMP[m_ReturnFunc];
	}
}

void CCharacterLevel::Init()
{
	SetCompleteHook(0xE9, 0x00810711, &SetLevelWhenMaxLevel);

	SetCompleteHook(0xE9, 0x00810790, &SetRenderLevelMaxLevel);

	MemorySet(0x00811020, 0x90, 7);
	SetCompleteHook(0xE9, 0x00811020, &SetMaxLevelCharacter);
}
