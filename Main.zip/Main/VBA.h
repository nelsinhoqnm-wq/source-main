#pragma once

inline void _glTexCoord2f(GLfloat s, GLfloat t);
inline void _glColor3f(GLfloat red, GLfloat green, GLfloat blue);
inline void _glColor3fv(const GLfloat* v);
inline void _glColor4f(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
inline void _glVertex3f(GLfloat x, GLfloat y, GLfloat z);
inline void _glVertex3fv(const GLfloat* v);
inline void _glBegin(GLenum mode);
inline void _glEnd(void);

#define __glTexCoord2f(s, t) \
	*textures++ = s; \
	*textures++ = t;

#define __glColor3f(red, green, blue) \
	*colors++ = red; \
	*colors++ = green; \
	*colors++ = blue; \
	*colors++ = 1.0f;

#define __glColor3fv(v) \
	*colors++ = v[0]; \
	*colors++ = v[1]; \
	*colors++ = v[2]; \
	*colors++ = 1.0f;

#define __glColor4f(red, green, blue, alpha) \
	*colors++ = red; \
	*colors++ = green; \
	*colors++ = blue; \
	*colors++ = alpha;

#define __glVertex3f(x, y, z) \
	*vertices++ = x; \
	*vertices++ = y; \
	*vertices++ = z;

#define __glVertex3fv(v) \
	*vertices++ = v[0]; \
	*vertices++ = v[1]; \
	*vertices++ = v[2];

void _CreateOpenglWindow();
void InitVBA();