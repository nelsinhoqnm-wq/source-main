#include "stdafx.h"
#include "PersonalShop.h"
#include "Util.h"
#include "LoadFiles.h"
#include "PrintPlayer.h"
#include "CustomMessage.h"
#include "Descriptions.h"

CPersonalShop gPersonalShop;

CPersonalShop::CPersonalShop()
{
	this->WindowValueVisible = 0;

	this->m_x = (640 / 2) - (230 / 2);

	this->m_y = 100;

	this->m_width = 230;

	this->m_height = 220;

	this->m_PersonalShopInfo.clear();

	this->m_PersonalShopInfoTarget.clear();

	this->m_TextInput.clear();

	this->m_TextInput2.clear();

	this->m_TextInput3.clear();

	this->m_TextInput4.clear();

	this->m_Input01Open = 0;

	this->m_Input02Open = 0;

	this->m_Input03Open = 0;

	this->m_Input04Open = 0;
}

CPersonalShop::~CPersonalShop()
{

}

void SetVisibleChangeValue() {
	gPersonalShop.WindowValueVisible = true;
	gPersonalShop.m_EventKey = 0;
	gPersonalShop.m_EventKey2 = 0;

	gPersonalShop.m_TextInput.clear();

	gPersonalShop.m_TextInput2.clear();

	gPersonalShop.m_TextInput3.clear();

	gPersonalShop.m_TextInput4.clear();

	gPersonalShop.m_Input01Open = 0;

	gPersonalShop.m_Input02Open = 0;

	gPersonalShop.m_Input03Open = 0;

	gPersonalShop.m_Input04Open = 0;
}

__declspec(naked) void CPersonalShopItemValueMsgBoxLayout() {
	static DWORD m_HookExit = 0x005D59BE;

	_asm {
		MOV EAX, DWORD PTR FS : [0x0] ;
		CALL[SetVisibleChangeValue];
		ADD ESP, 0x04;
		JMP[m_HookExit];
	}
}

BOOL PersonalShopItemValueOpened() {
	if (gPersonalShop.WindowValueVisible) {
		gPersonalShop.RenderWindowChangeValue();
		return 1;
	}

	return 0;
}

__declspec(naked) void RenderMessageBox() {
	static DWORD m_HookFunc = 0x0082495E;
	static DWORD m_ExitFunc = 0x008249DE;

	static DWORD m_OldEax = 0;
	static DWORD m_OldEcx = 0;
	static DWORD m_OldEbx = 0;

	_asm {
		MOV m_OldEax, EAX;
		MOV m_OldEcx, ECX;
		MOV m_OldEbx, EBX;
		Call[PersonalShopItemValueOpened];
		Test Eax, Eax;
		Je EXIT;

		MOV AL, 0
			JMP[m_ExitFunc];

	EXIT:
		MOV EAX, m_OldEax;
		MOV ECX, m_OldEcx;
		MOV EBX, m_OldEbx;
		MOV DWORD PTR SS : [EBP - 0x24] , ECX
			PUSH 0x00824AA0;
		JMP[m_HookFunc];
	}
}

BOOL PersonalShopUpdateMouse() {
	if (gPersonalShop.WindowValueVisible) {
		return gPersonalShop.UpdateMouseChangeValue();
	}

	return 0;
}

__declspec(naked) void UpdateMouseMessageBox() {
	static DWORD m_HookFunc = 0x00824391;
	static DWORD m_OldEax = 0x0;
	static DWORD m_ExitFunc = 0x00824701;

	_asm {
		MOV m_OldEax, EAX;
		Call[PersonalShopUpdateMouse];
		Test Eax, Eax;
		Je EXIT;

		MOV AL, 0;
		JMP[m_ExitFunc];

	EXIT:
		MOV EAX, m_OldEax;
		PUSH 0x00824AA0;
		LEA EAX, DWORD PTR SS : [EBP - 0x14] ;
		JMP[m_HookFunc];
	}
}

BOOL PersonalShopUpdate() {
	if (gPersonalShop.WindowValueVisible) {
		return gPersonalShop.UpdateChangeValue();
	}

	return 0;
}

__declspec(naked) void UpdateMessageBox() {
	static DWORD m_HookFunc = 0x00824801;
	static DWORD m_OldEax = 0x0;
	static DWORD m_ExitFunc = 0x00824941;

	_asm {
		MOV m_OldEax, EAX;
		Call[PersonalShopUpdate];
		Test Eax, Eax;
		Je EXIT;

		MOV AL, 0;
		JMP[m_ExitFunc];

	EXIT:
		MOV EAX, m_OldEax;
		PUSH 0x00824AA0;
		LEA EAX, DWORD PTR SS : [EBP - 0x24] ;
		JMP[m_HookFunc];
	}
}

BOOL PersonalShopUpdateKey() {
	if (gPersonalShop.WindowValueVisible) {
		return gPersonalShop.UpdateChangeValue();
	}

	return 0;
}

__declspec(naked) void UpdateKeyMessageBox() {
	static DWORD m_HookFunc = 0x00824721;
	static DWORD m_OldEax = 0x0;
	static DWORD m_ExitFunc = 0x008247EA;

	_asm {
		MOV m_OldEax, EAX;
		Call[PersonalShopUpdateKey];
		Test Eax, Eax;
		Je EXIT;

		MOV AL, 0;
		JMP[m_ExitFunc];

	EXIT:
		MOV EAX, m_OldEax;
		PUSH 0x00824AA0;
		LEA EAX, DWORD PTR SS : [EBP - 0x14] ;
		JMP[m_HookFunc];
	}
}

int CheckPersonalShopValue(DWORD Line, DWORD itemObject) {
	auto itemObj = &*(ITEM*)itemObject;

	if (itemObj) {
		PERSONAL_SHOP_ITENS_VALUE* itemInfo = nullptr;

		if (CheckWindowOpen(ObjWindow::OtherStore)) {
			itemInfo = gPersonalShop.getItemTarget(itemObj->x + 8 * itemObj->y + 204);
		}
		else {
			itemInfo = gPersonalShop.getItem(itemObj->x + 8 * itemObj->y + 204);
		}

		if (itemInfo) {
			char buffer[100];

			if (gLoadFiles.m_LoadFiles.m_Coin1Switch) {
				sprintf_s(buffer, gCustomMessage.GetMessage(41), itemInfo->Coin1);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (gLoadFiles.m_LoadFiles.m_Coin2Switch) {
				sprintf_s(buffer, gCustomMessage.GetMessage(42), itemInfo->Coin2);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (gLoadFiles.m_LoadFiles.m_Coin3Switch) {
				sprintf_s(buffer, gCustomMessage.GetMessage(43), itemInfo->Coin3);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (gLoadFiles.m_LoadFiles.m_Coin4Switch) {
				sprintf_s(buffer, gCustomMessage.GetMessage(44), itemInfo->Coin4);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			memcpy(textLine[Line], "\n", 100);
			textColor[Line] = 6;
			textBold[Line] = 1;
			Line++;
		}
	}

	return Line;
}

__declspec(naked) void UpdateDescriptionPersonalShop() {
	static DWORD m_ExitFunc = 0x007E4811;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x10] ;
		PUSH ECX;
		MOV EAX, DWORD PTR SS : [EBP - 0x74] ;
		PUSH EAX;
		CALL[CheckPersonalShopValue];
		MOV DWORD PTR SS : [EBP - 0x74] , EAX;
		MOV ECX, DWORD PTR SS : [EBP - 0x68] ;
		ADD ECX, 1;
		MOV DWORD PTR SS : [EBP - 0x68] , ECX;
		JMP[m_ExitFunc];
	}
}

PERSONAL_SHOP_ITENS_VALUE* CPersonalShop::getItem(int slot)
{
	std::map<int, PERSONAL_SHOP_ITENS_VALUE>::iterator it = this->m_PersonalShopInfo.find(slot);

	if (it == this->m_PersonalShopInfo.end()) {
		return 0;
	}

	return &it->second;
}

PERSONAL_SHOP_ITENS_VALUE* CPersonalShop::getItemTarget(int slot)
{
	std::map<int, PERSONAL_SHOP_ITENS_VALUE>::iterator it = this->m_PersonalShopInfoTarget.find(slot);

	if (it == this->m_PersonalShopInfoTarget.end()) {
		return 0;
	}

	return &it->second;
}

__declspec(naked) void FixStoreName()
{
	static DWORD addrJmp = NULL;

	static DWORD addrCall0 = 0x00412D50;
	static DWORD addrCall1 = 0x00402880;
	static DWORD addrCall2 = 0x00409B10;
	static DWORD ilength = 0;

	_asm
	{
		mov     ecx, dword ptr ss : [ebp + 0x8]
		call[addrCall0]
		mov     ilength, eax
	}

	if (ilength > 16)
	{
		addrJmp = 0x0041023B;

		_asm
		{
			jmp[addrJmp]
		}
	}
	else
	{
		addrJmp = 0x00410261;

		_asm
		{
			mov     ecx, dword ptr ss : [ebp + 0x8]
			call[addrCall1]
			push    eax
			mov     ecx, dword ptr ss : [ebp + 0xC]
			call[addrCall2]
			jmp[addrJmp]
		}
	}
}

void CPersonalShop::Init()
{
	SetCompleteHook(0xE9, 0x00410233, &FixStoreName);

	SetCompleteHook(0xE9, 0x005D595A, &CPersonalShopItemValueMsgBoxLayout);

	SetCompleteHook(0xE9, 0x00824959, &RenderMessageBox);

	SetCompleteHook(0xE9, 0x00824389, &UpdateMouseMessageBox);

	SetCompleteHook(0xE9, 0x008247F9, &UpdateMessageBox);

	SetCompleteHook(0xE9, 0x00824719, &UpdateKeyMessageBox);

	SetCompleteHook(0xE9, 0x007E4603, &UpdateDescriptionPersonalShop);
}

void CPersonalShop::InsertItemValue(int ItemIndex, BYTE slot, int Coin1, int Coin2, int Coin3, int Coin4)
{
	std::map<int, PERSONAL_SHOP_ITENS_VALUE>::iterator it = this->m_PersonalShopInfo.find(slot);

	if (it == this->m_PersonalShopInfo.end()) {
		PERSONAL_SHOP_ITENS_VALUE info;

		info.slot = slot;

		info.ItemIndex = ItemIndex;

		info.Coin1 = Coin1;

		info.Coin2 = Coin2;

		info.Coin3 = Coin3;

		info.Coin4 = Coin4;

		this->m_PersonalShopInfo.insert(std::make_pair(info.slot, info));
		return;
	}

	it->second.slot = slot;

	it->second.ItemIndex = ItemIndex;

	it->second.Coin1 = Coin1;

	it->second.Coin2 = Coin2;

	it->second.Coin3 = Coin3;

	it->second.Coin4 = Coin4;
}

void CPersonalShop::InsertItemValueTarget(int ItemIndex, BYTE slot, int Coin1, int Coin2, int Coin3, int Coin4)
{
	std::map<int, PERSONAL_SHOP_ITENS_VALUE>::iterator it = this->m_PersonalShopInfoTarget.find(slot);

	if (it == this->m_PersonalShopInfoTarget.end()) {
		PERSONAL_SHOP_ITENS_VALUE info;

		info.slot = slot;

		info.ItemIndex = ItemIndex;

		info.Coin1 = Coin1;

		info.Coin2 = Coin2;

		info.Coin3 = Coin3;

		info.Coin4 = Coin4;

		this->m_PersonalShopInfoTarget.insert(std::make_pair(info.slot, info));
		return;
	}

	it->second.slot = slot;

	it->second.ItemIndex = ItemIndex;

	it->second.Coin1 = Coin1;

	it->second.Coin2 = Coin2;

	it->second.Coin3 = Coin3;

	it->second.Coin4 = Coin4;
}

void CPersonalShop::GCPShopItemPrinceListRecv(PMSG_PSHOP_ITEM_LIST_RECV* lpMsg)
{
	int aIndex = MAKE_NUMBERW(lpMsg->index[0], lpMsg->index[1]) & 0x7FFF;

	if (aIndex == ViewIndex) {
		this->m_PersonalShopInfo.clear();

		for (int n = 0; n < lpMsg->count; n++)
		{
			auto lpInfo = (PMSG_PSHOP_ITEM_LIST_CUSTOM*)(((BYTE*)lpMsg) + sizeof(PMSG_PSHOP_ITEM_LIST_RECV) + (sizeof(PMSG_PSHOP_ITEM_LIST_CUSTOM) * n));

			this->InsertItemValue(lpInfo->ItemIndex, lpInfo->slot, lpInfo->m_Values[0], lpInfo->m_Values[1], lpInfo->m_Values[2], lpInfo->m_Values[3]);
		}
	}
	else {
		this->m_PersonalShopInfoTarget.clear();

		for (int n = 0; n < lpMsg->count; n++)
		{
			auto lpInfo = (PMSG_PSHOP_ITEM_LIST_CUSTOM*)(((BYTE*)lpMsg) + sizeof(PMSG_PSHOP_ITEM_LIST_RECV) + (sizeof(PMSG_PSHOP_ITEM_LIST_CUSTOM) * n));

			this->InsertItemValueTarget(lpInfo->ItemIndex, lpInfo->slot, lpInfo->m_Values[0], lpInfo->m_Values[1], lpInfo->m_Values[2], lpInfo->m_Values[3]);
		}
	}
}

bool CPersonalShop::UpdateMouseChangeValue()
{
	if (CheckMouseIn(this->m_x + (((230 / 2) - 54) / 2), this->m_y + this->m_height - 50, 54, 30)) {
		if (IsPressKey(VK_LBUTTON)) {
			m_EventKey = 2;
			ResetMouseL();

			ITEM* item = nullptr;
			DWORD CheckPick = ((DWORD(*)())0x7DD0F0)();

			if (CheckPick) {
				item = ((ITEM * (__thiscall*)(DWORD))0x7D9430)(CheckPick);
			}
			else {
				item = pMyShopInventoryFindItemThis(pMyShopInventoryThis(pWindowThis()), *(DWORD*)((DWORD)pMyShopInventoryThis(pWindowThis()) + 32));
			}

			if (item) {
				if (atoi(this->m_TextInput.c_str()) != 0
					|| atoi(this->m_TextInput2.c_str()) != 0
					|| atoi(this->m_TextInput3.c_str()) != 0
					|| atoi(this->m_TextInput4.c_str()) != 0) {
					this->WindowValueVisible = 0;
					this->PersonalShopValueItemChangeSend(*(DWORD*)((DWORD)pMyShopInventoryThis(pWindowThis()) + 32) + 204, atoi(this->m_TextInput.c_str()), atoi(this->m_TextInput2.c_str()), atoi(this->m_TextInput3.c_str()), atoi(this->m_TextInput4.c_str()));
					pMyShopInventorySetInputValueTextBox(pMyShopInventoryThis(pWindowThis()), 0);
				}
			}
		}
		else {
			m_EventKey = 1;
		}
	}
	else {
		m_EventKey = 0;
	}

	if (CheckMouseIn(this->m_x + (230 / 2) + (((230 / 2) - 54) / 2), this->m_y + this->m_height - 50, 54, 30)) {
		if (IsPressKey(VK_LBUTTON)) {
			m_EventKey2 = 2;
			ResetMouseL();

			this->WindowValueVisible = 0;
			((void(*)())0x7DD230)();
		}
		else {
			m_EventKey2 = 1;
		}
	}
	else {
		m_EventKey2 = 0;
	}

	if (IsPressKey(VK_LBUTTON)) {
		if (CheckMouseIn(this->m_x + 115 - 25, this->m_y + 57, 50, 10) && gLoadFiles.m_LoadFiles.m_Coin1Switch) {
			ResetMouseL();

			this->m_Input01Open = 1;
		}
		else {
			this->m_Input01Open = 0;
		}

		if (CheckMouseIn(this->m_x + 115 - 25, this->m_y + 87, 50, 10) && gLoadFiles.m_LoadFiles.m_Coin2Switch) {
			ResetMouseL();

			this->m_Input02Open = 1;
		}
		else {
			this->m_Input02Open = 0;
		}

		if (CheckMouseIn(this->m_x + 115 - 25, this->m_y + 117, 50, 10) && gLoadFiles.m_LoadFiles.m_Coin3Switch) {
			ResetMouseL();

			this->m_Input03Open = 1;
		}
		else {
			this->m_Input03Open = 0;
		}

		if (CheckMouseIn(this->m_x + 115 - 25, this->m_y + 147, 50, 10) && gLoadFiles.m_LoadFiles.m_Coin4Switch) {
			ResetMouseL();

			this->m_Input04Open = 1;
		}
		else {
			this->m_Input04Open = 0;
		}
	}

	return 1;
}

bool CPersonalShop::UpdateChangeValue()
{
	return 1;
}

void CPersonalShop::RenderWindowChangeValue()
{
	if (!this->WindowValueVisible) {
		return;
	}

	EnableAlphaTest(1);

	glColor4f(1.0f, 1.0f, 1.0f, 1.0f);

	int x, y, width, height;

	x = this->m_x; y = this->m_y + 2.f, width = this->m_width - 8; height = this->m_height - 10;

	RenderImage(0x7A5A, x, y, width, height);

	x = this->m_x; y = this->m_y, width = 230; height = 67;

	RenderImage(0x7A57, x, y, width, height);

	x = this->m_x; y += 67; width = 230; height = 15;

	for (int i = 0; i < 7; ++i)
	{
		RenderImage(0x7A58, x, y, width, height);
		y += height;
	}

	x = this->m_x; width = 230; height = 50;

	RenderImage(0x7A59, x, y, width, height);

	DWORD StructImage = ((DWORD(__thiscall*)(DWORD*, DWORD))0x42CFE0)(&*(DWORD*)0x9816AA0, 0x7A5B);

	int m_fButtonWidth = 54;
	int m_fButtonHeight = 30;

	if (StructImage != 0) {
		RenderImage2(0x7A5B, x + (((230 / 2) - 54) / 2), this->m_y + this->m_height - 50, 54, 30,
			(0.5f / (float)*(float*)(StructImage + 260)), ((this->m_EventKey * m_fButtonHeight + 0.5f) / (float)*(float*)(StructImage + 264)),
			(m_fButtonWidth - 0.5f) / (float)*(float*)(StructImage + 260) - (0.5f / (float)*(float*)(StructImage + 260)),
			(m_fButtonHeight - 0.5f) / (float)*(float*)(StructImage + 264) - (0.5f / (float)*(float*)(StructImage + 264)), 1, 1, 0);
	}

	DWORD StructImage2 = ((DWORD(__thiscall*)(DWORD*, DWORD))0x42CFE0)(&*(DWORD*)0x9816AA0, 0x7A5C);

	if (StructImage2 != 0) {
		RenderImage2(0x7A5C, x + (230 / 2) + (((230 / 2) - 54) / 2), this->m_y + this->m_height - 50, 54, 30,
			(0.5f / (float)*(float*)(StructImage2 + 260)), ((this->m_EventKey2 * m_fButtonHeight + 0.5f) / (float)*(float*)(StructImage2 + 264)),
			(m_fButtonWidth - 0.5f) / (float)*(float*)(StructImage2 + 260) - (0.5f / (float)*(float*)(StructImage2 + 260)),
			(m_fButtonHeight - 0.5f) / (float)*(float*)(StructImage2 + 264) - (0.5f / (float)*(float*)(StructImage2 + 264)), 1, 1, 0);
	}

	//Texts

	x = this->m_x, y = this->m_y + 2.f;

	pSetTextBgColor2(pTextThis(), 0);

	pSetTextColor(pTextThis(), 255, 189, 25, 255);

	pTextSetFont(pTextThis(), g_hFontBold);

	pDrawText(pTextThis(), x, y + 15, gCustomMessage.GetMessage(36), 230, 0, 3, 0);

	pSetTextColor(pTextThis(), 255, 255, 255, 255);

	pTextSetFont(pTextThis(), g_hFont);

	if (gLoadFiles.m_LoadFiles.m_Coin1Switch) {
		pDrawText(pTextThis(), x, y + 45, gCustomMessage.GetMessage(37), 230, 0, 3, 0);
	}

	if (gLoadFiles.m_LoadFiles.m_Coin2Switch) {
		pDrawText(pTextThis(), x, y + 75, gCustomMessage.GetMessage(38), 230, 0, 3, 0);
	}

	if (gLoadFiles.m_LoadFiles.m_Coin3Switch) {
		pDrawText(pTextThis(), x, y + 105, gCustomMessage.GetMessage(39), 230, 0, 3, 0);
	}

	if (gLoadFiles.m_LoadFiles.m_Coin4Switch) {
		pDrawText(pTextThis(), x, y + 135, gCustomMessage.GetMessage(40), 230, 0, 3, 0);
	}

	if (gLoadFiles.m_LoadFiles.m_Coin1Switch) {
		EnableAlphaTest(1);
		glColor4f(0.f, 0.f, 0.f, 1.f);
		pDrawBarForm(x + 115 - 25, y + 55, 50, 10, 0.0, 0);
		((void(*)())0x637A30)();
	}

	if (gLoadFiles.m_LoadFiles.m_Coin2Switch) {
		EnableAlphaTest(1);
		glColor4f(0.f, 0.f, 0.f, 1.f);
		pDrawBarForm(x + 115 - 25, y + 85, 50, 10, 0.0, 0);
		((void(*)())0x637A30)();
	}

	if (gLoadFiles.m_LoadFiles.m_Coin3Switch) {
		EnableAlphaTest(1);
		glColor4f(0.f, 0.f, 0.f, 1.f);
		pDrawBarForm(x + 115 - 25, y + 115, 50, 10, 0.0, 0);
		((void(*)())0x637A30)();
	}

	if (gLoadFiles.m_LoadFiles.m_Coin4Switch) {
		EnableAlphaTest(1);
		glColor4f(0.f, 0.f, 0.f, 1.f);
		pDrawBarForm(x + 115 - 25, y + 145, 50, 10, 0.0, 0);
		((void(*)())0x637A30)();
	}

	pSetTextColor(pTextThis(), 255, 255, 255, 255);

	if (gLoadFiles.m_LoadFiles.m_Coin1Switch) {
		pDrawText(pTextThis(), x + 115 - 25, y + 57, (this->m_TextInput.length() <= 0 ? "0" : this->m_TextInput.c_str()), 50, 0, 3, 0);
	}

	if (gLoadFiles.m_LoadFiles.m_Coin2Switch) {
		pDrawText(pTextThis(), x + 115 - 25, y + 87, (this->m_TextInput2.length() <= 0 ? "0" : this->m_TextInput2.c_str()), 50, 0, 3, 0);
	}

	if (gLoadFiles.m_LoadFiles.m_Coin3Switch) {
		pDrawText(pTextThis(), x + 115 - 25, y + 117, (this->m_TextInput3.length() <= 0 ? "0" : this->m_TextInput3.c_str()), 50, 0, 3, 0);
	}

	if (gLoadFiles.m_LoadFiles.m_Coin4Switch) {
		pDrawText(pTextThis(), x + 115 - 25, y + 147, (this->m_TextInput4.length() <= 0 ? "0" : this->m_TextInput4.c_str()), 50, 0, 3, 0);
	}

	DisableAlphaBlend();
}

void CPersonalShop::PersonalShopValueItemChangeSend(unsigned char slot, int coin1, int coin2, int coin3, int coin4)
{
	if (pMyShopInventoryIsEnablePersonalShop(pMyShopInventoryThis(pWindowThis()))) {
		PMSG_PSHOP_SET_CLOSE_SEND pMsg;

		pMsg.header.setE(0x3F, 0x03, sizeof(pMsg));

		DataSend((BYTE*)&pMsg, pMsg.header.size);
	}

	DWORD CheckPick = ((DWORD(*)())0x7DD0F0)();

	if (CheckPick) {
		auto itemObj = ((ITEM * (__thiscall*)(DWORD))0x7D9430)(CheckPick);

		if (itemObj) {
			int SrcIndex = ((int(__thiscall*)(DWORD))0x7D94E0)(CheckPick);
			int TargIndex = pMyShopInventoryGetTargetIndex(pMyShopInventoryThis(pWindowThis()));

			if (pInventoryIsInvenctrlSame(pInventoryThis(pWindowThis()), ((DWORD(__thiscall*)(DWORD))0x7D9410)(CheckPick)) != -1) {

				SrcIndex = pInventorySlotCntSendSrcInvenIndex(pInventoryThis(pWindowThis()), SrcIndex, pInventoryIsInvenctrlSame(pInventoryThis(pWindowThis()), ((DWORD(__thiscall*)(DWORD))0x7D9410)(CheckPick))) + 12;
				SendItemMove(SrcIndex, 0, TargIndex + 204, 4);

				slot = TargIndex + 204;
			}

			if (((DWORD(__thiscall*)(DWORD))0x7D9410)(CheckPick) == 0) {
				SendItemMove(SrcIndex, 0, TargIndex + 204, 4);

				slot = TargIndex + 204;
			}

			if (((DWORD(__thiscall*)(DWORD))0x7D9410)(CheckPick) == pMyShopInventoryGetMyInventoryCtrl(pMyShopInventoryThis(pWindowThis()))) {
				SendItemMove(SrcIndex, 4, TargIndex + 204, 4);

				slot = TargIndex + 204;
			}
		}
	}

	PMSG_PSHOP_SET_ITEM_PRICE_SEND pMsg;

	pMsg.header.setE(0x3F, 0x01, sizeof(pMsg));

	pMsg.slot = slot;

	pMsg.price[0] = 0;

	pMsg.price[1] = 0;

	pMsg.price[2] = 0;

	pMsg.price[3] = 0;

	pMsg.coins[0] = coin1;

	pMsg.coins[1] = coin2;

	pMsg.coins[2] = coin3;

	pMsg.coins[3] = coin4;

	DataSend((BYTE*)&pMsg, pMsg.header.size);

	((void((*)(int, int, int)))0x668630)(slot, 1, ((int(*)())0x790AA0)());
}

void CPersonalShop::InsertKeyInInput(int Param)
{
	if (!this->WindowValueVisible) {
		return;
	}

	int number = -1;

	if (Param == 0x30 || Param == 0x60) {
		number = 0;
	}
	else if (Param == 0x31 || Param == 0x61) {
		number = 1;
	}
	else if (Param == 0x32 || Param == 0x62) {
		number = 2;
	}
	else if (Param == 0x33 || Param == 0x63) {
		number = 3;
	}
	else if (Param == 0x34 || Param == 0x64) {
		number = 4;
	}
	else if (Param == 0x35 || Param == 0x65) {
		number = 5;
	}
	else if (Param == 0x36 || Param == 0x66) {
		number = 6;
	}
	else if (Param == 0x37 || Param == 0x67) {
		number = 7;
	}
	else if (Param == 0x38 || Param == 0x68) {
		number = 8;
	}
	else if (Param == 0x39 || Param == 0x69) {
		number = 9;
	}

	char Date[2] = { 0 };

	if (this->m_Input01Open) {
		if (this->m_TextInput.length() <= 0) {
			sprintf_s(Date, "%d", number);
			this->m_TextInput.append(Date);
		}
		else {
			if (this->m_TextInput.length() <= 8) {
				sprintf_s(Date, "%d", number);
				this->m_TextInput.append(Date);
			}
		}
	}

	if (this->m_Input02Open) {
		if (this->m_TextInput2.length() <= 0) {
			sprintf_s(Date, "%d", number);
			this->m_TextInput2.append(Date);
		}
		else {
			if (this->m_TextInput2.length() <= 8) {
				sprintf_s(Date, "%d", number);
				this->m_TextInput2.append(Date);
			}
		}
	}

	if (this->m_Input03Open) {
		if (this->m_TextInput3.length() <= 0) {
			sprintf_s(Date, "%d", number);
			this->m_TextInput3.append(Date);
		}
		else {
			if (this->m_TextInput3.length() <= 8) {
				sprintf_s(Date, "%d", number);
				this->m_TextInput3.append(Date);
			}
		}
	}

	if (this->m_Input04Open) {
		if (this->m_TextInput4.length() <= 0) {
			sprintf_s(Date, "%d", number);
			this->m_TextInput4.append(Date);
		}
		else {
			if (this->m_TextInput4.length() <= 8) {
				sprintf_s(Date, "%d", number);
				this->m_TextInput4.append(Date);
			}
		}
	}
}

void CPersonalShop::RemoveKeyInInput()
{
	if (!this->WindowValueVisible) {
		return;
	}

	if (this->m_Input01Open) {
		if (this->m_TextInput.length() > 0) {
			this->m_TextInput.pop_back();
		}
	}

	if (this->m_Input02Open) {
		if (this->m_TextInput2.length() > 0) {
			this->m_TextInput2.pop_back();
		}
	}

	if (this->m_Input03Open) {
		if (this->m_TextInput3.length() > 0) {
			this->m_TextInput3.pop_back();
		}
	}

	if (this->m_Input04Open) {
		if (this->m_TextInput4.length() > 0) {
			this->m_TextInput4.pop_back();
		}
	}
}