#include "stdafx.h"
#include "LuaInterface.h"
#include "LuaOpenFolder.h"
#include "AntiHack.h"
#include "Interface.h"
#include "LuaStack.hpp"
#include "Item.h"
#include "CustomItemForce.h"
#include "Console.h"
#include "WideScreen.h"

using namespace luaaa;

LuaInterface::LuaInterface()
{
}

LuaInterface::~LuaInterface()
{
}

static BOOL LuaRenderImage(lua_State * Lua)
{
	((void(__cdecl*)(DWORD, float, float, float, float)) 0x00790B50)((DWORD)lua_tointeger(Lua, 1), (float)lua_tonumber(Lua, 2), (float)lua_tonumber(Lua, 3), (float)lua_tonumber(Lua, 4), (float)lua_tonumber(Lua, 5));
	lua_pop(Lua, 5);
	return 1;
};

static BOOL LuaRenderImage2(lua_State * Lua)
{
	((void(__cdecl*)(int Texture, float x, float y, float Width, float Height, float u, float v, float uWidth, float vHeight, bool Scale, bool StartScale, float Alpha)) 0x00637C60)
		((int)lua_tointeger(Lua, 1), (float)lua_tonumber(Lua, 2), (float)lua_tonumber(Lua, 3), (float)lua_tonumber(Lua, 4), (float)lua_tonumber(Lua, 5), (float)lua_tonumber(Lua, 6), (float)lua_tonumber(Lua, 7), (float)lua_tonumber(Lua, 8), (float)lua_tonumber(Lua, 9), (bool)lua_tointeger(Lua, 10), (bool)lua_tointeger(Lua, 11), (float)lua_tonumber(Lua, 12));
	lua_pop(Lua, 12);
	return 1;
};

int DrawFormat(DWORD Color, int PosX, int PosY, int Width, int Align, LPCSTR Text, ...)
{
	char Buff[2048];
	int BuffLen = sizeof(Buff) - 1;
	ZeroMemory(Buff, BuffLen);

	va_list args;
	va_start(args, Text);
	int Len = vsprintf_s(Buff, BuffLen, Text, args);
	va_end(args);

	int LineCount = 0;

	char * Line = strtok(Buff, "\n");

	while (Line != NULL)
	{
		((int(__cdecl*)(LPCTSTR Text, int PosX, int PosY, int Width, int Arg5, int Color, int Arg7, int Align)) 0x7D04D0)(Line, PosX, PosY, Width, 0, Color, 0, Align);
		PosY += 10;
		Line = strtok(NULL, "\n");
	}

	return PosY;
}

static BOOL LuaRenderText(lua_State * Lua)
{
	char * Text = (char*)lua_tostring(Lua, 1);
	int PosX = (int)lua_tonumber(Lua, 2);
	int PosY = (int)lua_tonumber(Lua, 3);
	int Width = (int)lua_tonumber(Lua, 4);
	DWORD Color = (DWORD)lua_tonumber(Lua, 5);
	int Align = (int)lua_tonumber(Lua, 6);

	DrawFormat(Color, PosX, PosY, Width, Align, Text);

	lua_pop(Lua, 6);
	return 1;
};

static BOOL LuaEnableAlphaTest(lua_State * Lua)
{
	EnableAlphaTest(1);
	return true;
};

static BOOL LuaEnableAlphaBlend(lua_State * Lua)
{
	EnableAlphaBlend();
	return true;
};

static BOOL LuaDisableAlphaBlend(lua_State * Lua)
{
	DisableAlphaBlend();
	return true;
};

static BOOL LuaglColor3f(lua_State * Lua)
{
	glColor3f((float)lua_tonumber(Lua, 1), (float)lua_tonumber(Lua, 2), (float)lua_tonumber(Lua, 3));
	lua_pop(Lua, 3);
	return true;
};

static BOOL LuaglColor4f(lua_State * Lua)
{
	glColor4f((float)lua_tonumber(Lua, 1), (float)lua_tonumber(Lua, 2), (float)lua_tonumber(Lua, 3), (float)lua_tonumber(Lua, 4));
	lua_pop(Lua, 4);
	return true;
};

static BOOL LuaDrawBar(lua_State * Lua)
{
	pDrawBarForm((float)lua_tonumber(Lua, 1), (float)lua_tonumber(Lua, 2), (float)lua_tonumber(Lua, 3), (float)lua_tonumber(Lua, 4), 0.f, 0);
	lua_pop(Lua, 4);
	return true;
};

static BOOL LuapSetBlend(lua_State * Lua)
{
	pSetBlend(true);
	return true;
};

static BOOL LuaGLSwitchBlend(lua_State * Lua)
{
	pGLSwitchBlend();
	return true;
};

static BOOL LuaGLSwitch(lua_State * Lua)
{
	pGLSwitch();
	return true;
};

static BOOL LuaEndDrawBar(lua_State * Lua)
{
	((void(*)())0x637A30)();
	return true;
};

static BOOL LuaSetFontType(lua_State * Lua)
{
	int value = (int)lua_tonumber(Lua, 1);
	lua_pop(Lua, 1);

	if (value == 1) {
		pTextSetFont(pTextThis(), g_hFontBold);
	}
	else if (value == 2) {
		pTextSetFont(pTextThis(), g_hFontBig);
	}
	else if (value == 3) {
		pTextSetFont(pTextThis(), g_hFontFix);
	}
	else {
		pTextSetFont(pTextThis(), g_hFont);
	}

	return true;
};

static BOOL LuaSetFontBg(lua_State * Lua)
{
	pSetTextBgColor(pTextThis(), (BYTE)lua_tonumber(Lua, 1), (BYTE)lua_tonumber(Lua, 2), (BYTE)lua_tonumber(Lua, 3), (BYTE)lua_tonumber(Lua, 4));
	lua_pop(Lua, 4);
	return true;
};

static BOOL LuaRenderText2(lua_State * Lua)
{
	pDrawText(pTextThis(), (int)lua_tonumber(Lua, 1), (int)lua_tonumber(Lua, 2), lua_tostring(Lua, 3), (int)lua_tonumber(Lua, 4), 0, (int)lua_tonumber(Lua, 5), 0);
	lua_pop(Lua, 3);
	return true;
};

static BOOL LuaRenderText3(lua_State * Lua)
{
	pDrawText(pTextThis(), (int)lua_tonumber(Lua, 1), (int)lua_tonumber(Lua, 2), lua_tostring(Lua, 3), 0, 0, (int)lua_tonumber(Lua, 4), 0);
	lua_pop(Lua, 3);
	return true;
};

static BOOL LuaSetTextColor(lua_State * Lua)
{
	pSetTextColor(pTextThis(), (BYTE)lua_tointeger(Lua, 1), (BYTE)lua_tointeger(Lua, 2), (BYTE)lua_tointeger(Lua, 3), (BYTE)lua_tointeger(Lua, 4));
	lua_pop(Lua, 4);
	return true;
};

static BOOL LuaSetLockInterfaces(lua_State * Lua)
{
	pSetCursorFocus = 1;
	return true;
};

static BOOL LuaSetUnlockInterfaces(lua_State * Lua)
{
	pSetCursorFocus = 0;
	return true;
};

static BOOL LuaLockPlayerWalk(lua_State * Lua)
{
	gAntiHack.lockedWalk = 1;
	return true;
};

static BOOL LuaUnlockPlayerWalk(lua_State * Lua)
{
	gAntiHack.lockedWalk = 0;
	return true;
};

static BOOL LuaCheckClickClient(lua_State * Lua)
{
	lua_pushnumber(Lua, *(BYTE*)0x8793386);
	return true;
};

static BOOL LuaDisableClickClient(lua_State * Lua)
{
	*(BYTE*)0x8793386 = 0;
	*(BYTE*)0x8793384 = 0;
	gInterface.interfaceLock = 1;
	return true;
};

static BOOL LuaCreateItem(lua_State * Lua)
{
	glMatrixMode(0x1701);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(int, int, int, int))0x6363D0)(0, 0, *(GLsizei*)MAIN_RESOLUTION_X, *(GLsizei*)MAIN_RESOLUTION_Y);

	((void(*)(float, float, float, float))0x6358A0)(1.f, (float)(*(DWORD*)MAIN_RESOLUTION_X) / (float)(*(DWORD*)MAIN_RESOLUTION_Y), *(float*)0xE61E38, *(float*)0xE61E3C);

	glMatrixMode(0x1700);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(vec34_t))0x635830)(*(vec34_t*)0x87933A0);

	((void(*)())0x635DE0)();

	((void(*)())0x635E40)();

	((void(*)(float, float, float, float, int, int, int, int, bool))0x5CF310)((float)lua_tointeger(Lua, 1), (float)lua_tointeger(Lua, 2), (float)lua_tointeger(Lua, 3), (float)lua_tointeger(Lua, 4), (int)lua_tointeger(Lua, 5), (int)lua_tointeger(Lua, 6) * 8, (int)lua_tointeger(Lua, 7), (int)lua_tointeger(Lua, 8), 0);

	lua_pop(Lua, 8);

	glMatrixMode(0x1700);
	glPopMatrix();
	glMatrixMode(0x1701);
	glPopMatrix();

	glColor3f(1, 1, 1);
	pSetBlend(false);
	return true;
};

static BOOL LuaShowItemDescription(lua_State * Lua)
{
	EnableAlphaTest(1);

	BYTE m_Buff[MAX_ITEM_INFO];

	m_Buff[0] = lua_tointeger(Lua, 3) & 0xFF;

	m_Buff[1] = 0;
	m_Buff[1] |= (BYTE)lua_tointeger(Lua, 4) * 8;
	m_Buff[1] |= (BYTE)lua_tointeger(Lua, 5) * 128;
	m_Buff[1] |= (BYTE)lua_tointeger(Lua, 6) * 4;
	m_Buff[1] |= (BYTE)lua_tointeger(Lua, 7) & 3;

	m_Buff[2] = (BYTE)lua_tointeger(Lua, 8);

	m_Buff[3] = 0;
	m_Buff[3] |= ((short)lua_tointeger(Lua, 3) & 256) >> 1;
	m_Buff[3] |= (((BYTE)lua_tointeger(Lua, 7) > 3) ? 64 : 0);
	m_Buff[3] |= (BYTE)lua_tointeger(Lua, 9);

	m_Buff[4] = (BYTE)lua_tointeger(Lua, 10);

	m_Buff[5] = 0;
	m_Buff[5] |= (lua_tointeger(Lua, 3) & GET_ITEM(15, 0)) >> 5;
	m_Buff[5] |= ((0 & 128) >> 4);
	m_Buff[5] |= ((0 & 1) << 1);
	m_Buff[5] |= ((0 & 1) << 2);

	m_Buff[6] = 0;

	m_Buff[7] = 0xFF;
	m_Buff[8] = 0xFF;
	m_Buff[9] = 0xFF;
	m_Buff[10] = 0xFF;
	m_Buff[11] = 0xFF;

	auto m_Item = ((ITEM*(__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), m_Buff);

	gCustomItemForce.ItemConvert(m_Item, m_Buff[1], m_Buff[3], m_Item->ExtOption);
	//((void(*)(ITEM*, BYTE, BYTE, BYTE))0x58B910)(m_Item, m_Buff[1], m_Buff[3], m_Item->ExtOption);

	((void(__thiscall*)(LPVOID, int, int, ITEM*, bool, int, bool))0x7E3E30)(((LPVOID(__thiscall*)(LPVOID This)) 0x861AA0)(pWindowThis()), (int)lua_tointeger(Lua, 1), (int)lua_tointeger(Lua, 2), m_Item, 0, 0, 0);

	DisableAlphaBlend();

	if (m_Item) {
		((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), m_Item);
		m_Item = nullptr;
	}

	lua_pop(Lua, 9);
	return true;
};

void ItemByteConvert(BYTE* lpMsg, int ItemIndex, int Level, int Op1, int Op2, int Op3, int Exc, int Ancient, int JoH, int Socket, BYTE Sock1, BYTE Sock2, BYTE Sock3, BYTE Sock4, BYTE Sock5) // OK
{
	lpMsg[0] = ItemIndex & 0xFF;

	lpMsg[1] = 0;
	lpMsg[1] |= Level * 8;
	lpMsg[1] |= Op1 * 128;
	lpMsg[1] |= Op2 * 4;
	lpMsg[1] |= Op3 & 3;

	lpMsg[2] = (BYTE)255;

	lpMsg[3] = 0;
	lpMsg[3] |= (ItemIndex & 256) >> 1;
	lpMsg[3] |= ((Op3>3) ? 64 : 0);
	lpMsg[3] |= Exc;

	lpMsg[4] = Ancient;

	lpMsg[5] = 0;
	lpMsg[5] |= (ItemIndex & GET_ITEM(15, 0)) >> 5;
	lpMsg[5] |= ((0 & 128) >> 4);
	lpMsg[5] |= ((0 & 1) << 1);
	lpMsg[5] |= ((0 & 1) << 2);

	if (JoH) {
		lpMsg[6] = JoH;
	}
	else {
		lpMsg[6] = Socket;
	}

	lpMsg[7] = Sock1;
	lpMsg[8] = Sock2;
	lpMsg[9] = Sock3;
	lpMsg[10] = Sock4;
	lpMsg[11] = Sock5;
}

void ShowItemDescriptions(int x, int y, int ItemIndex, int Level, int Op1, int Op2, int Op3, int Exc, int Ancient, int JoH, int Socket, int Sock1, int Sock2, int Sock3, int Sock4, int Sock5) {
	if (Socket == 255) {
		Socket = 0;
	}

	EnableAlphaTest(1);

	static BYTE ItemBuffer[MAX_ITEM_INFO];
	std::memset(&ItemBuffer[0], 0, sizeof(ItemBuffer));

	ItemByteConvert(ItemBuffer, ItemIndex, Level, Op1, Op2, Op3, Exc, Ancient, JoH, Socket, Sock1, Sock2, Sock3, Sock4, Sock5);

	auto m_Item = ((ITEM*(__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemBuffer);

	gCustomItemForce.ItemConvert(m_Item, ItemBuffer[1], ItemBuffer[3], ItemBuffer[4]);

	((void(__thiscall*)(LPVOID, int, int, ITEM*, bool, int, bool))0x7E3E30)(((LPVOID(__thiscall*)(LPVOID This)) 0x861AA0)(pWindowThis()), x, y, m_Item, 0, 0, 0);

	DisableAlphaBlend();

	if (m_Item) {
		((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), m_Item);
		m_Item = nullptr;
	}
}


static BOOL LuaCreateGuildMark(lua_State * Lua)
{
	WORD markIndex = lua_tointeger(Lua, 1);
	lua_pop(Lua, 1);

	((void(*)(DWORD, bool))0x5D30F0)(markIndex, 1);
	return true;
};

int CheckDistance(int key, float distance) {
	return ((bool(*)(DWORD, DWORD, DWORD, float))0x59A010)(((DWORD(__thiscall*)(void*, DWORD))0x0096A4C0)(((void* (*)())0x00402BC0)(), key), *(DWORD*)0x81C038C, *(DWORD*)0x81C0388, distance);
}

float getFPS() {
	return (float)gInterface.FPS;
}

float GetImageWidth(int Image) {

	DWORD StructImage = ((DWORD(__thiscall*)(DWORD*, DWORD))0x42CFE0)(&*(DWORD*)0x9816AA0, Image);

	if (StructImage) {
		return *(float*)(StructImage + 260);
	}

	return 0.0;
}

float GetImageHeight(int Image) {

	DWORD StructImage = ((DWORD(__thiscall*)(DWORD*, DWORD))0x42CFE0)(&*(DWORD*)0x9816AA0, Image);

	if (StructImage) {
		return *(float*)(StructImage + 264);
	}

	return 0.0;
}

void CreateItem(float x, float y, float width, float height, int index, int level, int ancient, int unknow) {
	glMatrixMode(0x1701);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(int, int, int, int))0x6363D0)(0, 0, *(GLsizei*)MAIN_RESOLUTION_X, *(GLsizei*)MAIN_RESOLUTION_Y);

	((void(*)(float, float, float, float))0x6358A0)(1.f, (float)(*(DWORD*)MAIN_RESOLUTION_X) / (float)(*(DWORD*)MAIN_RESOLUTION_Y), *(float*)0xE61E38, *(float*)0xE61E3C);

	glMatrixMode(0x1700);
	glPushMatrix();
	glLoadIdentity();

	((void(*)(vec34_t))0x635830)(*(vec34_t*)0x87933A0);

	((void(*)())0x635DE0)();

	((void(*)())0x635E40)();

	((void(*)(float, float, float, float, int, int, int, int, bool))0x5CF310)(x, y, width, height, index, level * 8, ancient, unknow, 0);

	glMatrixMode(0x1700);
	glPopMatrix();
	glMatrixMode(0x1701);
	glPopMatrix();

	glColor3f(1, 1, 1);
	pSetBlend(false);
}

int MousePosX() {
	return pCursorX;
}

int MousePosY() {
	return pCursorY;
}

//int VisualCheckInventory() {
//	return 1;
//}

void RenderImageLua(int imageID, float x, float y, float width, float height) {
	((void(__cdecl*)(int, float, float, float, float)) 0x00790B50)(imageID, x, y, width, height);
}

void RenderImage2Lua(int Texture, float x, float y, float Width, float Height, float u, float v, float uWidth, float vHeight, int Scale, int StartScale, float Alpha) {
	((void(__cdecl*)(int, float, float, float, float, float, float, float, float, bool, bool, float)) 0x00637C60)
		(Texture, x, y, Width, Height, u, v, uWidth, vHeight, Scale, StartScale, Alpha);
}


int LuaCheckWindowOpen(int WindowID) {
	return ((bool(__thiscall*)(LPVOID This, int Code)) 0x0085EC20)(((LPVOID(*)()) 0x861110)(), WindowID);
}

int LuaCloseWindow(int WindowID) {
	return ((int(__thiscall*)(LPVOID This, int Code)) 0x0085F9A0)(((LPVOID(*)()) 0x861110)(), WindowID);
}

void LuaOpenWindow(int WindowID) {
	((int(__thiscall*)(LPVOID This, int Code)) 0x0085EC50)(((LPVOID(*)()) 0x861110)(), WindowID);
}

int LuaCheckIsRepeatKey(int Key) {
	return ((int(*)(int))0x791090)(Key);
}

int LuaCheckPressedKey(int Key) {
	return ((int(*)(int))0x791070)(Key);
}

int LuaCheckReleasedKey(int Key) {
	return ((int(*)(int))0x791050)(Key);
}

void HideAllInterface() {
	((void(__thiscall*)(LPVOID))0x8606B0)(pWindowThis());
}

DWORD GetPing() {
	return gAntiHack.m_PingServer;
}


void LuaInterface::RegisterInterface(lua_State * Lua)
{
	lua_register(Lua, "RenderText", LuaRenderText);
	lua_register(Lua, "RenderText2", LuaRenderText2);
	lua_register(Lua, "RenderText3", LuaRenderText2);
	lua_register(Lua, "EnableAlphaTest", LuaEnableAlphaTest);
	lua_register(Lua, "DisableAlphaBlend", LuaDisableAlphaBlend);
	lua_register(Lua, "glColor3f", LuaglColor3f);
	lua_register(Lua, "glColor4f", LuaglColor4f);
	lua_register(Lua, "DrawBar", LuaDrawBar);
	lua_register(Lua, "SetBlend", LuapSetBlend);
	lua_register(Lua, "GLSwitchBlend", LuaGLSwitchBlend);
	lua_register(Lua, "GLSwitch", LuaGLSwitch);
	lua_register(Lua, "EndDrawBar", LuaEndDrawBar);
	lua_register(Lua, "SetFontType", LuaSetFontType);
	lua_register(Lua, "SetTextBg", LuaSetFontBg);
	lua_register(Lua, "SetTextColor", LuaSetTextColor);
	lua_register(Lua, "SetLockInterfaces", LuaSetLockInterfaces);
	lua_register(Lua, "SetUnlockInterfaces", LuaSetUnlockInterfaces);
	lua_register(Lua, "LockPlayerWalk", LuaLockPlayerWalk);
	lua_register(Lua, "UnlockPlayerWalk", LuaUnlockPlayerWalk);
	lua_register(Lua, "CheckClickClient", LuaCheckClickClient);
	lua_register(Lua, "DisableClickClient", LuaDisableClickClient);
	lua_register(Lua, "ShowItemDescription", LuaShowItemDescription);
	lua_register(Lua, "CreateGuildMark", LuaCreateGuildMark);
	
	LuaModule(Lua).fun("CheckDistance", &CheckDistance);

	LuaModule(Lua).fun("getFPS", &getFPS);

	LuaModule(Lua).fun("GetImageWidth", &GetImageWidth);
	LuaModule(Lua).fun("GetImageHeight", &GetImageHeight);

	LuaModule(Lua).fun("ShowDescriptionComplete", &ShowItemDescriptions);

	LuaModule(Lua).fun("CreateItem", &CreateItem);

	LuaModule(Lua).fun("MousePosX", &MousePosX);
	LuaModule(Lua).fun("MousePosY", &MousePosY);

	//LuaModule(Lua).fun("VisualCheckInventory", &VisualCheckInventory);

	LuaModule(Lua).fun("RenderImage", &RenderImageLua);
	LuaModule(Lua).fun("RenderImage2", &RenderImage2Lua);

	LuaModule(Lua).fun("CheckWindowOpen", &LuaCheckWindowOpen);
	LuaModule(Lua).fun("CloseWindow", &LuaCloseWindow);
	LuaModule(Lua).fun("OpenWindow", &LuaOpenWindow);

	LuaModule(Lua).fun("CheckRepeatKey", &LuaCheckIsRepeatKey);
	LuaModule(Lua).fun("CheckPressedKey", &LuaCheckPressedKey);
	LuaModule(Lua).fun("CheckReleasedKey", &LuaCheckReleasedKey);

	LuaModule(Lua).fun("HideAllInterface", &HideAllInterface);

	LuaModule(Lua).fun("getPing", &GetPing);
}
