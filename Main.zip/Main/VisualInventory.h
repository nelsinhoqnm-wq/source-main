#pragma once

#include "Lua.h"
#include "LuaGlobal.h"

class ITEMS_SLOTS_INFO {
public:
	ITEMS_SLOTS_INFO() {
		this->slot = -1;
	};

	~ITEMS_SLOTS_INFO() {
	};

	void Clear() {
		this->slot = -1;
	}

	bool ItemEquiped;
	BYTE slot;
	ITEM pItemObj;

};

struct ITEM_INVENTORY_EQUIP
{
	int x;
	int y;
	int width;
	int height;
	int ImageID;
	int Active;
	int isPet;
};

class VisualInventory {
public:
	VisualInventory();
	~VisualInventory();

	void Release();
	void Init();
	void InitFromLua();
	static void Render();
	bool Update(DWORD Struct);
	void CheckCanEquipItem(int slot);
	void RenderItemToolTip(int slot);
	void Render3DItem();


	void AddItem(BYTE slot, BYTE* ItemInfo);
	void AddItem(BYTE slot, ITEM* itemObj);
	void DeleteItem(int slot);
	void Unequip(int slot);
	void EffectHelper(int ItemIndex);
	void RecoveryOldHelper();

	static void MainSetCharacterClass(ObjectPreview* Struct);



	int CheckVisualOpen() {
		return this->InventoryVisualOpen;
	};

	ITEM* getItem(int slot) {
		std::map<int, ITEMS_SLOTS_INFO>::iterator it = this->m_ItemsInfo.find(slot);

		if (it == this->m_ItemsInfo.end()) {
			return nullptr;
		}

		return &it->second.pItemObj;
	};

	bool CheckItemExist(int slot) {
		std::map<int, ITEMS_SLOTS_INFO>::iterator it = this->m_ItemsInfo.find(slot);

		if (it == this->m_ItemsInfo.end()) {
			return 0;
		}

		if (it->second.pItemObj.Type != -1) {
			return 1;
		}

		return 0;
	};

public:
	int InventoryVisualOpen;
	int InventoryVisualSwitch;
	int InventoryVisualOriginalDescription;
	DWORD Line;
	DWORD LineIndex;
	DWORD itemObject;

	ITEM_INVENTORY_EQUIP m_ItemInventoryEquip[12];
	std::map<int, ITEMS_SLOTS_INFO> m_ItemsInfo;

public:
	Lua m_Lua;
	LuaGlobal m_LuaGlobal;
};

extern VisualInventory gVisualInventory;