#pragma once

#include "Lua.h"
#include "LuaLoadImage.h"

class CCustomSkillEffect {
public:
	CCustomSkillEffect();
	~CCustomSkillEffect();

	void Init();
	void RestartLua();

public:
	Lua m_Lua;

	LuaLoadImage LuaLoadImage;
};

extern CCustomSkillEffect gCustomSkillEffect;