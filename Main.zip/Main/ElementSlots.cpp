#include "stdafx.h"
#include "ElementSlots.h"
#include "Util.h"
#include "Console.h"
#include "LuaStack.hpp"
#include "ElementPet.h"
#include "HelperSystem.h"
#include "Item.h"
#include "VisualInventory.h"
#include "DarkSpirit.h"
#include "Protocol.h"
#include "HelperManager.h"

using namespace luaaa;

CElementSlots gElementSlots;

CElementSlots::CElementSlots() : m_Lua(true)
{
	this->ImageNewSlot1 = 160535;
	this->ImageNewSlot2 = 160536;
	this->ImageNewSlot3 = 160537;
	this->ImageNewSlot4 = 160538;

	this->m_ElementSlots.clear();

	this->m_ElementEquiped[0].x = 56;
	this->m_ElementEquiped[0].y = 44;
	this->m_ElementEquiped[0].width = 22;
	this->m_ElementEquiped[0].height = 22;
	this->m_ElementEquiped[0].ImageID= this->ImageNewSlot1;
	this->m_ElementEquiped[0].Active = 0;
	this->m_ElementEquiped[0].isPet = 0;

	this->m_ElementEquiped[1].x = 116;
	this->m_ElementEquiped[1].y = 175;
	this->m_ElementEquiped[1].width = 22;
	this->m_ElementEquiped[1].height = 22;
	this->m_ElementEquiped[1].ImageID = this->ImageNewSlot2;
	this->m_ElementEquiped[1].Active = 0;
	this->m_ElementEquiped[1].isPet = 0;

	this->m_ElementEquiped[2].x = 56;
	this->m_ElementEquiped[2].y = 115;
	this->m_ElementEquiped[2].width = 22;
	this->m_ElementEquiped[2].height = 22;
	this->m_ElementEquiped[2].ImageID = this->ImageNewSlot3;
	this->m_ElementEquiped[2].Active = 0;
	this->m_ElementEquiped[2].isPet = 0;

	this->m_ElementEquiped[3].x = 116;
	this->m_ElementEquiped[3].y = 115;
	this->m_ElementEquiped[3].width = 22;
	this->m_ElementEquiped[3].height = 22;
	this->m_ElementEquiped[3].ImageID = this->ImageNewSlot4;
	this->m_ElementEquiped[3].Active = 0;
	this->m_ElementEquiped[3].isPet = 0;
}

CElementSlots::~CElementSlots()
{
	this->Release();
}

void CElementSlots::Release()
{
	for (std::map<int, ELEMENT_SLOTS_INFO>::iterator it = gElementSlots.m_ElementSlots.begin(); it != gElementSlots.m_ElementSlots.end(); it++) {
		auto lpInfo = &(*it).second;

		lpInfo->Clear();
	}

	gElementSlots.m_ElementSlots.clear();
}

void SetElementSlot(int stack, int x, int y, int width, int height, int active, int pet) {
	gElementSlots.m_ElementEquiped[stack].x = x;
	gElementSlots.m_ElementEquiped[stack].y = y;
	gElementSlots.m_ElementEquiped[stack].width = width;
	gElementSlots.m_ElementEquiped[stack].height = height;
	gElementSlots.m_ElementEquiped[stack].Active = active;
	gElementSlots.m_ElementEquiped[stack].isPet = pet;
}

void GCItemListRecv(PMSG_ITEM_LIST_RECV * lpMsg, int Encrypted)
{
	((void(*)(PMSG_ITEM_LIST_RECV*, int))0x0063F200)(lpMsg, Encrypted);

	//gHelperManager.DeleteHelper(Hero);
	gElementPetFirst.DeleteHelper(Hero);
	gElementPetSecond.DeleteHelper(Hero);

	for (int n = 0; n < lpMsg->count; n++)
	{
		auto lpInfo = (PMSG_ITEM_LIST*)(((BYTE*)lpMsg) + sizeof(PMSG_ITEM_LIST_RECV) + (sizeof(PMSG_ITEM_LIST)*n));

		if (lpInfo->slot >= 236 && lpInfo->slot <= 239) {
			gElementSlots.AddItem(lpInfo->slot, lpInfo->ItemInfo);
		}
		else if (lpInfo->slot >= 240 && lpInfo->slot <= 248) {
			gVisualInventory.AddItem(lpInfo->slot, lpInfo->ItemInfo);
		}
	}
}

void CElementSlots::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetElementSlot", &SetElementSlot);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//ElementSlots.lua");

	this->m_Lua.Generic_Call("StartLoadElementSlots", ">");

	MemorySet(0x0083503C, 0x90, 13);
	SetCompleteHook(0xE9, 0x0083503C, &this->Update);

	SetCompleteHook(0xE9, 0x008373A0, &this->RenderEquippedItem);

	SetCompleteHook(0xE9, 0x008373C0, &this->RenderEquippedItem2);

	MemorySet(0x0083B879, 0x90, 6);
	SetCompleteHook(0xE9, 0x0083B879, &this->RenderItemToolTip);

	MemorySet(0x008353D9, 0x90, 7);
	SetCompleteHook(0xE9, 0x008353D9, &this->RenderItem3D);

	MemorySet(0x00833B26, 0x90, 7);
	SetCompleteHook(0xE9, 0x00833B26, &this->UnequipItem);

	MemorySet(0x008380DA, 0x90, 6);
	SetCompleteHook(0xE9, 0x008380DA, &this->CheckPickItem);

	MemorySet(0x007DD2C6, 0x90, 7);
	SetCompleteHook(0xE9, 0x007DD2C6, &this->BackUpPickedItem);

	MemorySet(0x00837B4F, 0x90, 6);
	SetCompleteHook(0xE9, 0x00837B4F, &this->CheckEquipItem);

	SetCompleteHook(0xE8, 0x00663EF4, &GCItemListRecv);
}

void CElementSlots::Render()
{
	
}

int CheckMouseItemPointer(DWORD Struct) {
	if (gVisualInventory.Update(Struct) == 1) {
		return 1;
	}

	for (int i = 0; i < 4; i++) {
		if (gElementSlots.m_ElementEquiped[i].Active == 0) {
			continue;
		}

		if (CheckMouseIn(*((DWORD *)pInventoryThis(pWindowThis()) + 9) + gElementSlots.m_ElementEquiped[i].x
			, *((DWORD *)pInventoryThis(pWindowThis()) + 10) + gElementSlots.m_ElementEquiped[i].y
			, gElementSlots.m_ElementEquiped[i].width
			, gElementSlots.m_ElementEquiped[i].height)) {
			*(DWORD *)(Struct + 284) = 236 + i;
			return 1;
		}
	}

	return 0;
}

__declspec(naked) void CElementSlots::Update()
{
	static DWORD m_ReturnFunc = 0x00835049;
	static DWORD m_ExitFunc = 0x008350D0;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP - 0xC];
		PUSH EDX;
		CALL[CheckMouseItemPointer];
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_ExitFunc];

	RETURN:
		MOV EDX, DWORD PTR SS : [EBP - 0xC];
		MOV DWORD PTR DS : [EDX + 0x11C], -1;
		JMP[m_ReturnFunc];
	}
}

void CElementSlots::UpdateKey()
{

}

void CElementSlots::RenderEquippedItemSlot()
{
	if (gVisualInventory.CheckVisualOpen()) {
		return;
	}

	EnableAlphaTest(1);

	for (int i = 0; i < 4; i++) {
		if (gElementSlots.m_ElementEquiped[i].Active == 0) {
			continue;
		}

		RenderImage2(this->m_ElementEquiped[i].ImageID, *((DWORD *)pInventoryThis(pWindowThis()) + 9) + this->m_ElementEquiped[i].x
			, *((DWORD *)pInventoryThis(pWindowThis()) + 10) + this->m_ElementEquiped[i].y, this->m_ElementEquiped[i].width, this->m_ElementEquiped[i].height, 0, 0.0, 0.60, 0.60, 1, 1, 1.0);
	}

	DisableAlphaBlend();
}

__declspec(naked) void CElementSlots::RenderEquippedItem()
{
	static DWORD m_ReturnFunc = 0x008373A5;
	static DWORD m_CallFunc = 0x007DD0F0;

	_asm {
		Lea Ecx, gElementSlots;
		Call[CElementSlots::RenderEquippedItemSlot];
		CALL[m_CallFunc];
		JMP[m_ReturnFunc];
	}
}

int CheckCanEquipeItem(DWORD Struct) {
	if (gVisualInventory.CheckVisualOpen()) {
		gVisualInventory.CheckCanEquipItem(*(DWORD *)(Struct + 284));
		return 1;
	}

	if (*(DWORD *)(Struct + 284) >= 236) {
		auto itemObj = ((ITEM*(__thiscall*)(DWORD))0x7D9430)(((DWORD(*)())0x7DD0F0)());

		if (itemObj) {
			auto elementSlot = gElementSlots.getElement(*(DWORD *)(Struct + 284));
			auto itemAttr = pGetItemAttr(itemObj->Type);

			int StackEquiped = *(DWORD *)(Struct + 284) - 236;

			if (StackEquiped < 0) {
				StackEquiped = 0;
			}

			if (StackEquiped > 3) {
				StackEquiped = 3;
			}

			if (gElementSlots.m_ElementEquiped[StackEquiped].Active == 0) {
				return 0;
			}

			if (elementSlot != nullptr || (itemAttr != nullptr && itemAttr->m_byItemSlot != *(DWORD *)(Struct + 284))) {
				glColor4f(0.9f, 0.1f, 0.1f, 0.4f);

				EnableAlphaTest(1);

				pDrawBarForm(*((DWORD *)pInventoryThis(pWindowThis()) + 9) + gElementSlots.m_ElementEquiped[StackEquiped].x
					, *((DWORD *)pInventoryThis(pWindowThis()) + 10) + gElementSlots.m_ElementEquiped[StackEquiped].y, gElementSlots.m_ElementEquiped[StackEquiped].width, gElementSlots.m_ElementEquiped[StackEquiped].height, 0.0, 0);

				((void(*)())0x637A30)();
			}
		}

		return 1;
	}

	return 0;
}

__declspec(naked) void CElementSlots::RenderEquippedItem2()
{
	static DWORD m_CallFunc = 0x007DD0F0;
	static DWORD m_ReturnFunc = 0x008373C5;
	static DWORD m_ExitFunc = 0x00837542;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP - 0x1040];
		PUSH EAX;
		CALL[CheckCanEquipeItem];
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_ExitFunc];

	RETURN:
		CALL[m_CallFunc];
		JMP[m_ReturnFunc];
	}
}

BOOL CheckRenderItemToolTip(DWORD Struct) {
	if (*(DWORD *)(Struct + 284) == -1) {
		return 0;
	}

	if (gVisualInventory.CheckVisualOpen()) {
		gVisualInventory.RenderItemToolTip(*(DWORD *)(Struct + 284));
		return 1;
	}

	if (*(DWORD *)(Struct + 284) >= 236) {
		auto itemObj = gElementSlots.getItemElement(*(DWORD *)(Struct + 284));

		if (itemObj) {
			int StackEquiped = *(DWORD *)(Struct + 284) - 236;

			if (StackEquiped < 0) {
				StackEquiped = 0;
			}

			if (StackEquiped > 3) {
				StackEquiped = 3;
			}

			if (gElementSlots.m_ElementEquiped[StackEquiped].Active == 0) {
				return 0;
			}

			int EquipamentX = *((DWORD *)pInventoryThis(pWindowThis()) + 9) + gElementSlots.m_ElementEquiped[StackEquiped].x;
			int EquipamentY = *((DWORD *)pInventoryThis(pWindowThis()) + 10) + gElementSlots.m_ElementEquiped[StackEquiped].y;
			int EquipamentWidth = gElementSlots.m_ElementEquiped[StackEquiped].width;
			int EquipamentHeight = gElementSlots.m_ElementEquiped[StackEquiped].height;

			int iTargetX = EquipamentX + EquipamentWidth / 2;
			int iTargetY = EquipamentY + EquipamentHeight / 2;

			itemObj->bySelectedSlotIndex = *(DWORD *)(Struct + 284);

			((void(__thiscall*)(LPVOID, int, int, ITEM*, bool, int, bool))0x7E3E30)(((LPVOID(__thiscall*)(LPVOID This)) 0x861AA0)(pWindowThis()), iTargetX, iTargetY, itemObj, 0, 0, 0);
		}

		return 1;
	}

	return 0;
}

__declspec(naked) void CElementSlots::RenderItemToolTip()
{
	static DWORD m_ReturnFunc = 0x0083B87F;
	static DWORD m_ExitFunc = 0x0083B934;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP - 0x10];
		PUSH EAX;
		CALL[CheckRenderItemToolTip];
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_ExitFunc];

	RETURN:
		MOV EAX, DWORD PTR SS : [EBP - 0x10];
		MOV ECX, DWORD PTR SS : [EBP + 0x8]
		IMUL ECX, ECX, 0x6B

		JMP[m_ReturnFunc];
	}
}

void MyRenderItem3D() {
	for (int i = 236; i < 240; i++) {
		int StackEquiped = i - 236;

		if (StackEquiped < 0) {
			StackEquiped = 0;
		}

		if (StackEquiped > 3) {
			StackEquiped = 3;
		}

		if (gElementSlots.m_ElementEquiped[StackEquiped].Active == 0) {
			continue;
		}

		auto itemObj = gElementSlots.getItemElement(i);

		if (itemObj) {
			glColor4f(1.0, 1.0, 1.0, 1.0);

			((void(*)(float, float, float, float, int, int, int, int, bool))0x5CF310)((float)(*((DWORD *)pInventoryThis(pWindowThis()) + 9) + gElementSlots.m_ElementEquiped[StackEquiped].x)
				, (float)(*((DWORD *)pInventoryThis(pWindowThis()) + 10) + gElementSlots.m_ElementEquiped[StackEquiped].y)
				, (float)gElementSlots.m_ElementEquiped[StackEquiped].width
				, (float)gElementSlots.m_ElementEquiped[StackEquiped].height, itemObj->Type, itemObj->Level, itemObj->Option1, itemObj->ExtOption, 0);
		}
	}
}

int CheckRenderItensVisual() {
	if (gVisualInventory.CheckVisualOpen()) {
		gVisualInventory.Render3DItem();
		return 1;
	}

	return 0;
}

__declspec(naked) void CElementSlots::RenderItem3D()
{
	static DWORD m_ReturnFunc = 0x008353E0;
	static DWORD m_ExitFunc = 0x008354EC;

	_asm {
		CALL[CheckRenderItensVisual];
		TEST EAX, EAX;
		JE NORMAL_CALL;

		JMP[m_ExitFunc];

	NORMAL_CALL:
		CALL[MyRenderItem3D];
		MOV DWORD PTR SS : [EBP - 0x4], 0;
		JMP[m_ReturnFunc];
	}
}

int CheckUnequipItem(DWORD slot) {
	if (gVisualInventory.CheckVisualOpen()) {
		if (slot >= 240 && slot <= 248) {
			gVisualInventory.DeleteItem(slot);
			return 1;
		}
	}

	if (slot >= 236 && slot <= 239) {
		gElementSlots.DeleteItem(slot);
		return 1;
	}

	return 0;
}

__declspec(naked) void CElementSlots::UnequipItem()
{
	static DWORD m_ReturnFunc = 0x00833B2D;
	static DWORD m_HookFunc = 0x00833C5B;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8];
		PUSH EAX;
		CALL[CheckUnequipItem];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_HookFunc];

	RETURN:
		MOV DWORD PTR SS : [EBP - 0xC], ECX
		CMP DWORD PTR SS : [EBP + 0x8], 0x0
		JMP[m_ReturnFunc];
	}
}

int MyCheckPickedItem(DWORD Struct) {
	if (gVisualInventory.CheckVisualOpen()) {
		if (*(DWORD *)(Struct + 284) >= 240 && *(DWORD *)(Struct + 284) <= 248) {
			auto Item = gVisualInventory.getItem(*(DWORD *)(Struct + 284));

			if (Item) {
				if (((bool(*)(void*, ITEM*))0x7DD100)(nullptr, Item)) {
					gVisualInventory.Unequip(*(DWORD *)(Struct + 284));
				}
			}
			return 1;
		}
	}

	if (*(DWORD *)(Struct + 284) >= 236 && *(DWORD *)(Struct + 284) <= 239) {
		auto Item = gElementSlots.getItemElement(*(DWORD *)(Struct + 284));

		if (Item) {
			if (((bool(*)(void*, ITEM*))0x7DD100)(nullptr, Item)) {
				gElementSlots.Unequip(*(DWORD *)(Struct + 284));
			}
		}
		return 1;
	}

	return 0;
}

__declspec(naked) void CElementSlots::CheckPickItem()
{
	static DWORD m_ReturnFunc = 0x008380E0;
	static DWORD m_ExitFunc = 0x0083822B;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP - 0x10EC]
		PUSH EDX;
		CALL[MyCheckPickedItem];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_ExitFunc];

	RETURN:
		MOV EDX, DWORD PTR SS : [EBP - 0x10EC];
		JMP[m_ReturnFunc];
	}
}

int MyBackUpPickedItem(ITEM* itemObj) {
	if (gVisualInventory.CheckVisualOpen()) {
		if (itemObj->lineal_pos >= 240 && itemObj->lineal_pos <= 248) {
			gVisualInventory.AddItem(itemObj->lineal_pos, itemObj);

			((void(*)())0x007DD1B0)();
			return 1;
		}
	}

	if (itemObj->lineal_pos >= 236 && itemObj->lineal_pos <= 239) {
		gElementSlots.AddItem(itemObj->lineal_pos, itemObj);

		((void(*)())0x007DD1B0)();
		return 1;
	}
	return 0;
}

__declspec(naked) void CElementSlots::BackUpPickedItem()
{
	static DWORD m_ReturnFunc = 0x007DD2CD;
	static DWORD m_ExitFunc = 0x007DD472;

	static DWORD m_OldEax = 0x0;

	_asm {
		MOV m_OldEax, EAX;
		MOV EDX, DWORD PTR SS : [EBP - 0x14];
		PUSH EDX;
		CALL[MyBackUpPickedItem];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_ExitFunc];

	RETURN:
		MOV EAX, m_OldEax;
		MOV EDX, DWORD PTR SS : [EBP - 0x14];
		MOVZX EAX, BYTE PTR DS : [EDX + 0x43];
		JMP[m_ReturnFunc];
	}
}

int MyCheckEquipItem(DWORD Struct) {
	if (gVisualInventory.CheckVisualOpen()) {
		if (*(DWORD *)(Struct + 284) >= 240 && *(DWORD *)(Struct + 284) <= 248) {
			auto itemObj = gVisualInventory.getItem(*(DWORD *)(Struct + 284));

			if (itemObj == nullptr) {
				return 1;
			}
		}
	}

	if (*(DWORD *)(Struct + 284) >= 236 && *(DWORD *)(Struct + 284) <= 239) {
		auto itemObj = gElementSlots.getItemElement(*(DWORD *)(Struct + 284));

		if (itemObj == nullptr) {
			return 1;
		}
	}
	return 0;
}

__declspec(naked) void CElementSlots::CheckEquipItem()
{
	static DWORD m_ReturnFunc = 0x00837B55;
	static DWORD m_ExitFunc = 0x00837B86;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP - 0x10EC];
		PUSH EDX;
		CALL[MyCheckEquipItem];
		ADD ESP, 0x04;
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_ExitFunc];

	RETURN:
		MOV EDX, DWORD PTR SS : [EBP - 0x10EC];
		JMP[m_ReturnFunc];
	}
}


void CElementSlots::LoadImageSlot()
{
	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\slot_pet1.jpg", this->ImageNewSlot1, 0x2601, 0x2901, 1, 0);
	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\slot_pet2.jpg", this->ImageNewSlot2, 0x2601, 0x2901, 1, 0);
	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\slot_arete.jpg", this->ImageNewSlot3, 0x2601, 0x2901, 1, 0);
	((int(__cdecl*)(char * Folder, int Code, int Arg3, int Arg4, int Arg5, int Arg6)) 0x00772330)("Interface\\slot_arete2.jpg", this->ImageNewSlot4, 0x2601, 0x2901, 1, 0);
}

void CElementSlots::AddItem(BYTE slot, BYTE * ItemInfo)
{
	std::map<int, ELEMENT_SLOTS_INFO>::iterator it = this->m_ElementSlots.find(slot);

	if (it == this->m_ElementSlots.end()) {
		ELEMENT_SLOTS_INFO info;

		auto pTargetItemSlot = &info.pItemObj;
		auto pTempItem = ((ITEM*(__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemInfo);

		if (pTempItem == nullptr) {
			return;
		}

		pTempItem->lineal_pos = slot;

		pTempItem->ex_src_type = 1;

		memcpy(pTargetItemSlot, pTempItem, sizeof(ITEM));

		if (!this->AddDarkSpirit(pTempItem->Type)) {
			this->EffectPet(slot, pTempItem->Type);
		}

		((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), pTempItem);

		info.slot = slot;

		this->m_ElementSlots.insert(std::make_pair(slot, info));
	}
	else {
		auto pTargetItemSlot = &it->second.pItemObj;
		auto pTempItem = ((ITEM*(__thiscall*)(LPVOID, BYTE*))0x7E1B10)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), ItemInfo);

		if (pTempItem == nullptr) {
			return;
		}

		pTempItem->lineal_pos = slot;

		pTempItem->ex_src_type = 1;

		memcpy(pTargetItemSlot, pTempItem, sizeof(ITEM));

		if (!this->AddDarkSpirit(pTempItem->Type)) {
			this->EffectPet(slot, pTempItem->Type);
		}

		((void(__thiscall*)(LPVOID, ITEM*))0x7E1ED0)(((LPVOID(__thiscall*)(LPVOID))0x861240)(pWindowThis()), pTempItem);

		it->second.slot = slot;
	}
}

void CElementSlots::AddItem(BYTE slot, ITEM * itemObj)
{
	std::map<int, ELEMENT_SLOTS_INFO>::iterator it = this->m_ElementSlots.find(slot);

	if (it == this->m_ElementSlots.end()) {
		ELEMENT_SLOTS_INFO info;

		info.slot = slot;

		ITEM* pEquipmentItemSlot = &info.pItemObj;

		memcpy(pEquipmentItemSlot, itemObj, sizeof(ITEM));

		this->m_ElementSlots.insert(std::make_pair(slot, info));
	}
	else {
		it->second.slot = slot;

		ITEM* pEquipmentItemSlot = &it->second.pItemObj;

		memcpy(pEquipmentItemSlot, itemObj, sizeof(ITEM));
	}

	if (!this->AddDarkSpirit(itemObj->Type)) {
		this->EffectPet(slot, itemObj->Type);
	}
}

ELEMENT_SLOTS_INFO * CElementSlots::getElement(int slot)
{
	std::map<int, ELEMENT_SLOTS_INFO>::iterator it = this->m_ElementSlots.find(slot);

	if (it == this->m_ElementSlots.end()) {
		return nullptr;
	}

	return &it->second;
}

ITEM* CElementSlots::getItemElement(int slot)
{
	std::map<int, ELEMENT_SLOTS_INFO>::iterator it = this->m_ElementSlots.find(slot);

	if (it == this->m_ElementSlots.end()) {
		return nullptr;
	}

	return &it->second.pItemObj;
}

void CElementSlots::DeleteItem(int slot)
{
	std::map<int, ELEMENT_SLOTS_INFO>::iterator it = this->m_ElementSlots.find(slot);

	if (it == this->m_ElementSlots.end()) {
		return;
	}

	this->DeleteDarkSpirit(it->second.pItemObj.Type);

	this->DeleteEffectPets(slot);

	it->second.Clear();

	this->m_ElementSlots.erase(it);
}

void CElementSlots::Unequip(int slot)
{
	std::map<int, ELEMENT_SLOTS_INFO>::iterator it = this->m_ElementSlots.find(slot);

	if (it == this->m_ElementSlots.end()) {
		return;
	}

	this->DeleteDarkSpirit(it->second.pItemObj.Type);

	it->second.pItemObj.Type = -1;
	it->second.pItemObj.Level = 0;
	it->second.pItemObj.Number = -1;
	it->second.pItemObj.Option1 = 0;
	it->second.pItemObj.ExtOption = 0;

	this->DeleteEffectPets(slot);

	this->m_ElementSlots.erase(it);
}

void CElementSlots::EffectPet(int slot, int ItemIndex)
{
	auto hero = Hero;

	if (slot == 236) {
		if (gHelperSystem.CheckIsHelper(ItemIndex + ITEM_BASE_MODEL)) {
			gElementPetFirst.CreateHelper(ItemIndex, gHelperSystem.GetHelperModel(ItemIndex + ITEM_BASE_MODEL), hero->Object.Position, hero, 0);
		}
	}
	else if (slot == 237) {
		if (gHelperSystem.CheckIsHelper(ItemIndex + ITEM_BASE_MODEL)) {
			gElementPetSecond.CreateHelper(ItemIndex, gHelperSystem.GetHelperModel(ItemIndex + ITEM_BASE_MODEL), hero->Object.Position, hero, 0);
		}
	}
}

void CElementSlots::DeleteEffectPets(int slot)
{
	if (slot == 236) {
		gElementPetFirst.DeleteHelper(Hero);
	}
	else if (slot == 237) {
		gElementPetSecond.DeleteHelper(Hero);
	}
}

void CElementSlots::DeleteDarkSpirit(int ItemIndex)
{
	if (gDarkSpirit.checkIsDarkSpirit(ItemIndex)) {
		((void(*)(ObjectPreview*))0x4F94A0)(Hero);

		if (gDarkSpirit.CheckExistDarkSpirit(Hero)) {
			gDarkSpirit.DeleteDarkSpirit(Hero, -1, false);

			if (GetBaseClass((Hero)->Class) != 4) {
				for (int k = 0; k < 4; ++k) {
					*(WORD *)(*(DWORD*)0x8128AC8 + 2 * k + 420) = 0;
				}
			}
		}
	}
}

bool CElementSlots::AddDarkSpirit(int ItemIndex)
{
	if (gDarkSpirit.checkIsDarkSpirit(ItemIndex)) {
		auto hero = Hero;
		auto backupWeapon = hero->WeaponSecondSlot;

		hero->WeaponSecondSlot = ItemIndex + 1171;

		DWORD PetInfo = ((DWORD(*)(DWORD))0x4F9930)((DWORD)*(WORD*)(*(DWORD*)0x8128AC4 + 4779));

		((void(*)(ObjectPreview*))0x4F8B80)(hero);

		if (!((bool(*)(int))0x4E65A0)(pMapNumber)) {
			((void(__thiscall*)(DWORD*, DWORD))0x4FA780)((DWORD*)hero->m_pPet, PetInfo);
		}

		gDarkSpirit.CreateDarkSpirit(hero, hero->WeaponSecondSlot);

		hero->WeaponSecondSlot = backupWeapon;

		if (GetBaseClass((Hero)->Class) != 4) {
			for (int k = 0; k < 4; ++k) {
				*(WORD *)(*(DWORD*)0x8128AC8 + 2 * k + 420) = k + 120;
			}
		}

		return 1;
	}

	return 0;
}
