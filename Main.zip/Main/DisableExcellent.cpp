#include "stdafx.h"
#include "DisableExcellent.h"
#include "Util.h"
#include "LuaStack.hpp"

using namespace luaaa;

DisableExcellent gDisableExcellent;

DisableExcellent::DisableExcellent() : m_Lua(true)
{
	this->m_DisableExcellent.clear();
}

DisableExcellent::~DisableExcellent()
{
}

void SetDisableExcellent(int ItemIndex) {
	DISABLE_EXCELLENT_INFO info;

	info.ItemIndex;

	gDisableExcellent.m_DisableExcellent.insert(std::make_pair(ItemIndex, info));
}

void DisableExcellent::Init()
{
	MemorySet(0x0060EDB8, 0x90, 5);
	SetCompleteHook(0xE9, 0x0060EDB8, &this->DisableExcellentFunc);

	LuaModule(this->m_Lua.GetState()).fun("SetDisableExcellent", &SetDisableExcellent);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//DisableExcellent.lua");
}


void DisableExcellent::RestartLua()
{
	MemorySet(0x0060EDB8, 0x90, 5);
	SetCompleteHook(0xE9, 0x0060EDB8, &this->DisableExcellentFunc);

	LuaModule(this->m_Lua.GetState()).fun("SetDisableExcellent", &SetDisableExcellent);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//DisableExcellent.lua");
}

bool DisableExcellent::CanDisableExcellent(int ItemIndex)
{
	std::map<int, DISABLE_EXCELLENT_INFO>::iterator it = this->m_DisableExcellent.find(ItemIndex);

	if (it == this->m_DisableExcellent.end()) {
		return 0;
	}

	return 1;
}

int CheckDisableExcellent(int ItemIndex) {
	if (gDisableExcellent.CanDisableExcellent(ItemIndex)) {
		return 1;
	}

	return 0;
}

__declspec(naked) void DisableExcellent::DisableExcellentFunc()
{
	static DWORD m_ExitFunc = 0x0060F4E8;
	static DWORD m_ReturnFunc = 0x0060EDBD;
	static DWORD m_CallFunc1 = 0x00861110;
	static DWORD m_CallFunc2 = 0x00861620;
	static DWORD m_CallFunc3 = 0x00849EC0;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0xC];
		PUSH EDX;
		CALL[CheckDisableExcellent];
		TEST EAX, EAX;
		JE RETURN;

		JMP[m_ExitFunc];

	RETURN:
		PUSH 0x39;
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		JMP[m_ReturnFunc];
	}
}
