#include "stdafx.h"
#include "CustomItemValue.h"
#include "LuaStack.hpp"
#include "Util.h"
#include "CustomMessage.h"
#include "Descriptions.h"

using namespace luaaa;

CCustomItemValue gCustomItemValue;

CCustomItemValue::CCustomItemValue() : m_Lua(true)
{
	this->m_ItemValueInfo.clear();
}

CCustomItemValue::~CCustomItemValue()
{
	this->m_ItemValueInfo.clear();
}

void SetItemValue(int Index, int Level, int Grade, int BuyValue, int Coin1, int Coin2, int Coin3, int SellValue, int SellCoin1, int SellCoin2, int SellCoin3) {
	ITEM_VALUE_INFO info;

	info.Index = Index;

	info.Level = Level;

	info.Grade = Grade;

	info.BuyValue = BuyValue;

	info.Coin1 = Coin1;

	info.Coin2 = Coin2;

	info.Coin3 = Coin3;

	info.SellValue = SellValue;

	info.SellCoin1 = SellCoin1;

	info.SellCoin2 = SellCoin2;

	info.SellCoin3 = SellCoin3;

	gCustomItemValue.m_ItemValueInfo.push_back(info);
}

int CheckItemValueBuy(DWORD Line, DWORD itemObject) {

	auto itemObj = &*(ITEM*)itemObject;

	if (itemObj) {
		auto itemValue = gCustomItemValue.GetItemInfo(itemObj->Type, itemObj->Level/8&15, itemObj->ExtOption);

		if (itemValue) {
			char buffer[100];

			if (itemValue->Coin1 > 0) {
				sprintf_s(buffer, gCustomMessage.GetMessage(28), itemValue->Coin1);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (itemValue->Coin2 > 0) {
				sprintf_s(buffer, gCustomMessage.GetMessage(29), itemValue->Coin2);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (itemValue->Coin3 > 0) {
				sprintf_s(buffer, gCustomMessage.GetMessage(30), itemValue->Coin3);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (itemValue->BuyValue > 0) {
				sprintf_s(buffer, gCustomMessage.GetMessage(31), itemValue->BuyValue);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 2;
				textBold[Line] = 1;
				Line++;
			}

			memcpy(textLine[Line], "\n", 100);
			textColor[Line] = 4;
			textBold[Line] = 1;
			Line++;
		}
	}

	return Line;
}

int CheckItemValueSell(DWORD Line, DWORD itemObject) {
	auto itemObj = &*(ITEM*)itemObject;

	if (itemObj) {
		auto itemValue = gCustomItemValue.GetItemInfo(itemObj->Type, itemObj->Level / 8 & 15, itemObj->ExtOption);

		if (itemValue) {
			char buffer[100];

			if (itemValue->SellCoin1 > 0) {
				sprintf_s(buffer, gCustomMessage.GetMessage(32), itemValue->SellCoin1);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (itemValue->SellCoin2 > 0) {
				sprintf_s(buffer, gCustomMessage.GetMessage(33), itemValue->SellCoin2);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (itemValue->SellCoin3 > 0) {
				sprintf_s(buffer, gCustomMessage.GetMessage(34), itemValue->SellCoin3);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 6;
				textBold[Line] = 1;
				Line++;
			}

			if (itemValue->SellValue > 0) {
				sprintf_s(buffer, gCustomMessage.GetMessage(35), itemValue->SellValue);

				memcpy(textLine[Line], buffer, 100);
				textColor[Line] = 2;
				textBold[Line] = 1;
				Line++;
			}

			memcpy(textLine[Line], "\n", 100);
			textColor[Line] = 4;
			textBold[Line] = 1;
			Line++;
		}
	}
	return Line;
}

__declspec(naked) void PrintPlayerItemValue() {
	static DWORD m_HookFunc = 0x007E4443;
	static DWORD m_ReturnFunc = 0x007E44DD;
	static DWORD m_ExitFunc = 0x007E458F;

	_asm {
		CMP DWORD PTR SS : [EBP + 0x14], 0x0;
		JE RETURN;

		MOV ECX, DWORD PTR SS : [EBP + 0x10];
		PUSH ECX;
		MOV EAX, DWORD PTR SS : [EBP - 0x74];
		PUSH EAX;
		CALL[CheckItemValueBuy];
		CMP EAX, 0;
		JNZ EXIT;

		JMP[m_HookFunc];

	EXIT:
		MOV DWORD PTR SS : [EBP - 0x74], EAX;
		MOV ECX, DWORD PTR SS : [EBP - 0x68];
		ADD ECX, 1;
		MOV DWORD PTR SS : [EBP - 0x68], ECX;


		JMP[m_ExitFunc];

	RETURN:

		MOV ECX, DWORD PTR SS : [EBP + 0x10];
		PUSH ECX;
		MOV EAX, DWORD PTR SS : [EBP - 0x74];
		PUSH EAX;
		CALL[CheckItemValueSell];
		CMP EAX, 0;
		JNZ EXIT_SELL;

		JMP[m_ReturnFunc];

	EXIT_SELL:
		MOV DWORD PTR SS : [EBP - 0x74], EAX;
		MOV ECX, DWORD PTR SS : [EBP - 0x68];
		ADD ECX, 1;
		MOV DWORD PTR SS : [EBP - 0x68], ECX;
		JMP[m_ExitFunc];
	}
}

void CCustomItemValue::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetItemValue", &SetItemValue);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//ItemValue.lua");

	this->m_Lua.Generic_Call("StartLoadItemValue", "");

	SetCompleteHook(0xE9, 0x007E4439, &PrintPlayerItemValue);
}

ITEM_VALUE_INFO * CCustomItemValue::GetItemInfo(int ItemIndex, int Level, int ExtOption)
{
	for (auto &itemInfo : gCustomItemValue.m_ItemValueInfo) {
		if (itemInfo.Index == ItemIndex) {
			if (itemInfo.Level == Level && itemInfo.Grade == ExtOption)
			{
				return &itemInfo;
			}

			if (itemInfo.Level == Level && itemInfo.Grade == -1)
			{
				return &itemInfo;
			}

			if (itemInfo.Level == -1 && itemInfo.Grade == ExtOption)
			{
				return &itemInfo;
			}

			if (itemInfo.Level == -1 || itemInfo.Level == Level)
			{
				if (itemInfo.Grade == -1 || itemInfo.Grade == ExtOption)
				{
					return &itemInfo;
				}
			}
		}
	}

	return 0;
}
