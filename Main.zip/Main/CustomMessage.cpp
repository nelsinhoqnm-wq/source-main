// CustomJewel.cpp: implementation of the CCustomJewel class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CustomMessage.h"
#include "Offset.h"

CCustomMessage gCustomMessage;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCustomMessage::CCustomMessage() : m_Lua(true) // OK
{
	memset(this->m_DefaultMessage, 0, sizeof(this->m_DefaultMessage));

	for (int n = 0; n < MAX_CUSTOM_MESSAGE; n++)
	{
		this->m_EngCustomMessageInfo[n].Index = -1;
		this->m_PorCustomMessageInfo[n].Index = -1;
		this->m_SpnCustomMessageInfo[n].Index = -1;
	}
}

CCustomMessage::~CCustomMessage() // OK
{

}

void CCustomMessage::Init() // OK
{
	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomMessage.lua");

	this->LoadEng();

	this->LoadPor();

	this->LoadSpn();
}

static BOOL LuaSetEngMsg(lua_State* Lua)
{
	CUSTOM_MESSAGE_INFO info;

	info.Index = (int)lua_tonumber(Lua, 1);

	strcpy_s(info.Message, lua_tostring(Lua, 2));

	lua_pop(Lua, 2);

	gCustomMessage.m_EngCustomMessageInfo[info.Index] = info;
	return true;
};

void CCustomMessage::LoadEng() // OK
{
	lua_register(m_Lua.GetState(), "SetEngMsg", LuaSetEngMsg);

	m_Lua.Generic_Call("LoadEngMessage", ">");
}

static BOOL LuaSetPorMsg(lua_State* Lua)
{
	CUSTOM_MESSAGE_INFO info;

	info.Index = (int)lua_tonumber(Lua, 1);

	strcpy_s(info.Message, lua_tostring(Lua, 2));

	lua_pop(Lua, 2);

	gCustomMessage.m_PorCustomMessageInfo[info.Index] = info;
	return true;
};

void CCustomMessage::LoadPor() // OK
{
	lua_register(m_Lua.GetState(), "SetPorMsg", LuaSetPorMsg);

	m_Lua.Generic_Call("LoadPorMessage", ">");
}

static BOOL LuaSetSpnMsg(lua_State* Lua)
{
	CUSTOM_MESSAGE_INFO info;

	info.Index = (int)lua_tonumber(Lua, 1);

	strcpy_s(info.Message, lua_tostring(Lua, 2));

	lua_pop(Lua, 2);

	gCustomMessage.m_SpnCustomMessageInfo[info.Index] = info;
	return true;
};

void CCustomMessage::LoadSpn() // OK
{
	lua_register(m_Lua.GetState(), "SetSpnMsg", LuaSetSpnMsg);

	m_Lua.Generic_Call("LoadSpnMessage", ">");
}

CUSTOM_MESSAGE_INFO* CCustomMessage::GetInfoEng(int index) // OK
{
	if(index < 0 || index >= MAX_CUSTOM_MESSAGE)
	{
		wsprintf(this->m_DefaultMessage,"Message %d out of bound!",index);
		return 0;
	}

	if(this->m_EngCustomMessageInfo[index].Index != index)
	{
		wsprintf(this->m_DefaultMessage,"Could not find message %d!",index);
		return 0;
	}

	return &this->m_EngCustomMessageInfo[index];
}

CUSTOM_MESSAGE_INFO* CCustomMessage::GetInfoPor(int index) // OK
{
	if(index < 0 || index >= MAX_CUSTOM_MESSAGE)
	{
		wsprintf(this->m_DefaultMessage,"Message %d out of bound!",index);
		return 0;
	}

	if(this->m_PorCustomMessageInfo[index].Index != index)
	{
		wsprintf(this->m_DefaultMessage,"Could not find message %d!",index);
		return 0;
	}

	return &this->m_PorCustomMessageInfo[index];
}

CUSTOM_MESSAGE_INFO* CCustomMessage::GetInfoSpn(int index) // OK
{
	if(index < 0 || index >= MAX_CUSTOM_MESSAGE)
	{
		wsprintf(this->m_DefaultMessage,"Message %d out of bound!",index);
		return 0;
	}

	if(this->m_SpnCustomMessageInfo[index].Index != index)
	{
		wsprintf(this->m_DefaultMessage,"Could not find message %d!",index);
		return 0;
	}

	return &this->m_SpnCustomMessageInfo[index];
}

char* CCustomMessage::GetMessage(int index) // OK
{
	if(strcmp((char*)MAIN_LANGUAGE,"Eng") == 0)
	{
		CUSTOM_MESSAGE_INFO* lpInfo = this->GetInfoEng(index);
		if(lpInfo==0){return this->m_DefaultMessage;}
		return lpInfo->Message;
	}

	if(strcmp((char*)MAIN_LANGUAGE,"Por") == 0)
	{
		CUSTOM_MESSAGE_INFO* lpInfo = this->GetInfoPor(index);
		if(lpInfo==0){return this->m_DefaultMessage;}
		return lpInfo->Message;
	}

	if(strcmp((char*)MAIN_LANGUAGE,"Spn") == 0)
	{
		CUSTOM_MESSAGE_INFO* lpInfo = this->GetInfoSpn(index);
		if(lpInfo==0){return this->m_DefaultMessage;}
		return lpInfo->Message;
	}

	CUSTOM_MESSAGE_INFO* lpInfo = this->GetInfoEng(index);
	if(lpInfo==0){return this->m_DefaultMessage;}
	return lpInfo->Message;
}
