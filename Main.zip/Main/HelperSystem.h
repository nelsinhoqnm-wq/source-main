#pragma once

#include "Lua.h"
#include "LuaEffects.h"
#include "LuaBMD.h"

class HELPER_INFO {
public:
	HELPER_INFO() {
		this->ItemIndex = -1;
	};

	~HELPER_INFO() {

	};

	int ItemIndex;
	int Type;
	int Movement;
	float HeightFloor;
	float Size;
	float SizeCharList;
	char Model[32];
	char ObjectModel[32];
	int ModelID;
	int Miniature;
	float SizeMiniature;
	float VelocityMiniature;
};

struct HELPER_EFFECT_INFO {
	int EffectType; 
	int EffectIndex; 
	int EffectLevel; 
	int Skeleton; 
	float Size; 
	float LightR; 
	float LightG; 
	float LightB;
	float PosX; 
	float PosY; 
	float PosZ;
};

struct HELPER_EFFECT_MAIN {
	std::vector<HELPER_EFFECT_INFO> m_Effect;
};

class CHelperSystem {
public:
	CHelperSystem();
	~CHelperSystem();

	void Init();
	void RestartLua();
	int GetHelperModel(int ItemIndex);
	bool CheckIsHelper(int ItemIndex);
	bool CheckHelperType(int ItemIndex, int value);
	int GetModelComplete(int Index);
	HELPER_INFO * GetHelper(int ItemIndex);

	void RenderEffectHelper(DWORD BMDStruct, DWORD ObjectStruct, DWORD Type, short InSafeZone = 0);

public:
	std::map<int, HELPER_INFO> m_HelperInfo;
	std::map<int, HELPER_EFFECT_MAIN> m_HelperEffectInfo;

public:
	Lua m_Lua;
	CLuaEffects m_LuaEffects;
	LuaBMD m_LuaBMD;
};

extern CHelperSystem gHelperSystem;