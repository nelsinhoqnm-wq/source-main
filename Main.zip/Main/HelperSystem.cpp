#include "stdafx.h"
#include "HelperSystem.h"
#include "HelperManager.h"
#include "LuaStack.hpp"
#include "LuaBMD.h"
#include "LuaEffects.h"
#include "LuaObject.h"
#include "Item.h"
#include "LoadFiles.h"
#include "Console.h"

using namespace luaaa;
CHelperSystem gHelperSystem;

CHelperSystem::CHelperSystem() : m_Lua(false)
{
	this->m_HelperInfo.clear();
	this->m_HelperEffectInfo.clear();
}

CHelperSystem::~CHelperSystem()
{
	//this->m_HelperInfo.clear();
}

void SetHelper(int ItemIndex, int Type, int Movement, float Height, float Size, float SizeCharList, int miniature, float sizeMiniature, float velocityMiniature, std::string Model, std::string ObjectModel) {
	auto it = gHelperSystem.m_HelperInfo.find(ItemIndex);

	if (it != gHelperSystem.m_HelperInfo.end()) {
		return;
	}

	HELPER_INFO info;

	info.ItemIndex = ItemIndex;

	info.Type = (Type == 1 ? 2 : Type == 2 ? 4 : Type == 3 ? 8 : Type == 4 ? 16 : Type);

	info.Movement = Movement;

	info.HeightFloor = Height;

	info.Size = Size;

	info.SizeCharList = SizeCharList;

	info.Miniature = miniature;

	info.SizeMiniature = sizeMiniature;

	info.VelocityMiniature = velocityMiniature;

	strcpy_s(info.Model, Model.c_str());

	strcpy_s(info.ObjectModel, ObjectModel.c_str());

	gHelperSystem.m_HelperInfo.insert(std::make_pair(ItemIndex, info));
};

void SetEffectHelperMiniature(int ItemIndex, int EffectType, int EffectIndex, int EffectLevel, int Skeleton, float Size, float LightR, float LightG, float LightB, float PosX, float PosY, float PosZ) {
	HELPER_EFFECT_INFO info;

	info.EffectType = EffectType;
	info.EffectIndex = EffectIndex;
	info.EffectLevel = EffectLevel;
	info.Skeleton = Skeleton;
	info.Size = Size;
	info.LightR = LightR;
	info.LightG = LightG;
	info.LightB = LightB;
	info.PosX = PosX;
	info.PosY = PosY;
	info.PosZ = PosZ;

	auto Effect = gHelperSystem.m_HelperEffectInfo.find(ItemIndex);

	if (Effect == gHelperSystem.m_HelperEffectInfo.end()) {
		HELPER_EFFECT_MAIN effectMain;

		effectMain.m_Effect.push_back(info);

		gHelperSystem.m_HelperEffectInfo.insert(std::make_pair(ItemIndex, effectMain));
	}
	else {
		Effect->second.m_Effect.push_back(info);
	}
}

void SetEffectHelper(int ItemIndex, int EffectType, int EffectIndex, int EffectLevel, int Skeleton, float Size, float LightR, float LightG, float LightB, float PosX, float PosY, float PosZ) {
	HELPER_EFFECT_INFO info;

	info.EffectType = EffectType;
	info.EffectIndex = EffectIndex;
	info.EffectLevel = EffectLevel;
	info.Skeleton = Skeleton;
	info.Size = Size;
	info.LightR = LightR;
	info.LightG = LightG;
	info.LightB = LightB;
	info.PosX = PosX;
	info.PosY = PosY;
	info.PosZ = PosZ;

	auto Effect = gHelperSystem.m_HelperEffectInfo.find(ItemIndex);

	if (Effect == gHelperSystem.m_HelperEffectInfo.end()) {
		HELPER_EFFECT_MAIN effectMain;

		effectMain.m_Effect.push_back(info);

		gHelperSystem.m_HelperEffectInfo.insert(std::make_pair(ItemIndex, effectMain));
	}
	else {
		Effect->second.m_Effect.push_back(info);
	}
}

int CheckModelById(int ItemIndex) {
	return gHelperSystem.GetHelperModel(ItemIndex);
}

bool CHelperSystem::CheckIsHelper(int ItemIndex)
{
	for (std::map<int, HELPER_INFO>::iterator it = this->m_HelperInfo.begin(); it != this->m_HelperInfo.end(); ++it)
	{
		if (it->second.ItemIndex == ItemIndex || it->second.ModelID == ItemIndex) {
			return 1;
		}
	}

	return 0;
}

bool CHelperSystem::CheckHelperType(int ItemIndex, int value)
{
	for (std::map<int, HELPER_INFO>::iterator it = this->m_HelperInfo.begin(); it != this->m_HelperInfo.end(); ++it)
	{
		if (it->second.ItemIndex == ItemIndex || it->second.ModelID == ItemIndex) {
			return (it->second.Type & value) == value;
		}
	}

	return 0;
}

int CHelperSystem::GetModelComplete(int Index)
{
	for (std::map<int, HELPER_INFO>::iterator it = this->m_HelperInfo.begin(); it != this->m_HelperInfo.end(); ++it)
	{
		if (it->second.ItemIndex == Index || it->second.ModelID == Index) {
			return it->second.ItemIndex;
		}
	}

	return 0;
}

int CHelperSystem::GetHelperModel(int ItemIndex)
{
	std::map<int, HELPER_INFO>::iterator it = this->m_HelperInfo.find(ItemIndex);

	if (it == this->m_HelperInfo.end()) {
		return 0;
	}

	if (it->second.Type == 0) {
		return it->second.ItemIndex;
	}
	else {
		return it->second.ModelID;
	}
}

HELPER_INFO* CHelperSystem::GetHelper(int ItemIndex) {
	for (std::map<int, HELPER_INFO>::iterator it = this->m_HelperInfo.begin(); it != this->m_HelperInfo.end(); ++it)
	{
		if (it->second.ItemIndex == ItemIndex || it->second.ModelID == ItemIndex) {
			return &it->second;
		}
	}

	return 0;
}

void CHelperSystem::RenderEffectHelper(DWORD BMDStruct, DWORD ObjectStruct, DWORD Type, short InSafeZone)
{
	auto effectInfo = this->m_HelperEffectInfo.find(this->GetModelComplete(Type));

	if (effectInfo == this->m_HelperEffectInfo.end()) {
		return;
	}

	auto obj = (ObjectModel*)ObjectStruct;

	if (obj == nullptr) {
		return;
	}

	for (auto it = std::begin(effectInfo->second.m_Effect); it != std::end(effectInfo->second.m_Effect); ++it) {
		vec3_t vPos, pos;

		Vector(it->PosX, it->PosY, it->PosZ, vPos);
		((void(__thiscall*)(void*, float(*Matrix)[4], vec3_t Position, vec3_t WorldPosition, bool Translate))0x545030)((void*)BMDStruct, BoneTransform[it->Skeleton], vPos, pos, 0);

		vec3_t Light;
		Vector(it->LightR, it->LightG, it->LightB, Light);

		//EFEITO DENTRO DA CIDADE
		float EffectSize = (InSafeZone == 1 ? (it->Size / 2) : it->Size);

		if (it->EffectType == 0)
		{
			((void(*)(int, vec3_t, float, vec3_t, ObjectModel*, float, int))0x771310)(it->EffectIndex, pos, EffectSize, Light, obj, 0.0, 0);
		}
		else if (it->EffectType == 1)
		{
			((void(*)(int, vec3_t, vec3_t, vec3_t, int, float, ObjectModel*))0x74CD30)(it->EffectIndex, pos, obj->Angle, Light, it->EffectLevel, EffectSize, obj);
		}
		else if (it->EffectType == 2)
		{
			((void(*)(int, vec3_t, vec3_t,
				vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
				float, int))0x6D9070)(it->EffectIndex, (it->Skeleton == -1 ? obj->Position : pos), obj->Angle, Light, it->EffectLevel, obj, -1, 0, 0, 0, 0.0, -1);
		}
	}
}

__declspec(naked) void DeleteEquippingEffectBug() {
	static DWORD m_Returnfunc = 0x008363DF;
	static DWORD m_HookFunc = 0x0083640B;
	static DWORD m_Index = 0;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 8] ;
		MOVSX ECX, WORD PTR DS : [EAX] ;
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckIsHelper(m_Index + ITEM_BASE_MODEL)) {
		gHelperManager.DeleteHelper(Hero);

		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 8] ;
			MOVSX ECX, WORD PTR DS : [EAX] ;
			JMP[m_Returnfunc];
		}
	}
}

void InvCreateEquippingEffect(DWORD ItemIndex) {
	auto hero = Hero;

	gHelperManager.CreateHelper(ItemIndex, gHelperSystem.GetHelperModel(hero->PetSlot), hero->Object.Position, hero, 0);

	if (!hero->InSafeZone && gHelperSystem.CheckHelperType(hero->PetSlot, 0) != 1) {
		((void(*)(int, vec3_t, vec3_t,
			vec3_t, int, ObjectModel*, short, WORD, WORD, WORD,
			float, int))0x6D9070)(32141, hero->Object.Position, hero->Object.Angle, hero->Object.Light, 1, &hero->Object, -1, 0, 0, 0, 0.0, -1);
	}
}

__declspec(naked) void CreateEquippingEffect() {
	static DWORD m_Returnfunc = 0x00835E8C;
	static DWORD m_HookFunc = 0x0083624D;
	static DWORD m_Index = 0;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EDX, WORD PTR DS : [ECX] ;
		MOV DWORD PTR SS : [EBP - 0xC] , EDX;
		MOV EAX, DWORD PTR SS : [EBP - 0xC] ;

		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckIsHelper(m_Index + ITEM_BASE_MODEL)) {
		InvCreateEquippingEffect(m_Index);

		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EDX, WORD PTR DS : [ECX] ;
			MOV DWORD PTR SS : [EBP - 0xC] , EDX;
			MOV EAX, DWORD PTR SS : [EBP - 0xC] ;
			JMP[m_Returnfunc];
		}
	}
}

__declspec(naked) void RenderEquipedHelperLife() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x007DFE5E;
	static DWORD m_HookFunc = 0x007E0082;

	_asm {
		MOV EDX, DWORD PTR DS : [0x7BC4F04]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckIsHelper(m_Index)) {
		_asm {
			MOV ECX, DWORD PTR DS : [0x7BC4F04]
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C]
			SUB EDX, 0x493
			IMUL EDX, EDX, 0x54
			ADD EDX, DWORD PTR DS : [0x8128AC0]
			MOV DWORD PTR SS : [EBP - 0x10C] , EDX
			MOV EAX, DWORD PTR SS : [EBP - 0x10C]
			PUSH EAX;
			LEA ECX, DWORD PTR SS : [EBP - 0x108] ;
			PUSH ECX;
			CALL[sprintf];
			ADD ESP, 0x8

				JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR DS : [0x7BC4F04]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void RenderCharacterWindowFixDinorant() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x004D72F2;
	static DWORD m_HookFunc = 0x004D72FA;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP - 0x38] ;
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
		MOV m_Index, EDX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP - 0x38] ;
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

void SetActionBloodAttack(ObjectPreview* c, ObjectModel* o) {
	if (c->PetSlot == GET_ITEM_MODEL(13, 2) || gHelperSystem.CheckHelperType(c->PetSlot, 2)) {
		SetCurrentAction(o, 173, 1);
	}
	else if (c->PetSlot == GET_ITEM_MODEL(13, 3) || gHelperSystem.CheckHelperType(c->PetSlot, 4)) {
		SetCurrentAction(o, 174, 1);
	}
	else if (c->PetSlot == GET_ITEM_MODEL(13, 37) || gHelperSystem.CheckHelperType(c->PetSlot, 8)) {
		SetCurrentAction(o, 175, 1);
	}
	else {
		SetCurrentAction(o, 172, 1);
	}
}

__declspec(naked) void SetPlayerStopFenrir() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0054EAD2;
	static DWORD m_HookFunc = 0x0054EADE;
	static DWORD m_SetRavenMovement = 0x0054ED28;
	static DWORD m_PreviewStruct = 0;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOV m_PreviewStruct, EAX;
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			MOV m_Index, ECX;
	}

	if (*(BYTE*)(m_PreviewStruct + 14) && *(DWORD*)(m_PreviewStruct + 676) != 0 && GetBaseClass(*(BYTE*)(m_PreviewStruct + 19)) == 4 && !((bool(*)(int))0x4E65A0)(pMapNumber)) {
		_asm {
			JMP[m_SetRavenMovement];
		}
	}
	else if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerStopDinorant() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0054ED5F;
	static DWORD m_HookFunc = 0x0054ED6A;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerStopHorse() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0054EC99;
	static DWORD m_HookFunc = 0x0054ECA0;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C] ;
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerStopUniria() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0054ED4D;
	static DWORD m_HookFunc = 0x0054ED6A;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerWalkingFenrir() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0054F8F4;
	static DWORD m_HookFunc = 0x0054F91A;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
		MOV m_Index, EDX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerWalkingFenrir2() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0054FC87;
	static DWORD m_HookFunc = 0x0054FC8F;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C]
		MOV m_Index, EDX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerWalkingFenrir3() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00550710;
	static DWORD m_HookFunc = 0x00550740;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerWalkingDinorant() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0054FE2F;
	static DWORD m_HookFunc = 0x0054FE3B;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C] ;
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerWalkingHorse() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0054FCE2;
	static DWORD m_HookFunc = 0x0054FCE9;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerWalkingHorse2() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005506CC;
	static DWORD m_HookFunc = 0x005506D4;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerReturnAction() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005A3844;
	static DWORD m_HookFunc = 0x005A3976;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
		MOV m_Index, EDX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 8) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetUnknowUniriaDino() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005517AE;
	static DWORD m_HookFunc = 0x005517C7;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C] ;
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerAttackFenrir() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00551920;
	static DWORD m_HookFunc = 0x0055192B;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerAttackDinoUniria() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00551B49;
	static DWORD m_HookFunc = 0x00551D62;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C]
		MOV m_Index, EDX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerAttackHorse() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00551B13;
	static DWORD m_HookFunc = 0x00551B1A;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerMagicDinoUniria() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0055273E;
	static DWORD m_HookFunc = 0x00552757;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C] ;
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

int CheckIsFenrirOrDino(int m_Index) {
	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		return 1;
	}

	return 0;
}

__declspec(naked) void SetPlayerSockUniDinoHorse() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00552777;
	static DWORD m_HookFunc = 0x00552757;
	static DWORD m_HookFunc2 = 0x00552789;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C] ;
		MOV m_Index, EAX;
	}

	if (m_Index == GET_ITEM_MODEL(13, 2) || m_Index == GET_ITEM_MODEL(13, 3)
		|| CheckIsFenrirOrDino(m_Index) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc2];
		}
	}
	else {
		_asm {
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerSockFenrir() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0055299F;
	static DWORD m_HookFunc = 0x005529A6;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerSockHorse() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005528E8;
	static DWORD m_HookFunc = 0x00552CD8;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetPlayerMagicFenrir() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00552781;
	static DWORD m_HookFunc = 0x00552789;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C] ;
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8)) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetCharacterMoveSpeedDinoUni() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00564CA6;
	static DWORD m_HookFunc = 0x00564CAD;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetCharacterMoveSpeedFenrir() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00564BAC;
	static DWORD m_HookFunc = 0x00564BB4;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetCharacterMoveSpeedHorse() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00564C26;
	static DWORD m_HookFunc = 0x00564C2D;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetCharacterPositionDino() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00564E78;
	static DWORD m_HookFunc = 0x00564E80;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8]
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C]
		MOV m_Index, EDX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8]
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetRenderCharacterUniDino() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0056F692;
	static DWORD m_HookFunc = 0x0056F6AC;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
		MOV m_Index, EDX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetCharacterPointerDino() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0057E112;
	static DWORD m_HookFunc = 0x0057E119;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C] ;
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetAttackMounts() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005B5409;
	static DWORD m_HookFunc = 0x005B544C;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 8) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetSummonerAttackMount() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0059B663;
	static DWORD m_HookFunc = 0x0059B6E4;

	_asm {
		MOV EDX, DWORD PTR DS : [0x7BC4F04]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 8) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR DS : [0x7BC4F04]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetActionMounts() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005A3821;
	static DWORD m_HookFunc = 0x005A3976;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 8) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetTeleportDino() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0063EDD2;
	static DWORD m_HookFunc = 0x0063EDDA;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP - 0x14]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP - 0x14]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetTeleportDino2() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00640A96;
	static DWORD m_HookFunc = 0x00640A9D;

	_asm {
		MOV EDX, DWORD PTR DS : [0x7BC4F04]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR DS : [0x7BC4F04]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetTeleportDino3() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00640DDB;
	static DWORD m_HookFunc = 0x00640DE3;

	_asm {
		MOV EAX, DWORD PTR DS : [0x7BC4F04]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 4) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR DS : [0x7BC4F04]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetDisableDefenseSkillMount() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00813F67;
	static DWORD m_HookFunc = 0x00813FEC;

	_asm {
		MOV EDX, DWORD PTR DS : [0x7BC4F04]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, EAX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 8) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR DS : [0x7BC4F04]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetDisableDefenseSkillMount2() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005B541B;
	static DWORD m_HookFunc = 0x005B544C;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 2) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 4) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 8) == 1 ||
		gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void FixRavenWalk() {
	static DWORD m_ReturnFunc = 0x0054FD18;
	static DWORD m_HookFunc = 0x0054FD2B;
	static DWORD m_PreviewStruct = 0;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
		MOV m_PreviewStruct, ECX;
	}

	if (*(BYTE*)(m_PreviewStruct + 14) && *(DWORD*)(m_PreviewStruct + 676) != 0 && !((bool(*)(int))0x4E65A0)(pMapNumber)) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else if (*(BYTE*)(m_PreviewStruct + 14) && *(DWORD*)(m_PreviewStruct + 676) != 0 && GetBaseClass(*(BYTE*)(m_PreviewStruct + 19)) == 4 && !((bool(*)(int))0x4E65A0)(pMapNumber)) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
			MOVSX EDX, WORD PTR DS : [ECX + 0x1E4] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void FixReceiveActionInCity() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x0064452A;
	static DWORD m_HookFunc = 0x00644537;
	static ObjectPreview* m_PreviewStruct = 0;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8] ;
		MOV m_PreviewStruct, ECX;
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
		MOV m_Index, EDX;

		MOV DWORD PTR SS : [EBP - 0x8] , EAX;
		MOV ECX, DWORD PTR SS : [EBP - 0x14] ;
		MOV m_PreviewStruct, ECX;
		MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
	}

	if (m_PreviewStruct != 0) {
		if ((m_PreviewStruct->PetSlot == GET_ITEM_MODEL(13, 4) || gHelperSystem.CheckHelperType(m_PreviewStruct->PetSlot, 16) == 1) && m_PreviewStruct->InSafeZone) {
			_asm {
				MOV DWORD PTR SS : [EBP - 0x8] , EAX;
				MOV ECX, DWORD PTR SS : [EBP - 0x14] ;
				MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
				JMP[m_HookFunc];
			}
		}
		else {
			_asm {
				MOV DWORD PTR SS : [EBP - 0x8] , EAX;
				MOV ECX, DWORD PTR SS : [EBP - 0x14] ;
				MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
				JMP[m_ReturnFunc];
			}
		}
	}
	else {
		_asm {
			MOV DWORD PTR SS : [EBP - 0x8] , EAX;
			MOV ECX, DWORD PTR SS : [EBP - 0x14] ;
			MOVSX EDX, WORD PTR DS : [ECX + 0x22C] ;
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetSkillFenrirChaotic() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00648DB6;
	static DWORD m_HookFunc = 0x00648DBE;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP - 0x18]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP - 0x18]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetSkillHorseChaotic() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x00648DEC;
	static DWORD m_HookFunc = 0x00648DF3;

	_asm {
		MOV EDX, DWORD PTR SS : [EBP - 0x18]
		MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
		MOV m_Index, ECX;
	}

	if (m_Index >= GET_ITEM_MODEL(13, 2) && m_Index <= GET_ITEM_MODEL(13, 4)
		|| gHelperSystem.CheckHelperType(m_Index, 2) == 1
		|| gHelperSystem.CheckHelperType(m_Index, 4) == 1
		|| gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, DWORD PTR SS : [EBP - 0x18]
			MOVSX EAX, WORD PTR DS : [EDX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetSkillFenrirChaoticAttack() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005AE1E7;
	static DWORD m_HookFunc = 0x005AE1EF;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (gHelperSystem.CheckHelperType(m_Index, 8) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void SetSkillHorseChaoticAttack() {
	static DWORD m_Index = 0;
	static DWORD m_ReturnFunc = 0x005AE20B;
	static DWORD m_HookFunc = 0x005AE224;

	_asm {
		MOV EAX, DWORD PTR SS : [EBP + 0x8]
		MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
		MOV m_Index, ECX;
	}

	if (m_Index >= GET_ITEM_MODEL(13, 2) && m_Index <= GET_ITEM_MODEL(13, 4)
		|| gHelperSystem.CheckHelperType(m_Index, 2) == 1
		|| gHelperSystem.CheckHelperType(m_Index, 4) == 1
		|| gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, DWORD PTR SS : [EBP + 0x8]
			MOVSX ECX, WORD PTR DS : [EAX + 0x22C]
			JMP[m_ReturnFunc];
		}
	}
}

__declspec(naked) void FixRavenUnequipChar() {
	static DWORD m_ExitFunc = 0x0054ED43;
	static DWORD m_HookFunc = 0x0054ED13;

	_asm {

		MOV EDX, DWORD PTR SS : [EBP + 0x8]
		CMP DWORD PTR DS : [EDX + 0x2A4] , 0
		JE RETURN

		JMP[m_HookFunc];

	RETURN:
		JMP[m_ExitFunc]
	}
}

__declspec(naked) void HorseSkill() {
	static DWORD m_ExitFunc = 0x005AFF59;
	static DWORD m_HookFunc = 0x005AF27A;

	static DWORD m_Index = 0;

	_asm {
		MOV m_Index, EAX;
	}

	if (m_Index == GET_ITEM_MODEL(13, 4) || gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			MOV EAX, m_Index;
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EAX, m_Index;
			JMP[m_ExitFunc];
		}
	}
}

__declspec(naked) void HorseSkillIcon() {
	static DWORD m_ExitFunc = 0x008140D7;
	static DWORD m_HookFunc = 0x008140DB;
	static DWORD m_Index = 0;

	_asm {
		MOV m_Index, ECX;
	}

	if (m_Index == GET_ITEM_MODEL(13, 4) || gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			MOV ECX, m_Index;
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV ECX, m_Index;
			JMP[m_ExitFunc];
		}
	}
}

__declspec(naked) void HorseSkill2() {
	static DWORD m_ExitFunc = 0x0059C7F1;
	static DWORD m_HookFunc = 0x0059CB07;
	static DWORD m_Index = 0;

	_asm {
		MOV m_Index, EDX;
	}

	if (m_Index == GET_ITEM_MODEL(13, 4) || gHelperSystem.CheckHelperType(m_Index, 16) == 1) {
		_asm {
			MOV EDX, m_Index;
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			MOV EDX, m_Index;
			JMP[m_ExitFunc];
		}
	}
}

void CHelperSystem::RestartLua()
{
	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());

	this->m_LuaEffects.RegisterLuaClass(this->m_Lua.GetState());

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//CharacterHelper.lua");

	this->m_Lua.Generic_Call("LoadHelpers", ">");


	SetCompleteHook(0xE9, 0x008363D9, &DeleteEquippingEffectBug);

	SetCompleteHook(0xE9, 0x00835E80, &CreateEquippingEffect);


}

void CHelperSystem::Init()
{
	this->m_LuaBMD.RegisterClassBMD(this->m_Lua.GetState());

	RegisterClassObject(this->m_Lua.GetState());

	this->m_LuaEffects.RegisterLuaClass(this->m_Lua.GetState());

	LuaModule(this->m_Lua.GetState()).fun("SetHelper", &SetHelper);

	LuaModule(this->m_Lua.GetState()).fun("SetEffectHelper", &SetEffectHelper);

	LuaModule(this->m_Lua.GetState()).fun("SetEffectHelperMiniature", &SetEffectHelperMiniature);

	LuaModule(this->m_Lua.GetState()).fun("CheckModelById", &CheckModelById);

	this->m_Lua.DoFile("Data//Files//Lua//CharacterSystem//CharacterHelper.lua");

	this->m_Lua.Generic_Call("LoadHelpers", ">");

	gHelperManager.Init();

	SetCompleteHook(0xE9, 0x008363D9, &DeleteEquippingEffectBug);

	SetCompleteHook(0xE9, 0x00835E80, &CreateEquippingEffect);

	SetCompleteHook(0xE9, 0x007DFE51, &RenderEquipedHelperLife);

	SetCompleteHook(0xE9, 0x004D72EB, &RenderCharacterWindowFixDinorant);

	SetCompleteHook(0xE8, 0x00534C65, &SetActionBloodAttack);

	SetCompleteHook(0xE9, 0x0054EAC8, &SetPlayerStopFenrir);

	SetCompleteHook(0xE9, 0x0054ED55, &SetPlayerStopDinorant);

	SetCompleteHook(0xE9, 0x0054EC8F, &SetPlayerStopHorse);

	SetCompleteHook(0xE9, 0x0054ED43, &SetPlayerStopUniria);

	SetCompleteHook(0xE9, 0x0054F8EA, &SetPlayerWalkingFenrir);

	SetCompleteHook(0xE9, 0x0054FC7D, &SetPlayerWalkingFenrir2);

	SetCompleteHook(0xE9, 0x00550706, &SetPlayerWalkingFenrir3);

	SetCompleteHook(0xE9, 0x0054FE28, &SetPlayerWalkingDinorant);

	SetCompleteHook(0xE9, 0x0054FCD8, &SetPlayerWalkingHorse);

	SetCompleteHook(0xE9, 0x005506C2, &SetPlayerWalkingHorse2);

	SetCompleteHook(0xE9, 0x005A383A, &SetPlayerReturnAction);

	SetCompleteHook(0xE9, 0x005517A4, &SetUnknowUniriaDino);

	SetCompleteHook(0xE9, 0x00551916, &SetPlayerAttackFenrir);

	SetCompleteHook(0xE9, 0x00551B3F, &SetPlayerAttackDinoUniria);

	SetCompleteHook(0xE9, 0x00551B09, &SetPlayerAttackHorse);

	SetCompleteHook(0xE9, 0x0055273E, &SetPlayerSockUniDinoHorse);

	SetCompleteHook(0xE9, 0x00552995, &SetPlayerSockFenrir);

	SetCompleteHook(0xE9, 0x005528DE, &SetPlayerSockHorse);

	SetCompleteHook(0xE9, 0x00552777, &SetPlayerMagicFenrir);

	SetCompleteHook(0xE9, 0x00564C9C, &SetCharacterMoveSpeedDinoUni);

	SetCompleteHook(0xE9, 0x00564BA2, &SetCharacterMoveSpeedFenrir);

	SetCompleteHook(0xE9, 0x00564C1C, &SetCharacterMoveSpeedHorse);

	SetCompleteHook(0xE9, 0x00564E6E, &SetCharacterPositionDino);

	SetCompleteHook(0xE9, 0x0056F688, &SetRenderCharacterUniDino);

	SetCompleteHook(0xE9, 0x0057E108, &SetCharacterPointerDino);

	SetCompleteHook(0xE9, 0x005B53FF, &SetAttackMounts);

	SetCompleteHook(0xE9, 0x0059B656, &SetSummonerAttackMount);

	SetCompleteHook(0xE9, 0x005A3817, &SetActionMounts);

	SetCompleteHook(0xE9, 0x0063EDC8, &SetTeleportDino);

	SetCompleteHook(0xE9, 0x00640A89, &SetTeleportDino2);

	SetCompleteHook(0xE9, 0x00640DCF, &SetTeleportDino3);

	if (gLoadFiles.m_LoadFiles.m_EnableSkillsMount == 0) {
		SetCompleteHook(0xE9, 0x00813F5A, &SetDisableDefenseSkillMount);

		SetCompleteHook(0xE9, 0x005B5411, &SetDisableDefenseSkillMount2);
	}

	SetCompleteHook(0xE9, 0x0054FD0E, &FixRavenWalk);

	SetCompleteHook(0xE9, 0x00644520, &FixReceiveActionInCity);

	SetCompleteHook(0xE9, 0x00648DAF, &SetSkillFenrirChaotic);

	SetCompleteHook(0xE9, 0x00648DD3, &SetSkillHorseChaotic);

	SetCompleteHook(0xE9, 0x005AE1E0, &SetSkillFenrirChaoticAttack);

	SetCompleteHook(0xE9, 0x005AE201, &SetSkillHorseChaoticAttack);

	SetCompleteHook(0xE9, 0x0054ED07, &FixRavenUnequipChar);

	SetCompleteHook(0xE9, 0x005AF273, &HorseSkill);

	MemorySet(0x008140CF, 0x90, 6);
	SetCompleteHook(0xE9, 0x008140CF, &HorseSkillIcon);

	MemorySet(0x0059C7E5, 0x90, 6);
	SetCompleteHook(0xE9, 0x0059C7E5, &HorseSkill2);
}
