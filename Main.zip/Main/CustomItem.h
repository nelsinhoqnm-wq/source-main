// CustomItem.h: interface for the CCustomItem class.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <vector>
#include "Lua.h"

struct CUSTOM_ITEM_INFO
{
	int ItemIndex;
	float ColorR;
	float ColorG;
	float ColorB;
	char ModelName[50];
};

class CCustomItem
{
public:
	CCustomItem();
	virtual ~CCustomItem();
	void Init();
	void RestartLua();
	BOOL GetCustomItemColor(int ItemIndex,float* ItemColor);
public:
	std::map<int, CUSTOM_ITEM_INFO> m_CustomItemInfo;

private:
	Lua m_Lua;
};

extern CCustomItem gCustomItem;
