#pragma once

void CSceneS0();
void SelectCharInterfaceDowngrade();

#define Vector(a,b,c,d) {(d)[0]=a;(d)[1]=b;(d)[2]=c;}
// ---------------------------------------------------------------------------------------------
#define gCharCardEnable						*(int*)0x8793541
#define RenderCircle						((void(__cdecl*)(int a1, int a2, float a3, float a4, float a5, float a6, float a7, float a8)) 0x00749250)
#define WorldTime							*(int*)0x5EF5A1C
#define sub_404570							((void *(__thiscall*)(int a1)) 0x00404570)
#define DisplayInfoBarCharacter				((int(__fastcall*)(int a1, int a2, signed int a3, signed int a4, char a5)) 0x416640)
#define sub_482B70							((int(*)()) 0x00482B70)
#define sub_587620							((int(__cdecl*)(char a1)) 0x00587620)
#define sub_483B20							((int(__thiscall*)(int a1,int a2)) 0x00483B20)
#define SelectedHero						*(int*)0xE60B4C
#define SelectedCharacter					*(int*)0xE61730
#define PlayBuffer							((signed int(__cdecl*)(int a1, int a2, int a3)) 0x006D6C20)
#define sub_63CB40							((int(*)(void)) 0x0063CB40)
#define sub_4D5130							((DWORD(__cdecl*)(char a1)) 0x004D5130)
#define sub_587380							((DWORD(__cdecl*)(char)) 0x587380)
#define sub_586DA0							((int(__cdecl*)(int, int, char, float, float, float)) 0x586DA0)
#define sub_9CF1C0							((DWORD(__cdecl*)(DWORD, DWORD, DWORD)) 0x009CF1C0)
#define sub_9CF1C0							((char *(__cdecl*)(char *a1, const void *a2, unsigned int a3)) 0x009CF1C0)
#define sub_9CF1C0B							((char *(__cdecl*)(char *a1, const void *a2, unsigned int a3)) 0x009CF1C0)
#define sub_57FD90							((void(__cdecl*)(signed int a1, int a2, int a3, int a4)) 0x0057FD90)
#define dword_87935A4						*(int*)0x87935A4
#define dword_E8CB30						*(int*)0xE8CB30
#define SceneFlag							*(int*)0x0E609E8
#define World								*(int*)0x0E61E18
#define GetClassNameText					nt(cdecl*)(unsigned int8 a4)) 0x00587620)
#define JCSetModelCoord						((int(__cdecl*)(int slot, int iclass, char a3, float UbicacionX, float UbicacionY, float Rotacion)) 0x0048AD30)
#define JCSpiriteSetPosition				((int(__fastcall*)(int Button, int This, signed int x, signed int y, char type)) 0x00416640)
#define CreateModelCharacter				((int(__cdecl*)(int slot, int iclass, char a3, float UbicacionX, float UbicacionY, float Rotacion)) 0x00586DA0)
#define sub_57D760							((DWORD(__cdecl*)(DWORD)) 0x0057D760)
#define BeginBitmap							((void(*)()) 0x637770)
#define EndOpengl							((void(*)()) 0x6366F0)
#define TransformPosition					((int(__thiscall*)(int This, int a2, vec3_t WorldPos, vec3_t Bone1, bool a5)) 0x00545030)
#define Joint(x)							((0x30 * x) + 0x7BC08A0)
#define pWarehouseExThis		((int(__thiscall*)(LPVOID This)) 0x861A80)
#define pWarehouseExSet			((void(__thiscall*)(int Pointer, BYTE Status)) 0x856BD0)
#define sub_57D760			((void(__cdecl*)(int a4)) 0x0057D760)
#define sub_668520			((int(__thiscall*)(char *a1)) 0x00668520)
#define sub_4057B0			((int(__thiscall*)(char *a1)) 0x004057B0)
#define sub_402AD0			((int(__thiscall*)(char *a1)) 0x00402AD0)
#define sub_484A10			((int(__thiscall*)(int This, int a2, char *a3)) 0x00484A10)
#define pPreviewCharSet ((void(__cdecl*)(int ObjectIndex, BYTE * CharSet, lpViewObj Object, int Mode)) 0x57FD90)

// ---------------------------------------------------------------------------------------------
#define SceneFlag							*(int*)0x0E609E8
#define World								*(int*)0x0E61E18
#define BeginRender							((void(__thiscall*)(float a2)) 0x00546860)
#define RenderMesh							((int(__thiscall*)(int This, signed int a2, int a3, float a4, signed int a5, float a6, float a7, float a8, int a9)) 0x005468A0)
#define EndRender							((void(__cdecl*)()) 0x00546880)
#define TransformPosition					((int(__thiscall*)(int This, int a2, vec3_t WorldPos, vec3_t Bone1, bool a5)) 0x00545030)
#define Joint(x)							((0x30 * x) + 0x7BC08A0)
#define CreateSprite						((int(__cdecl*)(int a1, vec3_t Bone1, float size, vec3_t color, int ObjPos, float, int)) 0x00771310)
#define CreateParticle						((int(__cdecl*)(int a1, int a2, int a3, vec3_t color, int a5, float a6, int a7)) 0x0074CD30)
#define CreateParticle2						((int(__cdecl*)(int a1, vec3_t Bone1, int a3, vec3_t color, int a5, float size, int a7)) 0x0074CD30)
#define BoneTransform						*(int*)0x7BC09C0
#define CreateEffect2						((int(__cdecl*)(int a4, vec3_t Bone1, int a6, vec3_t color, int a8, int a9, __int16 a10, __int16 a11, __int16 a12, __int16 a13, float a14, __int16 a1)) 0x006D9070)
#define RenderCryingWolf2ndObjectVisual		((void(__cdecl*)(int a1, int a2)) 0x008D1C00)
#define RenderBitmap						((void(__cdecl*)(int a1, float a2, float a3, float a4, float a5, float a6, float a7, float a8, float a9, char a10, char a11, float a12)) 0x00637C60)
#define EnableAlphaBlend					((void(__cdecl*)()) 0x636070)
#define EnableAlphaTest						((void(__cdecl*)(BYTE Mode)) 0x635FD0)
#define RenderInfomationR					((int(*)()) 0x4D5EC0)
#define pCursorX							*(int*)0x879340C
#define pCursorY							*(int*)0x8793410
#define pWinWidth							*(GLsizei*)0x0E61E58
#define pWinHeight							*(GLsizei*)0x0E61E5C
#define pWinWidthReal						*(float*)0xE7C3D4
#define pWinWidthReal2						1.5f
#define pWinHeightReal						*(float*)0xE7C3D8
#define pWinHeightReal2						1.25f
#define pWinFontHeight						*(int*)0x81C0380
#define pCheckMouseOver						((bool(__cdecl*)(int a1, int a2, int a3, int a4)) 0x00790B10)
#define JCButtonShow						((__int16(__thiscall*)(int a1 )) 0x00403700)
#define JGCloseChar							((char (__thiscall*)(int a1, int a4)) 0x483B50)
#define SetBoundInputField					((int(__thiscall*)(int a1, int a2, int a3)) 0x00417EC0)
#define SpiriteGetInfoX						((signed int(__thiscall*)(int thisa)) 0x00401C20)
#define SpiriteGetInfoY						((signed int(__thiscall*)(int thisa)) 0x00401C40)
#define SpiriteGetInfoW						((signed int(__thiscall*)(int thisa)) 0x00401C60)
#define SpiriteGetInfoH						((signed int(__thiscall*)(int thisa)) 0x00401C80)
#define sub_596EF0							((void (__thiscall*)(int a3, int a4, int a5)) 0x00596EF0)
#define ParticleScene						((int(__cdecl*)(int index, vec3_t Posicion, vec3_t Angle, vec3_t color, int a5, float size, DWORD pHeroObject)) 0x0074CD30)
#define BeginOpengl							((void(__cdecl*)(GLint x, int a2, GLsizei width, GLsizei height)) 0x00636480)
#define GetPreview							((int(*)())0x402BC0)
#define GetCharacter						((int(__thiscall*)(int This, signed int a2)) 0x96A4C0)
#define sub_402BC0							((int(*)( ))0x402BC0)
#define sub_96A4C0							((int(__thiscall*)(int This, signed int a2)) 0x96A4C0)
#define ConnectPlayerSend					((int(__thiscall*)(char type)) 0x004D6A60)
#define DelectPlayerSend					((int(__thiscall*)( )) 0x00405B10)
#define pDrawImage							((void(__cdecl*)(int ImageID, float PosX, float PosY, float Width, float Height, int Arg6, float Arg7, float ScaleX, float ScaleY, bool ScaleSize, bool ScalePosition, bool ScaleAlpha)) 0x637C60)
#define	pFontNormal							*(HGDIOBJ*)0x00E8C588
#define pFontBold							*(HGDIOBJ*)0x00E8C58C
#define pFontBigBold						*(HGDIOBJ*)0x00E8C590
#define pFontNormal2						*(HGDIOBJ*)0x00E8C594
#define pSetFont							((int(__thiscall*)(LPVOID This, int a2)) 0x420120)

extern int PointX11;
extern int PointX12;