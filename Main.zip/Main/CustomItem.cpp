// CustomItem.cpp: implementation of the CCustomItem class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CustomItem.h"
#include "CustomWing.h"
#include "CustomClaws.h"
#include "LuaStack.hpp"
#include "Item.h"

using namespace luaaa;

CCustomItem gCustomItem;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCustomItem::CCustomItem() : m_Lua(true) // OK
{
	this->m_CustomItemInfo.clear();
}

CCustomItem::~CCustomItem() // OK
{
	this->m_CustomItemInfo.clear();
}

void SetLoadItem(int ItemIndex, int colorR, int colorG, int ColorB, char* ModelName) {
	CUSTOM_ITEM_INFO info;

	info.ItemIndex = ItemIndex;

	info.ColorR = static_cast<float>(static_cast<float>(colorR) / static_cast<float>(255));

	info.ColorG = static_cast<float>(static_cast<float>(colorG) / static_cast<float>(255));

	info.ColorB = static_cast<float>(static_cast<float>(ColorB) / static_cast<float>(255));

	strcpy_s(info.ModelName, ModelName);

	gCustomItem.m_CustomItemInfo.insert(std::make_pair(info.ItemIndex, info));
}

void CCustomItem::Init() // OK
{
	LuaModule(this->m_Lua.GetState()).fun("LoadItem", &SetLoadItem);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//LoadItens.lua");

	m_Lua.Generic_Call("StartLoadItens", "");
}

void CCustomItem::RestartLua() // OK
{
	LuaModule(this->m_Lua.GetState()).fun("LoadItem", &SetLoadItem);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//LoadItens.lua");

	m_Lua.Generic_Call("StartLoadItens", "");
}

BOOL CCustomItem::GetCustomItemColor(int ItemIndex,float* ItemColor) // OK
{
	auto claw = gCustomClaws.getInfo(ItemIndex);

	if (claw) {
		ItemColor[0] = claw->ColorR;
		ItemColor[1] = claw->ColorG;
		ItemColor[2] = claw->ColorB;
		return 1;
	}

	std::map<int, CUSTOM_ITEM_INFO>::iterator it = gCustomItem.m_CustomItemInfo.find(ItemIndex);

	if (it == gCustomItem.m_CustomItemInfo.end()) {
		return 0;
	}

	auto lpInfo = &(*it).second;

	ItemColor[0] = lpInfo->ColorR;
	ItemColor[1] = lpInfo->ColorG;
	ItemColor[2] = lpInfo->ColorB;
	return 1;
}
