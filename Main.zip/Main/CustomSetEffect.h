#pragma once

#include "Lua.h"

class CCustomSetEffect {
public:
	CCustomSetEffect();
	~CCustomSetEffect();

	void Init();
	void RestartLua();

public:
	Lua m_Lua;
};

extern CCustomSetEffect gCCustomSetEffect;