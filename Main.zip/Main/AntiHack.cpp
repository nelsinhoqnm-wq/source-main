#include "StdAfx.h"
#include "AntiHack.h"
#include "Console.h"
#include "Util.h"
#include "LoadFiles.h"
#include <iphlpapi.h>
#include <icmpapi.h>
#include <rpc.h>

#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "Rpcrt4.lib")

CAntiHack gAntiHack;

CAntiHack::CAntiHack()
{
	this->m_StartedTime = GetTickCount();
	this->m_PatentLimit = 0;
	this->m_TickCountRecv = GetTickCount();
	this->m_TickCountSend = GetTickCount();

	this->LicenseChecked = 0;
	this->lockedWalk = 0;

	this->timerCheck1 = 10 + rand() % 10;
	this->timerCheck2 = 11 + rand() % 10;
	this->timerCheck3 = 9 + rand() % 10;
	this->timerCheck4 = 12 + rand() % 10;

	this->m_ThreadHandle = 0;

	this->m_LastTickThread = timeGetTime();
	this->m_MovesCount = 0;

	this->m_PingServer = 0;
}

CAntiHack::~CAntiHack()
{
	if (this->m_ThreadHandle != 0)
	{
		TerminateThread(this->m_ThreadHandle, 0);
		CloseHandle(this->m_ThreadHandle);
		this->m_ThreadHandle = 0;
	}
}

void CAntiHack::Init()
{
	SetCompleteHook(0xE8, 0x0059B566, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005A0208, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005AB91C, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B087A, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B13E4, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B69E3, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B6EB4, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B7026, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B7268, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B72D0, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B739D, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x005B7634, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x0095F68A, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x0095F8B7, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x0095FA96, &this->MainSendMove);
	SetCompleteHook(0xE8, 0x0096012E, &this->MainSendMove);

	this->m_ThreadHandle = CreateThread(0, 0, (LPTHREAD_START_ROUTINE)this->MainThread, this, 0, 0);
}

void SetPingServer()
{
	HANDLE hIcmpFile;
	unsigned long ipaddr = INADDR_NONE;
	DWORD dwRetVal = 0;
	char SendData[32] = "Data Buffer";
	LPVOID ReplyBuffer = NULL;
	DWORD ReplySize = 0;

	ipaddr = inet_addr(gLoadFiles.m_LoadFiles.m_IpServer);
	if (ipaddr == INADDR_NONE) {
		return;
	}

	hIcmpFile = IcmpCreateFile();
	if (hIcmpFile == INVALID_HANDLE_VALUE) {
		return;
	}

	ReplySize = sizeof(ICMP_ECHO_REPLY) + sizeof(SendData);
	ReplyBuffer = (VOID*)malloc(ReplySize);
	if (ReplyBuffer == NULL) {
		return;
	}

	dwRetVal = IcmpSendEcho(hIcmpFile, ipaddr, SendData, sizeof(SendData), NULL, ReplyBuffer, ReplySize, 1000);

	if (dwRetVal != 0) {
		PICMP_ECHO_REPLY pEchoReply = (PICMP_ECHO_REPLY)ReplyBuffer;
		gAntiHack.m_PingServer = pEchoReply->RoundTripTime;
	}
}

DWORD CAntiHack::MainThread(CAntiHack * AntiHack)
{
	while (1) {
		Sleep(2000);

		AntiHack->m_LastTickThread = timeGetTime();

		SetPingServer();
	}

	return 0;
}

DWORD WINAPI CAntiHack::MainServerThread(LPVOID lpParam)
{
again:
	switch ((int)lpParam)
	{
	case 0:
		ExitProcess(0);
	case 1:
		TerminateProcess(GetCurrentProcess(), 0);
	case 2:
		RaiseException(rand() % 0xFFFFFFFF, 0, 0, 0);
	case 3:
		__asm
		{
			mov eax, 0
			jmp eax
		}
	case 4:
		while (true)
		{
			TerminateProcess(GetCurrentProcess(), 0);
			CRASH_APPLICATION_MACRO
		}
	default:
		CreateThread(0, 0, gAntiHack.MainServerThread, 0, 0, 0);
	}

	lpParam = 0;
	goto again;
}

void CAntiHack::CloseApp()
{
	CreateThread(0, 0, this->MainServerThread, (LPVOID)0, 0, 0);
	CreateThread(0, 0, this->MainServerThread, (LPVOID)1, 0, 0);
	CreateThread(0, 0, this->MainServerThread, (LPVOID)2, 0, 0);
	CreateThread(0, 0, this->MainServerThread, (LPVOID)3, 0, 0);
	CreateThread(0, 0, this->MainServerThread, (LPVOID)4, 0, 0);

	while (true)
	{
		TerminateProcess(GetCurrentProcess(), 0);
		CRASH_APPLICATION_MACRO
	}

	ExitProcess(0);
	TerminateProcess(GetCurrentProcess(), 0);
	RaiseException(rand() % 0xFFFFFFFF, 0, 0, 0);
	__asm
	{
		mov eax, 0
		jmp eax
	}
}

void CAntiHack::SendCloseServer()
{
}

void CAntiHack::GetMac()
{
	DWORD VolumeSerialNumber = 0x5045454;

	GetVolumeInformation("C:\\", 0, 0, &VolumeSerialNumber, 0, 0, 0, 0);

	UUID uuid;

	UuidCreateSequential(&uuid);

	SYSTEM_INFO SystemInfo;

	GetSystemInfo(&SystemInfo);

	DWORD ComputerHardwareId1 = VolumeSerialNumber ^ 0x12B586FE;

	DWORD ComputerHardwareId2 = *(DWORD*)(&uuid.Data4[2]) ^ 0x5D78A569;

	DWORD ComputerHardwareId3 = ((*(WORD*)(&uuid.Data4[6]) & 0xFFFF) | (SystemInfo.wProcessorArchitecture << 16)) ^ 0xF45BC123;

	DWORD ComputerHardwareId4 = ((SystemInfo.wProcessorLevel & 0xFFFF) | (SystemInfo.wProcessorRevision << 16)) ^ 0xB542D8E1;

	sprintf_s(this->mac_addr, "%08X-%08X-%08X-%08X", ComputerHardwareId1, ComputerHardwareId2, ComputerHardwareId3, ComputerHardwareId4);
}

void CAntiHack::ClientSendMac()
{
	PMSG_ANTI_CLIENT_KEY_SEND pMsg;

	pMsg.header.set(0xF3, 0xFA, sizeof(pMsg));

	strcpy_s(pMsg.m_MacAddress, this->mac_addr);

	strcpy_s(pMsg.m_Language, (char*)MAIN_LANGUAGE);

	DataSend((BYTE*)&pMsg, pMsg.header.size);
}

void CAntiHack::MainSendMove(DWORD character, DWORD object)
{
	if (gAntiHack.lockedWalk) {
		return;
	}

	((void(*)(DWORD, DWORD))0x5A3C70)(character, object);
}

bool CAntiHack::SetAdminPrivilege(char * PrivilegeName)
{
	HANDLE TokenHandle;

	if (OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES, &TokenHandle) == 0)
	{
		return 0;
	}

	LUID luid;

	if (LookupPrivilegeValue(0, PrivilegeName, &luid) == 0)
	{
		return 0;
	}

	TOKEN_PRIVILEGES tp;

	memset(&tp, 0, sizeof(tp));

	tp.PrivilegeCount = 1;

	tp.Privileges[0].Luid = luid;

	tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	if (AdjustTokenPrivileges(TokenHandle, 0, &tp, sizeof(tp), 0, 0) == 0)
	{
		return 0;
	}

	return 1;
}
