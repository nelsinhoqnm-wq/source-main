#pragma once
// ---------------------------------------------------------------------------
//  Configuracao do select char controlada pelo Lua (CharacterList.lua)
// ---------------------------------------------------------------------------
struct SELECT_BACKGROUND_INFO
{
	int   WorldId;     // >0 = forca este mapa no select char | 0 = usa o padrao do client
	bool  UseCamera;   // true = usa a camera abaixo | false = camera padrao do client
	float CamDist;     // 0x0E61E3C
	float AngX;        // 0x87933D0
	float AngY;        // 0x87933D4
	float AngZ;        // 0x87933D8
	float PosX;        // 0x87933DC
	float PosY;        // 0x87933E0
	float PosZ;        // 0x87933E4
	float Fov;         // 0x0E61E40
	bool  LuaUI;       // true = a lista/botoes sao desenhados pelo Lua
};

extern SELECT_BACKGROUND_INFO gSelectBackground;
