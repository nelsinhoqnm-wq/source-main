#pragma once

#include "Lua.h"

struct CUSTOM_CLAWS_INFO {
	int ItemIndex;
	float ColorR;
	float ColorG;
	float ColorB;
	char ModelName[32];
	int TextureLeftIndex;
	char TextureLeftModel[32];
	int TextureRightIndex;
	char TextureRightModel[32];
};

class CCustomClaws {
public:
	CCustomClaws();
	~CCustomClaws();

	void Init();
	bool CheckIsClaw(int ItemIndex);
	CUSTOM_CLAWS_INFO* getInfo(int ItemIndex);

public:
	std::map<int, CUSTOM_CLAWS_INFO> m_CustomClaws;

private:
	Lua m_Lua;
};

extern CCustomClaws gCustomClaws;