#include "stdafx.h"
#include "WindowTray.h"
#include "CustomMessage.h"
#include "LoadFiles.h"
#include "HotKey.h"
#include "resource.h"
#include <Shellapi.h>

#pragma comment (lib, "Shell32.lib")

TrayMode gTrayMode;

void TrayMode::Load()
{
	this->TempWindowProc = NULL;
	this->TempIconProc = NULL;
	this->InTray = false;

	this->LastPress = GetTickCount();
}

void TrayMode::SwitchState()
{
	if (IsWindowVisible(*(HWND*)(0x00E8C578)))
	{
		if (GetForegroundWindow() == *(HWND*)(0x00E8C578))
		{
			ShowWindow(*(HWND*)(0x00E8C578), SW_HIDE);
			UpdateWindow(*(HWND*)(0x00E8C578));
			this->ShowNotify(true);
			this->ShowMessage(NIIF_INFO, gLoadFiles.m_LoadFiles.m_WindowName, gCustomMessage.GetMessage(23));
		}
	}
	else
	{
		ShowWindow(*(HWND*)(0x00E8C578), SW_SHOW);
		UpdateWindow(*(HWND*)(0x00E8C578));
		this->ShowNotify(false);
	}
}

void TrayMode::ShowNotify(bool Mode)
{
	this->InTray = Mode;
	NOTIFYICONDATA Icon = { 0 };

	Icon.cbSize = sizeof(NOTIFYICONDATA);
	Icon.uID = TRAYMODE_ICON_ID;
	Icon.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	Icon.hIcon = (HICON)LoadImage(gHotKey.hIstance, MAKEINTRESOURCE(IDI_ICON1), IMAGE_ICON, GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
	this->TempIconProc = Icon.hIcon;
	Icon.hWnd = *(HWND*)(0x00E8C578);
	Icon.uCallbackMessage = TRAYMODE_ICON_MESSAGE;

	strcpy_s(Icon.szTip, sizeof(Icon.szTip), gLoadFiles.m_LoadFiles.m_WindowName);

	if (*(DWORD*)(MAIN_SCREEN_STATE) == 5)
	{
		char Text[120];

		auto her = Hero;

		sprintf_s(Text, gCustomMessage.GetMessage(24), her->Name, her->Level, pGetMapName(*(int*)0x0E61E18), her->MapPosX, her->MapPosY);
		strcat_s(Icon.szTip, Text);
	}

	if (Mode)
	{
		Shell_NotifyIcon(NIM_ADD, &Icon);
	}
	else
	{
		Shell_NotifyIcon(NIM_DELETE, &Icon);
	}

	DeleteObject(Icon.hIcon);
}

void TrayMode::ShowMessage(DWORD Type, char * Title, char * Message)
{
	NOTIFYICONDATA Icon = { 0 };

	Icon.cbSize = sizeof(NOTIFYICONDATA);
	Icon.uID = TRAYMODE_ICON_ID;
	Icon.hWnd = *(HWND*)(0x00E8C578);
	Icon.uFlags = NIF_ICON | NIF_MESSAGE | NIF_INFO;
	Icon.hIcon = this->TempIconProc;
	Icon.uCallbackMessage = TRAYMODE_ICON_MESSAGE;
	Icon.dwInfoFlags = Type;
	Icon.uTimeout = 5000;

	strcpy_s(Icon.szInfo, Message);
	strcpy_s(Icon.szInfoTitle, Title);

	Shell_NotifyIcon(NIM_MODIFY, &Icon);
}