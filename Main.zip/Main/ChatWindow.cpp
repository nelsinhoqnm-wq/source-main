#include "StdAfx.h"
#include "ChatWindow.h"
#include "Util.h"
// ----------------------------------------------------------------------------------------------

ChatExpanded	gChatExpanded;
// ----------------------------------------------------------------------------------------------

Naked(FixSysMsg1)
{
	__asm
	{
		cmp dword ptr ss : [ebp + 0x10] , 3
		je _true
		call NewCall
		jmp FixSysMsg1_FALSE
		_true :
		pop eax
			jmp FixSysMsg1_TRUE
	}
}
// ----------------------------------------------------------------------------------------------

Naked(FixSysMsg2)
{
	__asm
	{
		cmp dword ptr ss : [ebp + 0x10] , 3
		je _true
		call NewCall
		jmp FixSysMsg2_FALSE
		_true :
		pop eax
			jmp FixSysMsg2_TRUE
	}
}
// ----------------------------------------

Naked(FixSysMsg3)
{
	__asm
	{
		cmp dword ptr ss : [ebp + 0x10] , 3
		je _true
		call NewCall
		jmp FixSysMsg3_FALSE
		_true :
		pop eax
			jmp FixSysMsg3_TRUE
	}
}
// -----------------------------------------

void ChatExpanded::Load()
{
	SetOp(oShowChatMessage_Call, (LPVOID)this->ShowChatMessage, 0xE8);
	SetOp(FixSysMsg1_Hook, FixSysMsg1, 0xE9);
	SetOp(FixSysMsg2_Hook, FixSysMsg2, 0xE9);
	SetOp(FixSysMsg3_Hook, FixSysMsg3, 0xE9);
}
// -----------------------------------------

void ChatExpanded::SetInstance(LPVOID Instance)
{
	this->Instance = Instance;
	this->PosYBuff = this->GetPosY();
	this->HeightBuff = this->GetHeight();
	this->MessageCountBuff = this->GetMessageCount();
	this->MessageTypeBuff = this->GetMessageType();
	this->ScrollPosBuff = this->GetScrollPos();
}
// ------------------------------------------

void ChatExpanded::Restore()
{
	this->SetPosY(this->PosYBuff);
	this->SetHeight(this->HeightBuff);
	this->SetMessageCount(this->MessageCountBuff);
	this->SetMessageType(this->MessageTypeBuff);
	this->SetScrollPos(this->ScrollPosBuff);
}
// -----------------------------------------

void ChatExpanded::Switch()
{
	if (gChatExpanded.m_separate == 0)
	{
		SetOp(oShowChatMessage_Call, (LPVOID)this->ShowChatMessage, 0xE8);
		SetOp(FixSysMsg1_Hook, FixSysMsg1, 0xE9);
		SetOp(FixSysMsg2_Hook, FixSysMsg2, 0xE9);
		SetOp(FixSysMsg3_Hook, FixSysMsg3, 0xE9);
		gChatExpanded.m_separate = 1;
	}
	else
	{
		SetOp(FixSysMsg1_Hook, (LPVOID)oNewCall, 0xE8);
		SetOp(FixSysMsg2_Hook, (LPVOID)oNewCall, 0xE8);
		SetOp(FixSysMsg3_Hook, (LPVOID)oNewCall, 0xE8);
		gChatExpanded.m_separate = 0;
	}
}
// ----------------------------------------

bool ChatExpanded::ShowChatMessage(LPVOID This, LPVOID EDX)
{
	if (gChatExpanded.m_separate == 0)
	{
		return pShowChatMessage(This);
	}
	// ----
	gChatExpanded.SetInstance(This);
	gChatExpanded.SetPosY(172);
	gChatExpanded.SetHeight(100);
	gChatExpanded.SetMessageCount(4);
	pSetChatMessageType(This, 3);
	pShowChatMessage(This);
	gChatExpanded.Restore();
	return pShowChatMessage(This);
}
// ----------------------------------------