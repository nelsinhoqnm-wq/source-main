#include "stdafx.h"
#include "CustomItemSize.h"
#include "LuaStack.hpp"
#include "Util.h"
#include "Item.h"

using namespace luaaa;

CCustomItemSize gCustomItemSize;

CCustomItemSize::CCustomItemSize() : m_Lua(true)
{
	this->m_CustomItemSizeInfo.clear();
}

CCustomItemSize::~CCustomItemSize()
{
	this->m_CustomItemSizeInfo.clear();
}

void SetItemPosition(int ItemIndex, float SizeInventory) {
	CUSTOM_ITEM_SIZE_INFO info;

	info.ItemIndex = ItemIndex;

	info.SizeInventory = SizeInventory;

	gCustomItemSize.m_CustomItemSizeInfo.insert(std::make_pair(info.ItemIndex, info));
}

void GetSizeItem(int ItemIndex, float& Size) {
	auto itemPos = gCustomItemSize.getItemSize(ItemIndex);

	if (itemPos) {
		Size = itemPos->SizeInventory;
	}
}

void __declspec(naked) InventoryItemSize()
{
	static DWORD m_ItemIndex = 0;
	static DWORD m_HookFunc = 0x005CF01C;
	static DWORD m_ReturnFunc = 0x005CD9CD;

	_asm {
		MOV ECX, DWORD PTR SS : [EBP + 0x8];
		MOV m_ItemIndex, ECX;
	}

	static float Itemsize = 0.0;

	if (gCustomItemSize.CheckCustomItemSize(m_ItemIndex - ITEM_BASE_MODEL)) {
		GetSizeItem(m_ItemIndex - ITEM_BASE_MODEL, Itemsize);

		_asm {
			FLD DWORD PTR DS : [Itemsize];
			FSTP DWORD PTR SS : [EBP - 0x2C];
			JMP[m_HookFunc];
		}
	}
	else {
		_asm {
			CMP DWORD PTR SS : [EBP + 0x8], 0x1293
			JMP[m_ReturnFunc];
		}
	}
}

bool CCustomItemSize::CheckCustomItemSize(int ItemIndex)
{
	std::map<int, CUSTOM_ITEM_SIZE_INFO>::iterator it = this->m_CustomItemSizeInfo.find(ItemIndex);

	if (it == this->m_CustomItemSizeInfo.end()) {
		return 0;
	}

	return 1;
}

CUSTOM_ITEM_SIZE_INFO * CCustomItemSize::getItemSize(int ItemIndex)
{
	std::map<int, CUSTOM_ITEM_SIZE_INFO>::iterator it = this->m_CustomItemSizeInfo.find(ItemIndex);

	if (it == this->m_CustomItemSizeInfo.end()) {
		return 0;
	}

	return &it->second;
}

void CCustomItemSize::Init()
{
	LuaModule(this->m_Lua.GetState()).fun("SetItemSize", &SetItemPosition);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomItemSize.lua");

	this->m_Lua.Generic_Call("StartLoadItemSize", "");

	SetCompleteHook(0xE9, 0x005CD9C6, &InventoryItemSize);
}


void CCustomItemSize::RestartLua()
{
	LuaModule(this->m_Lua.GetState()).fun("SetItemSize", &SetItemPosition);

	this->m_Lua.DoFile("Data//Files//Lua//Configs//CustomItemSize.lua");

	this->m_Lua.Generic_Call("StartLoadItemSize", "");

	SetCompleteHook(0xE9, 0x005CD9C6, &InventoryItemSize);
}
