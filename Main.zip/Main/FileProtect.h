// FileProtect.h: interface for the CFileProtect class.
//////////////////////////////////////////////////////////////////////
#ifndef FILEPROTECTED_H_
#define FILEPROTECTED_H_

static const BYTE gFileProtectHeader[8] = { 0x24,0xF9,0x21,0x95,0xA8,0xE6,0x43,0xF2 };
static const BYTE gFileProtectXorTable[16] = { 0x25,0x61,0x21,0xAA,0x05,0xFB,0x31,0x72,0x70,0xD5,0x20,0xCA,0x33,0x2E,0xE2,0xC8 };

class CFileProtect
{
public:
	CFileProtect();
	virtual ~CFileProtect();
	bool LoadFile(char* path);
	bool DecryptFile(char* path);
	bool CreateTemporaryFile();
	void DeleteTemporaryFile();
	void ConvertMainFilePath(char* path);
private:
	char* m_buff;
	DWORD m_size;
	char m_path[256];
};

extern CFileProtect gFileProtect;

#endif