#include "stdafx.h"
#include "WideScreen.h"
#include "InterWide.h"
#include "Util.h"
#include "PrintPlayer.h"
#include "Defines.h"
#include "Offset.h"

JCInterface JCInterfaceBar;
int TimerPush1;
int TimerPush2;
int JCPageSlotSkill = 0;
int JCSkillScale = 0;

bool JCEventButton(int x, int y, int w, int h)
{
	return pCheckMouseOver(x, y, w, h) && *(BYTE*)0x8793386;
}

signed int sub_9CEBF03(double a1)
{
	return (signed int)a1;
}

double JCRenderNumber(float a1, float a2, int a3, float a4)
{
	double result; // st7@2
	float v5; // ST44_4@5
	float v6; // ST38_4@5
	signed int i; // [sp+38h] [bp-30h]@3
	float v8; // [sp+3Ch] [bp-2Ch]@3
	signed int v9; // [sp+44h] [bp-24h]@3
	char v10[32]; // [sp+48h] [bp-20h]@3
	float v11; // [sp+70h] [bp+8h]@3

	EnableAlphaTest(1);
	if (a4 >= 0.300000011920929)
	{
		v8 = (a4 - 0.4800000119209290) * 12.0;
		_itoa(a3, v10, 10);
		v9 = strlen(v10);
		v11 = a1 - (double)v9 * v8 / 2.0;
		for (i = 0; i < v9; ++i)
		{
			v6 = (double)(v10[i] - 48) * 12.0 / 128.0;
			v5 = (a4 - 0.4000000119209290) * 16.0;
			RenderBitmap(31337, v11, a2, v8, v5, v6, 0.0, 0.09375, 0.875, 1, 1, 0.0);
			v11 = v8 * 0.800000011920929 + v11;
		}
		result = v11;
	}
	else
	{
		result = a1;
	}

	return result;
}

void JCItemStacknumber(float x, float y, int number, float scale)
{
	JCRenderNumber(x, y, number, scale);
}

int JCStacknumberpotion(float x, float y, int number)
{
	pSetBlend(1);

	return JCRenderNumber(x, y, number, 1.0);
}

void JCShowTimerBar(int Skillnumber, float x, float y, float w, float h)
{
	if (JCSkillScale == 1)
	{
		JCTimerSkillBar(Skillnumber, x, y, 16.0f, 20.0f);
	}
	else
	{
		JCTimerSkillBar(Skillnumber, x, y, w, h);
	}
}

void JCShownumberSkill(float x, float y, int number, float scale)
{
	if (JCSkillScale == 1)
	{
		JCRenderNumber(x - 5.0f, y - 5.0f, number, 0.9);
	}
	else
	{
		JCRenderNumber(x, y, number, 1.0);
	}

}

void JCShowSlotSkill(int ImageID, float PosX, float PosY, float Width, float Height, float CurrentMoveX, float CurrentMoveY, float ScaleX, float ScaleY, bool ScaleSize, bool ScalePosition, bool ScaleAlpha)
{
	if (JCSkillScale == 1)
	{
		RenderBitmap(ImageID, PosX, PosY, 16.0f, 20.0f, CurrentMoveX, CurrentMoveY, ScaleX, ScaleY, ScaleSize, ScalePosition, ScaleAlpha);
	}
	else
	{
		RenderBitmap(ImageID, PosX, PosY, Width, Height, CurrentMoveX, CurrentMoveY, ScaleX, ScaleY, ScaleSize, ScalePosition, ScaleAlpha);
	}
}


void SwitchEventSkill(int num, int x, int y)
{
	int JCMainSelect; // [sp+30h] [bp-2Ch]@15

	JCMainSelect = *(DWORD*)(GetInstance() + 32);

	EnableAlphaTest(1);
	glColor4f(1.0, 1.0, 1.0, 1.0);

	if ((signed int)*(BYTE*)(dword_8128AC8 + 118) > 0 && *(BYTE*)(JCMainSelect + 64) == 1)
	{
		RenderBitmap(61547, x + 245, y + 12, 17, 42, 0.0, 0.0, 0.2399999946, 1.0, 1, 1, 0);

		if (num > 20)
		{
			if (JCPageSlotSkill == 1)
			{
				//-- Boton Arriba
				if (JCEventButton(x + 247, y + 14, 13, 13))
				{
					JCPageSlotSkill = 0;
					RenderBitmap(61547, x + 247, y + 14, 13, 13, 0.3870000243, 0.4429999888, 0.1380000114, 0.2490001172, 1, 1, 0);
					PlayBuffer(25, 0, 0);
				}
				else
				{
					RenderBitmap(61547, x + 247, y + 14, 13, 13, 0.3870000243, 0.7100000381, 0.1380000114, 0.2490001172, 1, 1, 0);
				}
			}
			else
			{
				RenderBitmap(61547, x + 247, y + 14, 13, 13, 0.3870000243, 0.1729999632, 0.1380000114, 0.2490001172, 1, 1, 0);
			}
			//-- Boton Abajo
			if (JCPageSlotSkill == 0)
			{
				if (JCEventButton(x + 247, y + 38, 13, 13))
				{
					JCPageSlotSkill = 1;
					RenderBitmap(61547, x + 247, y + 38, 13, 13, 0.2470000237, 0.4429999888, 0.1380000114, 0.2490001172, 1, 1, 0);
					PlayBuffer(25, 0, 0);
				}
				else
				{
					RenderBitmap(61547, x + 247, y + 38, 13, 13, 0.2470000237, 0.7100000381, 0.1380000114, 0.2490001172, 1, 1, 0);
				}
			}
			else
			{
				RenderBitmap(61547, x + 247, y + 38, 13, 13, 0.2470000237, 0.1729999632, 0.1380000114, 0.2490001172, 1, 1, 0);
			}
		}
		else
		{
			//-- Arriba
			RenderBitmap(61547, x + 247, y + 14, 13, 13, 0.3870000243, 0.1729999632, 0.1380000114, 0.2490001172, 1, 1, 0);
			//-- Abajo
			RenderBitmap(61547, x + 247, y + 38, 13, 13, 0.2470000237, 0.1729999632, 0.1380000114, 0.2490001172, 1, 1, 0);
		}
	}
}

bool JCEventMouseSkill(int a1)
{
	bool result; // al@2
	unsigned __int8 v5; // ST4F_1@3
	int v6; // ST0C_4@7
	int v7; // ST08_4@7
	int v8; // ST04_4@7
	int v9; // eax@7
	int v10; // ST0C_4@11
	int v11; // ST08_4@11
	int v12; // ST04_4@11
	int v13; // eax@11
	int v14; // ST0C_4@16
	int v15; // ST08_4@16
	int v16; // ST04_4@16
	int v17; // eax@16
	int v18; // ST0C_4@21
	int v19; // ST08_4@21
	int v20; // ST04_4@21
	int v21; // eax@21
	int v22; // ST0C_4@30
	int v23; // ST08_4@30
	int v24; // ST04_4@30
	int v25; // eax@30
	int v26; // ST0C_4@34
	int v27; // ST08_4@34
	int v28; // ST04_4@34
	int v29; // eax@34
	int v30; // ST0C_4@38
	int v31; // ST08_4@38
	int v32; // ST04_4@38
	int v33; // eax@38
	int v34; // ST0C_4@45
	int v35; // ST08_4@45
	int v36; // ST04_4@45
	int v37; // eax@45
	int v38; // ST0C_4@68
	int v39; // ST08_4@68
	int v40; // ST04_4@68
	int v41; // eax@68
	int v42; // ST0C_4@92
	int v43; // ST08_4@92
	int v44; // ST04_4@92
	int v45; // eax@92
	int v46; // ST0C_4@98
	int v47; // ST08_4@98
	int v48; // ST04_4@98
	int v49; // eax@98
	int v50; // ST0C_4@102
	int v51; // ST08_4@102
	int v52; // ST04_4@102
	int v53; // eax@102
	int v54; // ST0C_4@107
	int v55; // ST08_4@107
	int v56; // ST04_4@107
	int v57; // eax@107
	int v58; // ST0C_4@118
	int v59; // ST08_4@118
	int v60; // ST04_4@118
	int v61; // eax@118
	int v62; // [sp+Ch] [bp-54h]@1
	signed int j; // [sp+10h] [bp-50h]@116
	int v64; // [sp+18h] [bp-48h]@84
	signed int i; // [sp+20h] [bp-40h]@73
	unsigned __int16 v66; // [sp+24h] [bp-3Ch]@53
	signed int v67; // [sp+2Ch] [bp-34h]@40
	signed int v68; // [sp+30h] [bp-30h]@40
	unsigned __int16 v69; // [sp+38h] [bp-28h]@76
	float v70; // [sp+40h] [bp-20h]@5
	float v71; // [sp+40h] [bp-20h]@28
	float v72; // [sp+40h] [bp-20h]@40
	float v73; // [sp+40h] [bp-20h]@73
	float v74; // [sp+40h] [bp-20h]@116
	float v75; // [sp+44h] [bp-1Ch]@5
	float v76; // [sp+44h] [bp-1Ch]@28
	float v77; // [sp+44h] [bp-1Ch]@73
	char v78; // [sp+4Bh] [bp-15h]@73
	float v79; // [sp+4Ch] [bp-14h]@73
	signed int v80; // [sp+50h] [bp-10h]@73
	int v81; // [sp+54h] [bp-Ch]@73
	float v82; // [sp+58h] [bp-8h]@5
	float v83; // [sp+58h] [bp-8h]@28
	float v84; // [sp+58h] [bp-8h]@40
	float v85; // [sp+58h] [bp-8h]@85
	float v86; // [sp+58h] [bp-8h]@116
	float v87; // [sp+5Ch] [bp-4h]@5
	float v88; // [sp+5Ch] [bp-4h]@28
	float v89; // [sp+5Ch] [bp-4h]@40
	float v90; // [sp+5Ch] [bp-4h]@73
	float v91; // [sp+5Ch] [bp-4h]@116
	int JCResto; // eax@1

	v62 = a1;
	JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	if (pCheckEffectPlayer((DWORD*)(dword_7BC4F04 + 1260), 98))
	{
		*(BYTE*)(v62 + 64) = 0;
		result = 1;
	}
	else
	{
		v5 = *(BYTE*)(dword_8128AC8 + 118);
		*(BYTE*)(v62 + 65) = 0;
		if ((signed int)v5 > 0)
		{
			v82 = 310.0f + JCResto;
			v87 = 447.05;
			v70 = 20.0;
			v75 = 28.0;

			if (*(DWORD*)(v62 + 80)
				|| byte_8793384
				|| (v6 = sub_9CEBF03(v75),
					v7 = sub_9CEBF03(v70),
					v8 = sub_9CEBF03(v87),
					v9 = sub_9CEBF03(v82),
					pCheckMouseOver(v9, v8, v7, v6) != 1))
			{
				if (*(DWORD*)(v62 + 80) != 1
					|| byte_8793384
					|| (v10 = sub_9CEBF03(v75),
						v11 = sub_9CEBF03(v70),
						v12 = sub_9CEBF03(v87),
						v13 = sub_9CEBF03(v82),
						pCheckMouseOver(v13, v12, v11, v10)))
				{
					if (*(DWORD*)(v62 + 80) != 1
						|| byte_8793384 != 1 && byte_8793380 != 1
						|| (v14 = (int)(v75),
							v15 = (int)(v70),
							v16 = (int)(v87),
							v17 = (int)(v82),
							pCheckMouseOver(v17, v16, v15, v14) != 1))
					{
						if (*(DWORD*)(v62 + 80) != 2 || byte_8793384 || byte_8793380)
						{
							if (*(DWORD*)(v62 + 80) == 1)
							{
								*(BYTE*)(v62 + 65) = 1;
								*(DWORD*)(v62 + 68) = *(BYTE*)(dword_7BC4F04 + 50);
								*(DWORD*)(v62 + 72) = (int)(v82 - 5.0);
								*(DWORD*)(v62 + 76) = (int)(v87);
								result = 0;
							}
							else if (*(DWORD*)(v62 + 80) == 2)
							{
								result = 0;
							}
							else
							{								
								v88 = 490.0;
								v71 = 160.0;
								v76 = 38.0;
								v83 = 222.0 + JCResto;

								if (*(DWORD*)(v62 + 80)
									|| byte_8793384
									|| (v22 = sub_9CEBF03(v76),
										v23 = sub_9CEBF03(v71),
										v24 = sub_9CEBF03(v88),
										v25 = sub_9CEBF03(v83),
										pCheckMouseOver(v25, v24, v23, v22) != 1))
								{
									if (*(DWORD*)(v62 + 80) != 3
										|| byte_8793384
										|| (v26 = sub_9CEBF03(v76),
											v27 = sub_9CEBF03(v71),
											v28 = sub_9CEBF03(v88),
											v29 = sub_9CEBF03(v83),
											pCheckMouseOver(v29, v28, v27, v26)))
									{
										if (*(DWORD*)(v62 + 80) != 3
											|| byte_8793384 != 1
											|| (v30 = sub_9CEBF03(v76),
												v31 = sub_9CEBF03(v71),
												v32 = sub_9CEBF03(v88),
												v33 = sub_9CEBF03(v83),
												pCheckMouseOver(v33, v32, v31, v30) != 1))
										{
											v84 = 190.0 + JCResto;
											v89 = 490.0;
											v72 = 32.0;
											v68 = 0;

											v67 = *(BYTE*)(v62 + 20) != 1 ? 1 : 6;
											while (v68 < 5)
											{
												v84 = v84 + v72;
												if (v67 == 10)
													v67 = 0;
												v34 = (int)((float)38.0);
												v35 = (int)(v72);
												v36 = (int)(v89);
												v37 = (int)(v84);
												if (pCheckMouseOver(v37, v36, v35, v34) == 1)
												{
													if (*(DWORD*)(v62 + 4 * v67 + 24) == -1)
													{
														if (*(DWORD*)(v62 + 80) == 3)
														{
															*(BYTE*)(v62 + 65) = 0;
															*(DWORD*)(v62 + 68) = -1;
														}
														if (*(DWORD*)(v62 + 80) == 4 && !byte_8793384)
															*(DWORD*)(v62 + 80) = 0;
													}
													else
													{
														v66 = *(WORD*)(dword_8128AC8 + 2 * *(DWORD*)(v62 + 4 * v67 + 24) + 120);
														if (v66
															&& ((signed int)v66 < 67 || (signed int)v66 > 72)
															&& *(BYTE*)(dword_8128ABC + 88 * v66 + 55) != 3)
														{
															if (*(DWORD*)(v62 + 80) == 3)
															{
																*(BYTE*)(v62 + 65) = 1;
																*(DWORD*)(v62 + 68) = *(DWORD*)(v62 + 4 * v67 + 24);
																*(DWORD*)(v62 + 72) = (int)(v84 - 5.0);
																*(DWORD*)(v62 + 76) = (int)(v89);
																return 1;
															}
															if (*(DWORD*)(v62 + 80) == 4 && !byte_8793384)
															{
																if (*(DWORD*)(v62 + 68) == *(DWORD*)(v62 + 4 * v67 + 24))
																{
																	*(DWORD*)(v62 + 80) = 0;
																	*(WORD*)(v62 + 84) = *(WORD*)(dword_8128AC8
																		+ 2 * *(BYTE*)(dword_7BC4F04 + 50)
																		+ 120);
																	*(BYTE*)(dword_7BC4F04 + 50) = *(BYTE*)(v62 + 4 * v67 + 24);
																	PlayBuffer(25, 0, 0);
																	return 0;
																}
																*(DWORD*)(v62 + 80) = 0;
															}
														}
													}
												}
												++v68;
												++v67;
											}
											if (*(DWORD*)(v62 + 80) == 4)
											{
												if (byte_8793384
													|| (v38 = (int)((float)38.0),
														v39 = (int)((float)160.0),
														v40 = (int)((float)431.0),
														v41 = (int)((float)222.0),
														pCheckMouseOver(v41, v40, v39, v38)))
												{
													result = 0;
												}
												else
												{
													*(DWORD*)(v62 + 80) = 0;
													result = 1;
												}
											}
											else if (*(BYTE*)(v62 + 64))
											{
												v80 = 0;
												v78 = 0;
												v90 = 349.0; //-- y
												v73 = 24.0; //-- width
												v77 = 29.5; //-- height
												v79 = JCResto + 191.0; //-- x
												v81 = *(DWORD*)(v62 + 80);
												for (i = 0; i < 150; ++i)
												{
													v69 = *(WORD*)(dword_8128AC8 + 2 * i + 120);
													if (v69
														&& ((signed int)v69 < 67 || (signed int)v69 > 72)
														&& *(BYTE*)(dword_8128ABC + 88 * v69 + 55) != 3)
													{
														if (v80 == 10)
															v90 = v90 + v77;
														if (v80 == 20)
															v90 = v90 - v77;
														if (v80 >= 10 && v80 < 20)
														{
															v85 = (double)(v80 - 10) * v73 + v79;
														}
														else if (v80 >= 20)
														{
															v85 = (double)(v80 - 20) * v73 + v79;
														}
														else
														{
															v85 = (double)v80 * v73 + v79;
														}
														++v80;

														if (JCPageSlotSkill == 0)
														{
															if (v80 >= 21)
																continue;
														}
														else
														{
															if (v80 < 21)
																continue;
														}
														v42 = (int)(v77);
														v43 = (int)(v73);
														v44 = (int)(v90);
														v45 = (int)(v85);
														if (pCheckMouseOver(v45, v44, v43, v42) == 1)
														{
															v78 = 1;
															if (!*(DWORD*)(v62 + 80) && !byte_8793384)
															{
																*(DWORD*)(v62 + 80) = 5;
																break;
															}
														}
														if (*(DWORD*)(v62 + 80) == 5 && byte_8793384 == 1)
														{
															v46 = (int)(v77);
															v47 = (int)(v73);
															v48 = (int)(v90);
															v49 = (int)(v85);
															if (pCheckMouseOver(v49, v48, v47, v46) == 1)
															{
																*(DWORD*)(v62 + 80) = 6;
																break;
															}
														}
														if (*(DWORD*)(v62 + 80) == 5 && !byte_8793384)
														{
															v50 = (int)(v77);
															v51 = (int)(v73);
															v52 = (int)(v90);
															v53 = (int)(v85);
															if (pCheckMouseOver(v53, v52, v51, v50) == 1)
															{
																*(BYTE*)(v62 + 65) = 1;
																*(DWORD*)(v62 + 68) = i;
																*(DWORD*)(v62 + 72) = (int)(v85);
																*(DWORD*)(v62 + 76) = (int)(v90);
															}
														}
														if (*(DWORD*)(v62 + 80) == 6 && !byte_8793384 && *(DWORD*)(v62 + 68) == i)
														{
															v54 = (int)(v77);
															v55 = (int)(v73);
															v56 = (int)(v90);
															v57 = (int)(v85);
															if (pCheckMouseOver(v57, v56, v55, v54) == 1)
															{
																*(DWORD*)(v62 + 80) = 0;
																*(WORD*)(v62 + 84) = *(WORD*)(dword_8128AC8 + 2 * *(BYTE*)(dword_7BC4F04 + 50) + 120);
																*(BYTE*)(dword_7BC4F04 + 50) = i;
																*(BYTE*)(v62 + 64) = 0;
																PlayBuffer(25, 0, 0);
																return 0;
															}
														}
													}
												}
												if (v81 == *(DWORD*)(v62 + 80))
												{
													if (*(DWORD*)(dword_7BC4F04 + 676))
													{
														v86 = JCResto + 191.0;
														v91 = 379.0;
														v74 = 24.0;
														for (j = 150; j < 154; ++j)
														{
															v58 = (int)((float)38.0);
															v59 = (int)(v74);
															v60 = (int)(v91);
															v61 = (int)(v86);
															if (pCheckMouseOver(v61, v60, v59, v58) == 1)
															{
																v78 = 1;
																if (!*(DWORD*)(v62 + 80) && !byte_8793384)
																{
																	*(DWORD*)(v62 + 80) = 5;
																	return 1;
																}
																if (*(DWORD*)(v62 + 80) == 5 && byte_8793384 == 1)
																{
																	*(DWORD*)(v62 + 80) = 6;
																	return 0;
																}
																if (*(DWORD*)(v62 + 80) == 5)
																{
																	*(BYTE*)(v62 + 65) = 1;
																	*(DWORD*)(v62 + 68) = j;
																	*(DWORD*)(v62 + 72) = (int)(v86);
																	*(DWORD*)(v62 + 76) = (int)(v91);
																}
																if (*(DWORD*)(v62 + 80) == 6 && !byte_8793384 && *(DWORD*)(v62 + 68) == j)
																{
																	*(DWORD*)(v62 + 80) = 0;
																	*(WORD*)(v62 + 84) = *(WORD*)(dword_8128AC8 + 2 * *(BYTE*)(dword_7BC4F04 + 50) + 120);
																	*(BYTE*)(dword_7BC4F04 + 50) = j;
																	*(BYTE*)(v62 + 64) = 0;
																	PlayBuffer(25, 0, 0);
																	return 0;
																}
															}
															v86 = v86 + v74;
														}
													}
													if (v78 || *(DWORD*)(v62 + 80) != 5)
													{
														if (v78 || byte_8793384 || *(DWORD*)(v62 + 80) != 6)
														{
															if (*(DWORD*)(v62 + 80) == 6)
															{
																if (byte_8793384)
																{
																	result = 0;
																}
																else
																{
																	*(DWORD*)(v62 + 80) = 0;
																	result = 1;
																}
															}
															else
															{
																result = 1;
															}
														}
														else
														{
															*(DWORD*)(v62 + 80) = 0;
															result = 0;
														}
													}
													else
													{
														*(DWORD*)(v62 + 80) = 0;
														result = 1;
													}
												}
												else
												{
													result = !*(DWORD*)(v62 + 80) || *(DWORD*)(v62 + 80) == 5;
												}
											}
											else
											{
												result = 1;
											}
										}
										else
										{
											*(DWORD*)(v62 + 80) = 4;
											result = 0;
										}
									}
									else
									{
										*(DWORD*)(v62 + 80) = 0;
										result = 1;
									}
								}
								else
								{
									*(DWORD*)(v62 + 80) = 3;
									result = 1;
								}
							}
						}
						else
						{
							v18 = (int)(v75);
							v19 = (int)(v70);
							v20 = (int)(v87);
							v21 = (int)(v82);
							if (pCheckMouseOver(v21, v20, v19, v18) == 1)
							{
								*(BYTE*)(v62 + 64) = *(BYTE*)(v62 + 64) == 0;
								PlayBuffer(25, 0, 0);
								*(DWORD*)(v62 + 80) = 0;
								result = 0;
							}
							else
							{
								*(DWORD*)(v62 + 80) = 0;
								result = 1;
							}
						}
					}
					else
					{
						*(DWORD*)(v62 + 80) = 2;
						result = 0;
					}
				}
				else
				{
					*(DWORD*)(v62 + 80) = 0;
					result = 1;
				}
			}
			else
			{
				*(DWORD*)(v62 + 80) = 1;
				result = 1;
			}
		}
		else
		{
			result = 1;
		}
	}

	return result;
}

void JCSkillRaven(int JCMainSelect)
{
	float v4; // ST18_4@7
	float v5; // ST14_4@7
	signed int i; // [sp+1Ch] [bp-14h]@2
	float v8; // [sp+20h] [bp-10h]@2
	float v9; // [sp+24h] [bp-Ch]@2
	float v10; // [sp+28h] [bp-8h]@2
	float v11; // [sp+2Ch] [bp-4h]@2
	int JCResto; // eax@1

	JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	if (*(DWORD*)(dword_7BC4F04 + 676))
	{
		v10 = JCResto + 191.0;
		v11 = 379.0;
		v8 = 24.0;
		v9 = 38.0;
		for (i = 150; i < 154; ++i)
		{
			if (i == *(BYTE*)(dword_7BC4F04 + 50))
				RenderBitmap(51500, v10 + 4.0, v11 + 4.0, 20.0f, 24.0f, 0.1600000411f, 0.1000000089f, 0.6397998333f, 0.4179990888f, 1, 1, 0);

			v4 = v11 + 6.0;
			v5 = v10 + 6.0;
			JCSkillScale = 1;
			JCLoadSkill(JCMainSelect, i, v5, v4, 20.0, 28.0);
			JCSkillScale = 0;
			v10 = v10 + v8;
		}
	}
}

char JCSkillSwitchBar(int JCMainSelect)
{
	float v4; // ST18_4@26
	float v5; // ST14_4@26
	char v9; // [sp+37h] [bp-25h]@9
	float v10; // [sp+38h] [bp-24h]@3
	signed int v11; // [sp+3Ch] [bp-20h]@3
	signed int v12; // [sp+40h] [bp-1Ch]@6
	float v13; // [sp+44h] [bp-18h]@3
	float v14; // [sp+48h] [bp-14h]@3
	signed int i; // [sp+50h] [bp-Ch]@3
	float v16; // [sp+54h] [bp-8h]@16
	float v17; // [sp+58h] [bp-4h]@3
	int JCResto; // eax@1

	JCMainSelect = *(DWORD*)(GetInstance() + 32);
	JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	EnableAlphaTest(1);
	glColor4f(1.0, 1.0, 1.0, 1.0);

	if ((signed int)*(BYTE*)(dword_8128AC8 + 118) > 0 && *(BYTE*)(JCMainSelect + 64) == 1)
	{
		v17 = 349.0;
		v13 = 24.0; //-- separaci�n
		v14 = 29.5;
		v10 = JCResto + 191.0;
		v11 = 0;

		RenderBitmap(61546, JCResto + 191.3, 350.0, 243.5, 60.0, 0.0, 0.0, 1.0, 1.0, 1, 1, 0);

		for (i = 0; i < 150; ++i)
		{
			v12 = *(WORD*)(dword_8128AC8 + 2 * i + 120);
			if (*(WORD*)(dword_8128AC8 + 2 * i + 120) && (v12 < 67 || v12 > 72))
			{
				v9 = *(BYTE*)(dword_8128ABC + 88 * v12 + 55);

				if (v9 != 1 && v9 != 3)
				{
					if (v11 == 10)
						v17 = v17 + v14;
					if (v11 == 20)
						v17 = v17 - v14;
					if (v11 >= 10 && v11 < 20)
					{
						v16 = (double)(v11 - 10) * v13 + v10;
					}
					else if (v11 >= 20)
					{
						v16 = (double)(v11 - 20) * v13 + v10;
					}
					else
					{
						v16 = (double)v11 * v13 + v10;
					}

					++v11;

					if (JCPageSlotSkill == 0)
					{
						if (v11 >= 21)
							continue;
					}
					else
					{
						if (v11 < 21)
							continue;
					}
					if (i == *(BYTE*)(dword_7BC4F04 + 50))
						RenderBitmap(51500, v16 + 4.0, v17 + 4.0, 20.0f, 24.0f, 0.1600000411f, 0.1000000089f, 0.6397998333f, 0.4179990888f, 1, 1, 0);

					v4 = v17 + 6.0;
					v5 = v16 + 6.0;

					JCSkillScale = 1;
					JCLoadSkill(JCMainSelect, i, v5, v4, 20.0, 28.0);
					JCSkillScale = 0;
				}
			}
		}
		JCSkillRaven(JCMainSelect);
	}

	if (*(BYTE*)(JCMainSelect + 65) == 1 && *(DWORD*)(JCMainSelect + 16))
	{
		JCMultiSkillLine(*(DWORD*)(JCMainSelect + 16), 5.5, (int)0x815040, JCMainSelect, 0, 0);
		*(BYTE*)(JCMainSelect + 65) = 0;
	}

	SwitchEventSkill(v11, JCResto + 191.0, 349.0);

	pGLSwitch();
	EnableAlphaTest(0);

	return 1;
}

void JCSkillSelectBar(int JCMainSelect)
{
	float v4; // ST18_4@17
	float v5; // ST14_4@17
	int v7; // [sp+20h] [bp-2Ch]@13
	int v8; // [sp+24h] [bp-28h]@7
	int v9; // [sp+2Ch] [bp-20h]@18
	signed int v10; // [sp+30h] [bp-1Ch]@2
	float v11; // [sp+34h] [bp-18h]@4
	signed int i; // [sp+40h] [bp-Ch]@4
	float v13; // [sp+44h] [bp-8h]@4
	float v14; // [sp+48h] [bp-4h]@4
	int JCResto; // eax@1

	JCMainSelect = *(DWORD*)(GetInstance() + 32);
	JCResto = pWinWidth / pWinHeightReal / 2 - 320;


	if ((signed int)*(BYTE*)(dword_8128AC8 + 118) > 0)
	{
		v10 = 1;
		if (*(BYTE*)(JCMainSelect + 20))
			v10 = 6;
		v13 = JCResto + 309;
		v14 = 443.5f;
		v11 = 22.5;

		for (i = 0; i < 5; ++i)
		{
			v13 = v13 + v11;
			v8 = i + v10;
			if (i + v10 == 10)
				v8 = 0;
			if (*(DWORD*)(JCMainSelect + 4 * v8 + 24) != -1
				&& (*(DWORD*)(JCMainSelect + 4 * v8 + 24) < 120
					|| *(DWORD*)(JCMainSelect + 4 * v8 + 24) >= 124
					|| *(DWORD*)(dword_7BC4F04 + 676)))
			{
				v7 = dword_8128ABC + 88 * *(WORD*)(dword_8128AC8 + 2 * *(DWORD*)(JCMainSelect + 4 * v8 + 24) + 120);
				if (!v7 || *(BYTE*)(v7 + 55) != 3)
				{
					if (*(BYTE*)(dword_7BC4F04 + 50) == *(DWORD*)(JCMainSelect + 4 * v8 + 24))
						RenderBitmap(51500, v13, v14, 20.0f, 24.0f, 0.1600000411f, 0.1000000089f, 0.6397998333f, 0.4179990888f, 1, 1, 0);
					v4 = v14 + 2.0;
					v5 = v13 + 2.0;
					JCSkillScale = 1;
					JCLoadSkill(JCMainSelect, *(DWORD*)(JCMainSelect + 4 * v8 + 24), v5, v4, 20.0, 28.0);
					JCSkillScale = 0;
				}
			}
		}

		v9 = dword_8128ABC + 88 * *(WORD*)(dword_8128AC8 + 2 * *(BYTE*)(dword_7BC4F04 + 50) + 120);

		if (v9 && *(BYTE*)(v9 + 55) != 3)
		{
			RenderBitmap(51500, JCResto + 306, 443.5f, 20.0f, 24.0f, 0.1600000411f, 0.1000000089f, 0.6397998333f, 0.4179990888f, 1, 1, 0);
			JCSkillScale = 1;
			JCLoadSkill(JCMainSelect, *(BYTE*)(dword_7BC4F04 + 50), JCResto + 308, 445.5f, 20.0, 28.0);
			JCSkillScale = 0;
		}
	}
}

void PetHPBarEx(signed int x, signed int y, int nameIndex, signed int hp, signed int hpmax, char a9)
{
	float v15; // ST30_4@4
	float v16; // ST10_4@4
	int moveparty;

	moveparty = (*(DWORD*)0x81F6B6C > 0) ? 80 : 0;

	EnableAlphaTest(1);
	pSetBackgroundTextColor(pTextThis(), 0, 0, 0, 0);
	pSetTextColor(pTextThis(), 0xFFu, 0xFFu, 0xFFu, 0xFFu);

	if (a9)
		glColor4f(0.2, 0.0, 0.0, 0.69999999);
	else
		glColor4f(0.0, 0.0, 0.0, 0.69999999);

	pDrawBarForm((double)(x + 2), (double)(y + 2), 53.0, 13.0, 0.0, 0);
	((void(__cdecl*)())0x00637A30)();
	glColor4f(1.0, 1.0, 1.0, 1.0);

	pDrawGUI(31624, x, y, 57.0, 23.0);

	v15 = (double)hp / (double)hpmax * 50.0;
	pDrawGUI(31625, (double)(x + 4), (double)(y + 16), v15, 3.0);

	pDrawText(pTextThis(), x + 28, y + 5, (LPCTSTR)nameIndex, 0, 0, 8, 0);
	pGLSwitch();
}

__declspec(naked) void RenderSlotQ1()
{
	static DWORD Addr_JMP = 0x00895A73;
	static int JCResto;
	static float RenderPotionX = 10.0f;
	static float RenderNumberX = 30.0f;

	JCResto = (pWinWidth / pWinHeightReal / 2) - 320;

	RenderNumberX += JCResto;
	RenderPotionX += JCResto;

	_asm
	{
		PUSH ECX; / Arg4
		FLD DWORD PTR DS : [0xD4B304] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg3
		FLD DWORD PTR DS : [RenderNumberX] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg2
		FLD DWORD PTR DS : [0xD4B300] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg1
		FLD DWORD PTR DS : [RenderPotionX] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		MOV ECX, DWORD PTR SS : [EBP - 0x18] ; |
		JMP[Addr_JMP]; \main1.008977D0
	}
}

__declspec(naked) void RenderSlotW1()
{
	static DWORD Addr_JMP = 0x00895AE8;
	static float RenderPotionX = 48.0f;
	static float RenderNumberX = 68.0f;
	static int JCResto;

	JCResto = (pWinWidth / pWinHeightReal / 2) - 320;

	RenderNumberX += JCResto;
	RenderPotionX += JCResto;

	_asm
	{
		PUSH ECX; / Arg4
		FLD DWORD PTR DS : [0xD4B304] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg3
		FLD DWORD PTR DS : [RenderNumberX] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg2
		FLD DWORD PTR DS : [0xD4B300] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg1
		FLD DWORD PTR DS : [RenderPotionX] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		MOV ECX, DWORD PTR SS : [EBP - 0x20] ; |
		JMP[Addr_JMP]; \main1.00897BD0
	}
}

__declspec(naked) void RenderSlotE1()
{
	static DWORD Addr_JMP = 0x00895B5D;
	static float RenderPotionX = 86.0f;
	static float RenderNumberX = 106.0f;
	static int JCResto;

	JCResto = (pWinWidth / pWinHeightReal / 2) - 320;

	RenderNumberX += JCResto;
	RenderPotionX += JCResto;

	_asm
	{
		PUSH ECX; / Arg4
		FLD DWORD PTR DS : [0xD4B304] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg3
		FLD DWORD PTR DS : [RenderNumberX] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg2
		FLD DWORD PTR DS : [0xD4B300] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg1
		FLD DWORD PTR DS : [RenderPotionX] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		MOV ECX, DWORD PTR SS : [EBP - 0x28] ; |
		JMP[Addr_JMP]; \main1.00895760
	}
}

__declspec(naked) void RenderSlotR1()
{
	static DWORD Addr_JMP = 0x00895BD2;
	static float RenderPotionX = 124.0f;
	static float RenderNumberX = 144.0f;
	static int JCResto;

	JCResto = (pWinWidth / pWinHeightReal / 2) - 320;

	RenderNumberX += JCResto;
	RenderPotionX += JCResto;

	_asm
	{
		PUSH ECX; / Arg4
		FLD DWORD PTR DS : [0xD4B304] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg3
		FLD DWORD PTR DS : [RenderNumberX] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg2
		FLD DWORD PTR DS : [0xD4B300] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		PUSH ECX; | Arg1
		FLD DWORD PTR DS : [RenderPotionX] ; |
		FSTP DWORD PTR SS : [ESP] ; |
		MOV ECX, DWORD PTR SS : [EBP - 0x30] ; |
		JMP[Addr_JMP]; \main1.008979C0
	}
}

void RenderNumber(float a4, float a5, int Number, float a7)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	pDrawGUI(87969, JCResto + 0.0, 480.0 - 12.0, 640.0, 12.0);

	JCRenderNumber(a4 + JCResto, a5, Number, a7);
}


void JCRenderBarExp(int ImageID, float PosX, float PosY, float Width, float Height, float CurrentMoveX, float CurrentMoveY, float ScaleX, float ScaleY, bool ScaleSize, bool ScalePosition, bool ScaleAlpha)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	RenderBitmap(ImageID, PosX + JCResto, PosY, Width, Height, CurrentMoveX, CurrentMoveY, ScaleX, ScaleY, ScaleSize, ScalePosition, ScaleAlpha);
}

void JCJCRenderBarExpAdd(float PosX, float PosY, float Width, float Height, float Arg5, int Arg6)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	pDrawBarForm(PosX + JCResto, PosY, Width, Height, Arg5, Arg6);
}

bool JCCheckMouseTooltip(int a1, int a2, int a3, int a4)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	return pCheckMouseOver(a1 + JCResto, a2, a3, a4);
}

int JCTooltipDraw(int X, int Y, LPCSTR Text)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	return pDrawToolTip(X + JCResto, Y, Text);
}

void RenderButtonQuest(DWORD ModelID, float X, float Y, float W, float H, float CurrentX, float CurrentY)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	pDrawButton(ModelID, X + JCResto, Y, W, H, CurrentX, CurrentY);
}

void InterfaceLeft(int ImageID, float PosX, float PosY, float Width, float Height)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	float x = PosX + JCResto - 70.28048780487805;
	//RenderBitmap(87968, x, PosY, 70.28048780487805, 51, 0.0, 0.0, 0.8785000443, 0.6409999728, 1, 1, 0.0);

	pDrawGUI(ImageID, PosX + JCResto, PosY, Width, Height);
}

void InterfaceMiddle(int ImageID, float PosX, float PosY, float Width, float Height)
{
	int v38; // [sp+14h] [bp-28h]@1
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	pDrawGUI(ImageID, PosX + JCResto, PosY, Width, Height);

	v38 = *(DWORD*)(GetInstance() + 28);

	ChangeButtonInfo((char*)(v38 + 56), JCResto + 489, 429, 30, 41); //-- cashshop

	ChangeButtonInfo((char*)(v38 + 228), JCResto + 519, 429, 30, 41); //-- character

	ChangeButtonInfo((char*)(v38 + 400), JCResto + 549, 429, 30, 41); //-- inventario

	ChangeButtonInfo((char*)(v38 + 572), JCResto + 579, 429, 30, 41); //-- friend list

	ChangeButtonInfo((char*)(v38 + 744), JCResto + 609, 429, 30, 41); //-- system config
}

void InterfaceRight(int ImageID, float PosX, float PosY, float Width, float Height)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	pDrawGUI(ImageID, PosX + JCResto, PosY, Width, Height);

	//RenderBitmap(87968, PosX + JCResto + Width, PosY, 70.28048780487805, Height, 0.8785000443, 0.0, -0.8785000443, 0.6409999728, 1, 1, 0.0);
}

void RendewrWideTexture(int ImageID, float PosX, float PosY, float Width, float Height, float Arg6, float Arg7, float ScaleX, float ScaleY, bool ScaleSize, bool ScalePosition, float ScaleAlpha)
{
	int JCResto = pWinWidth / pWinHeightReal / 2 - 320;

	RenderBitmap(ImageID, PosX + JCResto, PosY, Width, Height, Arg6, Arg7, ScaleX, ScaleY, ScaleSize, ScalePosition, ScaleAlpha);
}

void JCInterface::Load()
{
	SetCompleteHook(0xE8, 0x007DC9E6, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCA78, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCB05, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCB96, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCC16, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCCA8, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCD35, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCDB4, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCE51, &JCItemStacknumber); //-- Number Stack
	SetCompleteHook(0xE8, 0x007DCEE7, &JCItemStacknumber); //-- Number Stack
	//--
	SetCompleteHook(0xE9, 0x00895600, &JCStacknumberpotion); //-- Number Stack

	SetCompleteHook(0xE8, 0x00814F0D, &JCShowTimerBar);
	SetCompleteHook(0xE8, 0x00814E63, &JCShownumberSkill);
	SetCompleteHook(0xE8, 0x00814DC1, &JCShowSlotSkill);
	SetCompleteHook(0xE8, 0x00814D4D, &JCShowSlotSkill);
	SetCompleteHook(0xE9, 0x008126C0, &JCEventMouseSkill); //-- Skill event
	SetCompleteHook(0xE9, 0x00813970, &JCSkillSwitchBar); //-- Skill Switch
	SetCompleteHook(0xE8, 0x0080F833, &JCSkillSelectBar); //-- Skill barr / Select

	SetCompleteHook(0xE9, 0x007DFA60, &PetHPBarEx);
	//-- Slot consumables
	SetCompleteHook(0xE9, 0x00895A48, &RenderSlotQ1);
	SetCompleteHook(0xE9, 0x00895ABD, &RenderSlotW1);
	SetCompleteHook(0xE9, 0x00895B32, &RenderSlotE1);
	SetCompleteHook(0xE9, 0x00895BA7, &RenderSlotR1);

	//-- ExpBar || Master Exp
	SetCompleteHook(0xE8, 0x0080FF28, &RenderNumber); //-- HP
	SetCompleteHook(0xE8, 0x008100BB, &RenderNumber); //-- MP
	SetCompleteHook(0xE8, 0x00810389, &RenderNumber); //-- SD
	SetCompleteHook(0xE8, 0x00810659, &RenderNumber); //-- BP
	//-- ExpBar || Master Exp
	SetCompleteHook(0xE8, 0x00810F45, &RenderNumber); //-- EXP
	SetCompleteHook(0xE8, 0x008117EE, &RenderNumber); //-- MASTEREXP
	//-- Tooltip Attributos hp mp bp sd
	SetCompleteHook(0xE8, 0x0080FFA7, &JCTooltipDraw);
	SetCompleteHook(0xE8, 0x0081013A, &JCTooltipDraw);
	SetCompleteHook(0xE8, 0x00810408, &JCTooltipDraw);
	SetCompleteHook(0xE8, 0x008106EA, &JCTooltipDraw);
	//-- check atributos hp mp bp sd
	SetCompleteHook(0xE8, 0x0080FF56, &JCCheckMouseTooltip);
	SetCompleteHook(0xE8, 0x008100E9, &JCCheckMouseTooltip);
	SetCompleteHook(0xE8, 0x008103B7, &JCCheckMouseTooltip);
	SetCompleteHook(0xE8, 0x00810699, &JCCheckMouseTooltip);
	//-- barra de experiencia/ master experiencia
	SetCompleteHook(0xE8, 0x00810A1A, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x00810BE5, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x00810D2C, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x00810DC3, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x00810EF0, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x008112A6, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x0081147F, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x008115C9, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x00811660, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x00811790, &JCRenderBarExp);
	SetCompleteHook(0xE8, 0x00810A97, &JCJCRenderBarExpAdd);
	SetCompleteHook(0xE8, 0x00810C62, &JCJCRenderBarExpAdd);
	SetCompleteHook(0xE8, 0x00810E40, &JCJCRenderBarExpAdd);
	SetCompleteHook(0xE8, 0x00811323, &JCJCRenderBarExpAdd);
	SetCompleteHook(0xE8, 0x008114FC, &JCJCRenderBarExpAdd);
	SetCompleteHook(0xE8, 0x008116DD, &JCJCRenderBarExpAdd);
	//-- imagenes centrales bar
	SetCompleteHook(0xE8, 0x008119E6, &RenderButtonQuest);
	SetCompleteHook(0xE8, 0x0080F92D, &InterfaceLeft);	//-- Letter Print
	SetCompleteHook(0xE8, 0x0080F968, &InterfaceMiddle);	//-- Letter Print
	SetCompleteHook(0xE8, 0x0080F9A3, &InterfaceRight);	//-- Letter Print
	SetCompleteHook(0xE8, 0x0080FA02, &InterfaceMiddle);	//-- Letter Print
	//-- attributo hp mana
	SetCompleteHook(0xE8, 0x0080FEEF, &RendewrWideTexture);	//-- Letter Print
	SetCompleteHook(0xE8, 0x0080FE56, &RendewrWideTexture);	//-- Letter Print
	SetCompleteHook(0xE8, 0x00810083, &RendewrWideTexture);	//-- Letter Print
	//-- attributo sd bp
	SetCompleteHook(0xE8, 0x00810354, &RendewrWideTexture);	//-- bp Print
	SetCompleteHook(0xE8, 0x00810624, &RendewrWideTexture);	//-- sd Print

}